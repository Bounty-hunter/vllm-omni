#!/usr/bin/env bash
set -euo pipefail
run=$1
export TMPDIR=/tmp/hcms-wan-partitions-20261121
export TRITON_CACHE_DIR="$TMPDIR/triton"
export TORCHINDUCTOR_CACHE_DIR="$TMPDIR/inductor"
mkdir -p "$TMPDIR" "$run/source"
export LD_LIBRARY_PATH=/home/dyy/.local/lib/python3.12/site-packages/nvidia/cudnn/lib:${LD_LIBRARY_PATH:-}
export PROBE_DIR="$PWD/benchmarks/diffusion/head_overlap"
export PYTHONPATH="$PROBE_DIR${PYTHONPATH:+:$PYTHONPATH}"
files=(vllm_omni/diffusion/attention/parallel/head_overlap.py
       vllm_omni/diffusion/distributed/a2a_permute.py
       vllm_omni/diffusion/worker/diffusion_model_runner.py)
test -z "$(git status --porcelain)"
for file in "${files[@]}"; do cp "$file" "$run/source/$(basename "$file").before"; done
restore_probe() {
  for file in "${files[@]}"; do cp "$run/source/$(basename "$file").before" "$file"; done
  git status --short > "$run/restoration-status.txt"
}
trap restore_probe EXIT
git apply --check "$PROBE_DIR/native-probe.patch"
git apply "$PROBE_DIR/native-probe.patch"
git apply --check "$PROBE_DIR/model-probe.patch"
git apply "$PROBE_DIR/model-probe.patch"
git rev-parse HEAD > "$run/source/code-sha.txt"
git diff --binary > "$run/source/integration.patch"
sha256sum "$PROBE_DIR/"*.py "$PROBE_DIR/"*.json > "$run/source/source.sha256"
cp "$PROBE_DIR/wan-partition-confirm.json" "$run/source/config.json"
cp "$0" "$run/source/payload.sh"
nvidia-smi topo -m > "$run/topology.txt"
export HCMS_MATRIX_AUDIT="$run/results/audit"
python "$PROBE_DIR/model_matrix.py" \
  --model /data/models/hub/models--Wan-AI--Wan2.2-TI2V-5B-Diffusers/snapshots/b8fff7315c768468a5333511427288870b2e9635 \
  --config "$PROBE_DIR/wan-partition-confirm.json" --out "$run/results" --rounds 30 --warmups 5
