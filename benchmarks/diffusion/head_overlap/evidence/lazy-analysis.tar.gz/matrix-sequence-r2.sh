#!/usr/bin/env bash
set -uo pipefail
upload=/tmp/codex-hcms-lazy-20261121
model_repo=/data/dyy/code/vllm-omni-codex-hcms-wan5b-matrix-r6-20261120
h3_repo=/data/dyy/code/vllm-omni-codex-hcms-h3-sp4-confirm-20261120
smoke=/data/dyy/logs/hcms-10448-lazy-h3-smoke-20261121-r2/exit-code
for attempt in {1..180}; do
  if [[ -f $smoke ]]; then break; fi
  sleep 10
done
test -f "$smoke" && test "$(cat "$smoke")" = 0 || exit 1
for repo in "$model_repo" "$h3_repo"; do
  test -z "$(git -C "$repo" status --porcelain)" || exit 1
  git -C "$repo" fetch "$upload/coverage-r2.bundle" HEAD || exit 1
  git -C "$repo" checkout --quiet --detach 47f96cf97c97ceb3c0ad2fc2ad2ee6afeb817d25 || exit 1
done
for family in qwen flux wan14b; do
  case $family in
    qwen) world=2; adapter=qwen-blocks; model=/data/models/hub/models--Qwen--Qwen-Image-Edit-2511/snapshots/6f3ccc0b56e431dc6a0c2b2039706d7d26f22cb9 ;;
    flux) world=2; adapter=whole; model=/data/models/hub/models--black-forest-labs--FLUX.2-klein-4B/snapshots/e7b7dc27f91deacad38e78976d1f2b499d76a294 ;;
    wan14b) world=4; adapter=whole; model=/data/models/hub/models--Wan-AI--Wan2.2-T2V-A14B-Diffusers/snapshots/5be7df9619b54f4e2667b2755bc6a756675b5cd7 ;;
  esac
  for order in ab ba; do
    rounds=8
    if [[ $order == ba ]]; then rounds=4; fi
    run=/data/dyy/logs/hcms-10448-lazy-${family}-${order}-20261121-r2
    bash "$upload/remote-job.sh" "$model_repo" "$run" "$world" 35m 25m "hcms-lazy-${family}-${order}" -- bash "$upload/model-matrix-payload.sh" "$run" "$model" "lazy-${family}-${order}.json" "$adapter" "$rounds"
    printf '%s %s exit=%s
' "$family" "$order" "$?"
    test -z "$(git -C "$model_repo" status --porcelain)" || exit 1
  done
done
for order in ab ba; do
  rounds=8
  if [[ $order == ba ]]; then rounds=4; fi
  run=/data/dyy/logs/hcms-10448-lazy-h3-${order}-20261121-r2
  bash "$upload/remote-job.sh" "$h3_repo" "$run" 4 35m 25m "hcms-lazy-h3-${order}" -- bash "$upload/h3-matrix-payload.sh" "$run" "lazy-h3-${order}.json" "$rounds"
  printf 'h3 %s exit=%s
' "$order" "$?"
  test -z "$(git -C "$h3_repo" status --porcelain)" || exit 1
done
