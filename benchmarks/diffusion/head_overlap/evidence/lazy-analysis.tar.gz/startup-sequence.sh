#!/usr/bin/env bash
set -uo pipefail
upload=/tmp/codex-hcms-lazy-20261121
model_repo=/data/dyy/code/vllm-omni-codex-hcms-wan5b-matrix-r6-20261120
h3_repo=/data/dyy/code/vllm-omni-codex-hcms-h3-sp4-confirm-20261120
last=/data/dyy/logs/hcms-10448-lazy-h3-cold-20261121-r2/exit-code
for attempt in {1..1080}; do
  if [[ -f $last ]]; then break; fi
  sleep 10
done
for family in qwen flux wan14b h3; do
  marker=/data/dyy/logs/hcms-10448-lazy-${family}-cold-20261121-r2/exit-code
  test -f "$marker" && test "$(cat "$marker")" = 0 || exit 1
done
for repo in "$model_repo" "$h3_repo"; do
  test -z "$(git -C "$repo" status --porcelain)" || exit 1
  git -C "$repo" fetch "$upload/startup.bundle" HEAD || exit 1
  git -C "$repo" checkout --quiet --detach 19544e5d0214b28f7ce0c9fec2b761028f60f61c || exit 1
done
for family in qwen flux wan14b; do
  case $family in
    qwen) world=2; adapter=qwen-blocks; modes='auto base'; model=/data/models/hub/models--Qwen--Qwen-Image-Edit-2511/snapshots/6f3ccc0b56e431dc6a0c2b2039706d7d26f22cb9 ;;
    flux) world=2; adapter=whole; modes='base auto'; model=/data/models/hub/models--black-forest-labs--FLUX.2-klein-4B/snapshots/e7b7dc27f91deacad38e78976d1f2b499d76a294 ;;
    wan14b) world=4; adapter=whole; modes='auto base'; model=/data/models/hub/models--Wan-AI--Wan2.2-T2V-A14B-Diffusers/snapshots/5be7df9619b54f4e2667b2755bc6a756675b5cd7 ;;
  esac
  for mode in $modes; do
    run=/data/dyy/logs/hcms-10448-lazy-${family}-startup-${mode}-20261121-r1
    bash "$upload/remote-job.sh" "$model_repo" "$run" "$world" 20m 25m "hcms-lazy-${family}-startup-${mode}" -- bash "$upload/model-matrix-payload.sh" "$run" "$model" "lazy-${family}-startup-${mode}.json" "$adapter" 2
    printf '%s startup %s exit=%s
' "$family" "$mode" "$?"
    test -z "$(git -C "$model_repo" status --porcelain)" || exit 1
  done
done
for mode in base auto; do
  run=/data/dyy/logs/hcms-10448-lazy-h3-startup-${mode}-20261121-r1
  bash "$upload/remote-job.sh" "$h3_repo" "$run" 4 20m 25m "hcms-lazy-h3-startup-${mode}" -- bash "$upload/h3-matrix-payload.sh" "$run" "lazy-h3-startup-${mode}.json" 2
  printf 'h3 startup %s exit=%s
' "$mode" "$?"
  test -z "$(git -C "$h3_repo" status --porcelain)" || exit 1
done
