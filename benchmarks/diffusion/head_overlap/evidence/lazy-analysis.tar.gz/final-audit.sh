#!/usr/bin/env bash
[[ $(id -un) == dyy ]] || exit 1
shopt -s expand_aliases
source ~/.bashrc || exit $?
type DYY >/dev/null 2>&1 || exit 1
DYY || exit $?
set -euo pipefail
model_repo=/data/dyy/code/vllm-omni-codex-hcms-wan5b-matrix-r6-20261120
h3_repo=/data/dyy/code/vllm-omni-codex-hcms-h3-sp4-confirm-20261120
for repo in "$model_repo" "$h3_repo"; do
  test -z "$(git -C "$repo" status --porcelain)"
  printf 'clean checkout %s\n' "$repo"
  git -C "$repo" rev-parse HEAD
  git -C "$repo" diff 104a01d513430a280ffa3594ae2ef3b9a8f032c5 HEAD -- '*.py' '*.patch'
done
test "$(git -C "$model_repo" rev-parse HEAD)" = 5f59005587d25b9cf6ec668e398ee471b2e1e08b
test "$(git -C "$h3_repo" rev-parse HEAD)" = 19544e5d0214b28f7ce0c9fec2b761028f60f61c
for family in qwen flux wan14b h3; do
  for suffix in ab-20261121-r2 ba-20261121-r2 cold-20261121-r2 startup-base-20261121-r1 startup-auto-20261121-r1; do
    run=/data/dyy/logs/hcms-10448-lazy-${family}-${suffix}
    test "$(cat "$run/exit-code")" = 0
    test ! -s "$run/restoration-status.txt"
  done
done
run=/data/dyy/logs/hcms-10448-lazy-wan14b-confirm-20261121-r1
test "$(cat "$run/exit-code")" = 0
test ! -s "$run/restoration-status.txt"
printf 'PASS all final, pilot and confirmation runs exited0 and restored clean\n'
