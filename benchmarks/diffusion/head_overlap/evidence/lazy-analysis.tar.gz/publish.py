"""Publish verified lazy-policy data without mixing pilot and final evidence."""
import csv
import hashlib
import json
import shutil
import statistics
import tarfile
from pathlib import Path

root = Path('outputs/issue-10448-lazy-20261121')
bench = Path('worktrees/issue-10448-hcms/benchmarks/diffusion/head_overlap')
work = Path('work/issue-10448-lazy-20261121')
data = json.loads((root/'summary.json').read_text(encoding='utf-8'))
coverage = json.loads((bench/'evidence/coverage-summary.json').read_text(encoding='utf-8'))
families = ('qwen', 'flux', 'wan14b', 'h3')
cold_runs = [f'{family}-cold-20261121-r2' for family in families]
startup_runs = [f'{family}-startup-{mode}-20261121-r1' for family in families for mode in ('base', 'auto')]
pilot_runs = [f'{family}-{order}-20261121-r2' for family in families for order in ('ab', 'ba')]
confirm_run='wan14b-confirm-20261121-r1'
expected = dict(zip(cold_runs, (132, 132, 132, 176)))
expected.update({run:5 for run in startup_runs})
expected.update({run:(110 if run.startswith('h3-ab') else 70 if run.startswith('h3-ba') else 88 if '-ab-' in run else 56) for run in pilot_runs})
expected[confirm_run]=66
for run, count in expected.items():
    assert data['runs'][run]['exit_code']=='0' and data['runs'][run]['requests']==count, run
    assert data['runs'][run]['restoration_status']=='', run
    sha = data['runs'][run]['source_sha']
    assert sha == ('5f59005587d25b9cf6ec668e398ee471b2e1e08b' if run==confirm_run else
                   '104a01d513430a280ffa3594ae2ef3b9a8f032c5' if run in cold_runs else
                   '19544e5d0214b28f7ce0c9fec2b761028f60f61c' if run in startup_runs else
                   '47f96cf97c97ceb3c0ad2fc2ad2ee6afeb817d25'), (run, sha)
    family=run.split('-')[0]
    suffix=('confirm' if run==confirm_run else 'cold' if run in cold_runs else
            'startup-'+run.split('-')[2] if run in startup_runs else run.split('-')[1])
    tested=json.loads((root/run/'source/config.json').read_text(encoding='utf-8'))
    published=json.loads((bench/f'lazy-{family}-{suffix}.json').read_text(encoding='utf-8'))
    for value in (tested,published):
        value['measurement'].pop('selection',None)
    assert tested==published,(run,'published execution config drift')


def find(run, case, arm):
    return next(row for row in data['rows'] if (row['run'],row['case'],row['variant'])==(run,case,arm))


def policy(row):
    result=[]
    for component, value in row.get('policies',{}).get('0',{}).items():
        for index, report in enumerate(value['reports']):
            result.append(dict(component=component, signature_index=index, signature=report['signature'],
                selected=report['selected'], choices=report['choices'],
                valid_samples=[len(v) for v in report['samples_max_rank_us']],
                median_core_us=[statistics.median(v) if v else None for v in report['samples_max_rank_us']],
                pairing=report.get('pairing','pilot: independently qualified choices')))
    return result


def arm_record(row):
    return {key:row[key] for key in ('run','case','variant','cold_ms','cold_peak_memory_mb','median_ms','reduction_pct','rounds','wins',
        'paired_median_saved_ms','paired_bootstrap95_ms','paired_saved_ms','samples_ms','output_shapes','sampling')}


def audits(row, key):
    result={}
    for rank,audit in row[key].items():
        result[rank]={name:value for name,value in audit.items() if name not in ('lazy_policy','lazy_policies')}
        values=({'blocks':audit['lazy_policy']} if audit.get('lazy_policy') else audit.get('lazy_policies',{}))
        if values:
            result[rank]['learning_stats']={component:value['stats'] for component,value in values.items()}
    return result


canonical=[]
for run in cold_runs:
    cases=sorted({row['case'].removesuffix('-cold-ab').removesuffix('-cold-ba') for row in data['rows'] if row['run']==run})
    for case in cases:
        orders=[]
        base_values, auto_values=[],[]
        for order in ('ab','ba'):
            actual=f'{case}-cold-{order}'
            base, auto=find(run,actual,'serial1'), find(run,actual,'adaptive')
            orders.append(dict(order=order, baseline=arm_record(base), adaptive=arm_record(auto), policy=policy(auto),
                first_rank_audits={arm:audits(row,'first_rank_audits') for arm,row in (('serial1',base),('adaptive',auto))},
                steady_rank_audits={arm:audits(row,'steady_rank_audits') for arm,row in (('serial1',base),('adaptive',auto))}))
            base_values.extend(base['samples_ms'])
            auto_values.extend(auto['samples_ms'])
        b,a=statistics.median(base_values),statistics.median(auto_values)
        control=next((c for c in coverage['controls'] if c['request_case']==case),None)
        share=None
        if control:
            peer=control['peer_forward_us']+control['peer_reverse_us']
            share=dict(source='coverage-summary.json: independent controls, ESTIMATE not request profiling',
                control=control['case'], source_sha=control['source_sha'], peer_us=peer,
                calls_per_request=control['calls_per_request'],
                isolated_peer_core_fraction_pct=control['isolated_peer_core_fraction_pct'],
                estimated_peer_request_fraction_pct=peer*control['calls_per_request']/1000/b*100,
                controlled_partition=control['head_sizes'], splitting_tax_us=control['splitting_tax_us'],
                limitation='Splitting tax belongs only to this controlled partition, not necessarily the newly learned partition.')
        all_whole=all(len(p['selected'])==1 for order in orders for p in order['policy'])
        status=('whole fallback; A/A timing difference' if all_whole else
                'stable observed benefit in both orders' if all(order['adaptive']['paired_bootstrap95_ms'][0]>0 and order['adaptive']['wins']>=7 for order in orders) else
                'inconclusive or order-dependent end-to-end result')
        canonical.append(dict(case=case,baseline_ms=b,adaptive_ms=a,reduction_pct=(b-a)/b*100,
            all_whole=all_whole, interpretation=status,
            rounds=16,wins=sum(order['adaptive']['wins'] for order in orders),
            output_shapes=orders[0]['adaptive']['output_shapes'],communication=share,orders=orders))
assert len(canonical)==13

startup=[]
for family in families:
    rows=[next(row for row in data['rows'] if row['run']==f'{family}-startup-{mode}-20261121-r1') for mode in ('base','auto')]
    base, auto=rows
    startup.append(dict(family=family,baseline=arm_record(base),adaptive=arm_record(auto),policy=policy(auto),
        cold_added_ms=auto['cold_ms']-base['cold_ms'],
        learning_phase_max_rank_ms={component:{key:max(values[component]['stats'][key] for values in auto['policies'].values())
            for key in ('prepare_ms','finish_ms')} for component in auto['policies']['0']},
        first_rank_audits={arm:audits(row,'first_rank_audits') for arm,row in (('serial1',base),('adaptive',auto))},
        steady_rank_audits={arm:audits(row,'steady_rank_audits') for arm,row in (('serial1',base),('adaptive',auto))}))

confirmation=[]
for row in data['rows']:
    if row['run']==confirm_run:
        confirmation.append(dict(**arm_record(row),policy=policy(row),first_rank_audits=audits(row,'first_rank_audits'),steady_rank_audits=audits(row,'steady_rank_audits')))
assert len(confirmation)==2
control=next(c for c in coverage['controls'] if c['request_case']=='wan14b-480x832-f33')
confirm_base=next(row for row in confirmation if row['variant']=='serial1')
confirm_auto=next(row for row in confirmation if row['variant']=='adaptive')
confirm_share=(control['peer_forward_us']+control['peer_reverse_us'])*control['calls_per_request']/1000/confirm_base['median_ms']*100
for row in confirmation:
    row['estimated_peer_request_fraction_pct']=confirm_share

compact=dict(scope='Explicit offline CUDA graphs, batch/concurrency 1, engine request latency, model loading excluded; no new profiler.',
    final_source='104a01d513430a280ffa3594ae2ef3b9a8f032c5',
    startup_source='19544e5d0214b28f7ce0c9fec2b761028f60f61c; Python and patches identical to final_source',
    final_requests=sum(expected[run] for run in cold_runs+startup_runs),
    pilot_requests=sum(expected[run] for run in pilot_runs),
    confirmation_requests=66,confirmation=confirmation,
    successful_smoke_requests=44,canonical_cases=canonical,startup=startup,
    runs=data['runs'],pilot_rows=[dict(**arm_record(row),policy=policy(row)) for row in data['rows'] if row['run'] in pilot_runs],
    archive_sha256=hashlib.sha256((root/'evidence.tar.gz').read_bytes()).hexdigest())
evidence=bench/'evidence'
(evidence/'lazy-summary.json').write_text(json.dumps(compact,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(root/'evidence.tar.gz',evidence/'lazy-raw.tar.gz')
shutil.copyfile(root/'manifest.json',evidence/'lazy-manifest.json')
with tarfile.open(evidence/'lazy-analysis.tar.gz','w:gz') as archive:
    for name in ('summarize.py','publish.py','inspect_results.py','observe.py','collect.py','remote-job.sh',
                 'matrix-sequence-r2.sh','cold-sequence-r2.sh','startup-sequence.sh','confirm-sequence.sh',
                 'model-matrix-payload.sh','h3-matrix-payload.sh','final-audit.sh','self-check.txt'):
        archive.add(work/name,arcname=name)
    archive.add(root/'verification.log',arcname='verification.log')
    for name in ('code-precommit.log','remote-audit.log'):
        archive.add(root/name,arcname=name)
    if (root/'docs-precommit.log').exists():
        archive.add(root/'docs-precommit.log',arcname='docs-precommit.log')

lines=[
    'Issue #10448: lazy head-partition learning from existing forwards, 2026-11-21', '',
    'Scope and source', compact['scope'],
    'Final same-preparation/cycle-qualified source104a01d51: 572 requests,13 actual cases,AB/BA8pairs each.',
    'Independent-process first-request source19544e5d0:40 requests; Python/patches identical to104a01d51.',
    'Wan33f longer confirmation source5f5900558:66 requests,30pairs; Python/patches identical to104a01d51.',
    'Pilot source47f96cf97:612 requests,AB8/BA4pairs; generic cold preparation differed and pairing filtered choices independently.',
    'Pilot figures are retained but are not final cold-cost or final selector evidence. Successful smokes44 requests.',
    'All successful runs verify exact generated output arrays at seeds42/43/44, per-rank strategy agreement and clean restoration.',
    'Independent-process startup outputs are also checked across baseline/adaptive processes at all three seeds.',
    'No correctness tolerance was relaxed; failed early harness runs are retained separately.',
    'Published recipe descriptive selection notes were corrected after testing; every execution-setting field matches the byte-hashed tested recipe.',
    'NVIDIA L20X,NV18; Torch2.14.0+cu130,vLLM0.34.0; CUDA BF16 attention, batch1, one compute stream.',
    'Qwen-Image-Edit-2511:FP8 DiT480 linears,SP2,8steps,ref1; FLUX.2-klein4B:BF16,SP2,4steps.',
    'Qwen/FLUX request VAE2, but registry ignores it: VAE patch parallelism is NOT enabled for them.',
    'Wan2.2-T2V-A14B:two experts,each320 FP8 linears,SP4,tiled VAE4,8steps.',
    'H3-Image:260 FP8 linears,SP4,encoderTP4,nativeVAE4,6PDD steps. CFG1 throughout.',
    'H3 small canvases set min_generation_area=None; image quality at reduced canvas is not qualified.',
    '', 'Final steady E2E:16 paired rounds (32 requests) across two independent shape-cache-miss learns',
    'case | actual output | whole-borrowed ms | adaptive ms | delta | AB/BA delta | wins | selected heads by signature AB/BA | estimated peer/request | interpretation',
]
for row in canonical:
    settings=[';'.join('+'.join(map(str,p['selected'])) for p in order['policy']) for order in row['orders']]
    ratios='/'.join(f"{order['adaptive']['reduction_pct']:+.2f}%" for order in row['orders'])
    share='not controlled' if row['communication'] is None else f"{row['communication']['estimated_peer_request_fraction_pct']:.2f}%"
    delta='A/A (whole fallback)' if row['all_whole'] else f"{row['reduction_pct']:+.2f}%"
    lines.append(f"{row['case']} | {row['output_shapes']} | {row['baseline_ms']:.3f} | {row['adaptive_ms']:.3f} | {delta} | {ratios} | {row['wins']}/16 | {' / '.join(settings)} | {share} | {row['interpretation']}")
lines += ['', 'Additional Wan33f performance confirmation (all30pairs retained)']
for row in confirmation:
    lines.append(f"{row['variant']}: median{row['median_ms']:.3f}ms, delta{row['reduction_pct']:+.2f}%, wins{row['wins']}/30, paired_saved{row['paired_median_saved_ms']:+.3f}ms, interval{row['paired_bootstrap95_ms']}")
lines.append(f'Estimated peer/request with confirmation baseline denominator: {confirm_share:.2f}% (same isolated coverage control, not request profiling).')
lines += ['', 'Per-order paired evidence and first shape-cache-miss request',
    'Each AB/BA arm cold is one new-graph request in the SAME loaded model process. Backend shapes may have been seen already.',
    'Cold arm order, graph teardown, allocator/cache state and initialization affect these times; do not label the delta pure exploration overhead.',
    'Counters/audits are enabled during first/correctness requests. Request wall time includes their CPU cost; audit persistence after Omni.generate is excluded.',
    'case/order | whole cold ms | adaptive cold ms | median paired saved ms | descriptive95% bootstrap interval',
]
for row in canonical:
    for order in row['orders']:
        b,a=order['baseline'],order['adaptive']
        lines.append(f"{row['case']}/{order['order']} | {b['cold_ms']:.3f} | {a['cold_ms']:.3f} | {a['paired_median_saved_ms']:+.3f} | {a['paired_bootstrap95_ms']}")
lines += ['', 'Independent-process first request after model loading',
    'One baseline and one adaptive process per family; one first-request observation each. Not a cold-latency distribution or pure causal exploration estimate.',
    'Qwen/Wan run adaptive first; FLUX/H3 run baseline first. Compiler storage uses task-local caches; process initialization remains in request wall time.',
    'family | whole first ms | adaptive first ms | added ms | learned heads | whole/adaptive reported peak MB',
]
for row in startup:
    widths=';'.join('+'.join(map(str,p['selected'])) for p in row['policy'])
    lines.append(f"{row['family']} | {row['baseline']['cold_ms']:.3f} | {row['adaptive']['cold_ms']:.3f} | {row['cold_added_ms']:+.3f} | {widths} | {row['baseline']['cold_peak_memory_mb']}/{row['adaptive']['cold_peak_memory_mb']}")
    lines.append('  observed learning phase wall times (max rank per component, ms): '+json.dumps(row['learning_phase_max_rank_ms']))
lines += ['', 'Learning, execution counts and limitations',
    'Each actual eager attention call executes one complete candidate core; output feeds the model. No extra forward/dummy kernel/probe graph is added.',
    'Generic first-request Python body count5 =4 executed eager passes +1 capture recording; each component also executes its original denoising replays.',
    'Qwen native calls300=60layers*5; FLUX125=25layers*5; Wan400=40layers*5*2experts.',
    'H3 native150=50layers*(2 executed eager passes +1 capture recording); original validation replay1 and denoising replay6 remain.',
    'These counts match baseline on every rank at every first shape. Hits have0 core/body Python calls and do not recapture.',
    'First sampling has0 per-core host sync and0 captured learning timers. Header and finish are at most2 CPU-group gathers per learner, not per layer.',
    'Steady learning timer records,event queries,exploration all_gather_object and sampling_host_syncs are0 on all ranks.',
    'H3 original pipeline still calls101 all_reduce,61 Tensor.item and variable non-learning event APIs per request, equal in scope to baseline.',
    'Existing GPU peer fences/dependency events execute during replay; zero learning APIs does not mean the graph contains no events or communication.',
    'Preallocated events are recorded twice to realize handles and twice for each real sample; slow candidates and resource preparation have real once-per-shape costs.',
    'Candidate native plans/buffers remain in the existing bounded plan/slot caches until graph-owner clear; they increase memory residency even after freezing.',
    'Reported peak MB is the pipeline-provided metric, not a new allocator/residency measurement. In-process arm peaks share allocator history.',
    'prepare_ms includes waiting behind existing GPU work and collective/resource preparation; it is not pure incremental CPU work.',
    'Candidate proxy uses query tiles*heads/SMs plus estimated communication coverage; odd widths allowed, at most2 splits. No online global coefficient fit.',
    'The proxy predicts candidates, not actual FA launch grids. Exact complete-core observations and conservative noise margins decide the frozen policy.',
    'Only complete candidate cycles fully queued on every rank qualify. The start.query() readiness test is nonblocking; elapsed times are read at an existing sync.',
    'Insufficient samples or gains retain whole. Qwen512/1K currently have no fully queued cycles and miss the previously verified Qwen1K fixed-split opportunity.',
    'Wan17f also has no qualified complete cycles in the final matrix and retains whole despite a previously validated fixed4+6 benefit.',
    'Wan33f final eight-pair blocks have opposite E2E signs and hundred-ms request jitter despite consistent2+8 choices and lower observed core times.',
    'Their pooled median is not accepted as a stable benefit. Longer confirmation is reported separately; no outliers are removed.',
    f"The separate30-pair Wan33f confirmation reports{confirm_auto['reduction_pct']:+.2f}%, {confirm_auto['wins']}/30wins; it does not erase the earlier noisy blocks.",
    'Shape selection is graph-owned and reused on graph hits; no cross-process persistence or sharing between separate Wan expert graph owners.',
    'A changed shape in this harness invalidates graphs and relearns. Metadata/strides/backend/SP are in the execution signature.',
    'Unsupported mask/opaque metadata and small packed varlen remain whole; unexpected post-discovery signatures fail closed.',
    'Only naturally existing pre-capture eager calls are usable. Whole-DiT graph replay cannot perform Python exploration inside its already captured layers.',
    'Same borrowed output ownership is used for whole and adaptive. Removing a clone is not counted as overlap benefit.',
    '', 'Communication and split-cost interpretation',
    'Request peer share is reused from independent coverage controls: (F+R)*calls/E2E, an ESTIMATE, not newly profiled request communication.',
    'These controls include required peer fences and exclude encoder/VAE/other communication. Core peer share is C/(Awhole+C).',
    'Control splitting tax applies only to its recorded partition; it cannot be assigned to a different newly learned5+9/3+11 partition.',
    'Peer bytes do not decrease. Two groups hide part of traffic behind attention; first input exchange and final return remain exposed.',
    'For small-first fraction x, ideal hidden time is min(A0,(1-x)*F)+min(A1,x*R). Net benefit also pays split-kernel/fence costs and any interference.',
    'CE copies can still share DRAM/cache resources and require fences. This experiment does not establish a hardware cause for request jitter.',
    'Large attention can cover more traffic, but growing quadratic attention lowers the communication fraction; percentage E2E gains need not rise monotonically.',
    'Small-shape fallback eliminates split work at steady state; these A/A runs do not prove first-request nonregression.',
    'Small uniform-split safety is not claimed. The prior H3 packed auto-SplitKV precision failure remains documented in COVERAGE-RESULTS.txt.',
    'No HTTP/concurrency/torch.compile/hybrid-parallel qualification or production-default selector is claimed.',
    '', 'Evidence', f"Raw archive SHA256: {compact['archive_sha256']}",
    'evidence/lazy-summary.json: canonical and per-order latencies, actual shapes, policies, first/hit counters, startup observations and pilot rows.',
    'evidence/lazy-raw.tar.gz + lazy-manifest.json: exact raw samples/configs/source patches/audits/exit codes and file hashes.',
    'Large output arrays remain remote with hashes in the manifest; raw run outputs contain pixel hashes/shapes/dtypes.',
    'evidence/lazy-analysis.tar.gz: verification/publication/collection/launch scripts and author self-check. No new profiler trace or PR.',
    'AI assistance: Codex prepared implementation, measurements and analysis.',
]
(bench/'LAZY-RESULTS.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
with (root/'canonical.csv').open('w',encoding='utf-8-sig',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=('case','baseline_ms','adaptive_ms','reduction_pct','all_whole','wins','rounds'),extrasaction='ignore')
    writer.writeheader()
    writer.writerows(canonical)
print(json.dumps(dict(canonical_cases=len(canonical),final_requests=compact['final_requests'],pilot_requests=compact['pilot_requests'],archive_sha256=compact['archive_sha256'])))
