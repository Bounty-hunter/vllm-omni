"""Package only this task's exited jobs and preserve their byte identities."""

import hashlib
import json
import tarfile
from pathlib import Path

runs=[f'qwen-smoke-20261121-r{i}' for i in (1,2,3)]+['h3-smoke-20261121-r1']
runs += [f'{family}-{order}-20261121-r1' for family in ('qwen','flux','wan14b','h3') for order in ('ab','ba')]
runs += ['h3-smoke-20261121-r2']
runs += [f'{family}-{order}-20261121-r2' for family in ('qwen','flux','wan14b','h3') for order in ('ab','ba')]
runs += [f'{family}-cold-20261121-r2' for family in ('qwen','flux','wan14b','h3')]
runs += [f'{family}-startup-{mode}-20261121-r1' for family in ('qwen','flux','wan14b','h3') for mode in ('base','auto')]
runs += ['wan14b-confirm-20261121-r1']
manifest={}
target=Path('/tmp/codex-hcms-lazy-20261121/evidence.tar.gz')
with tarfile.open(target,'w:gz') as archive:
    for name in runs:
        folder=Path('/data/dyy/logs')/f'hcms-10448-lazy-{name}'
        if not (folder/'exit-code').is_file():
            continue
        row={'remote':str(folder),'exit_code':(folder/'exit-code').read_text().strip(),'files':[],'external_arrays':[]}
        manifest[name]=row
        for file in sorted(folder.rglob('*')):
            if not file.is_file():
                continue
            item={'file':f'{name}/{file.relative_to(folder).as_posix()}',
                  'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'bytes':file.stat().st_size}
            if file.suffix=='.npz':
                row['external_arrays'].append(item)
                continue
            assert file.stat().st_size<30_000_000,file
            archive.add(file,arcname=item['file'])
            row['files'].append(item)
target.with_name('manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'runs':{k:v['exit_code'] for k,v in manifest.items()},'bytes':target.stat().st_size,
                  'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
