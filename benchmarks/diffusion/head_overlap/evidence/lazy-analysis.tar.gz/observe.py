"""Read this experiment's progress without importing accelerator libraries."""

import json
from pathlib import Path

for directory in sorted(Path('/data/dyy/logs').glob('hcms-10448-lazy-*20261121*')):
    if '-sequence-' in directory.name:
        continue
    status={'run':directory.name,'state':'running'}
    if (directory/'exit-code').exists():
        status.update(state='completed',exit_code=(directory/'exit-code').read_text().strip())
    result=directory/'results/results.json'
    if result.exists():
        records=json.loads(result.read_text())['records']
        if records:
            status.update(requests=len(records),last={key:records[-1][key] for key in ('case','variant','phase','index')})
    log=directory/'run.log'
    if log.exists():
        status['preflight_pass']=any('PASS backend identity' in line for line in log.read_text().splitlines())
    print(json.dumps(status),flush=True)
