#!/usr/bin/env bash
set -euo pipefail
upload=/tmp/codex-hcms-lazy-20261121
repo=/data/dyy/code/vllm-omni-codex-hcms-wan5b-matrix-r6-20261120
last=/data/dyy/logs/hcms-10448-lazy-h3-startup-auto-20261121-r1/exit-code
for attempt in {1..1080}; do
  if [[ -f $last ]]; then break; fi
  sleep 10
done
for family in qwen flux wan14b h3; do
  for mode in base auto; do
    marker=/data/dyy/logs/hcms-10448-lazy-${family}-startup-${mode}-20261121-r1/exit-code
    test -f "$marker" && test "$(cat "$marker")" = 0 || exit 1
  done
done
test -z "$(git -C "$repo" status --porcelain)"
git -C "$repo" fetch "$upload/confirm.bundle" HEAD
git -C "$repo" checkout --quiet --detach 5f59005587d25b9cf6ec668e398ee471b2e1e08b
run=/data/dyy/logs/hcms-10448-lazy-wan14b-confirm-20261121-r1
model=/data/models/hub/models--Wan-AI--Wan2.2-T2V-A14B-Diffusers/snapshots/5be7df9619b54f4e2667b2755bc6a756675b5cd7
bash "$upload/remote-job.sh" "$repo" "$run" 4 20m 25m hcms-lazy-wan-confirm -- bash "$upload/model-matrix-payload.sh" "$run" "$model" lazy-wan14b-confirm.json whole 30
test -z "$(git -C "$repo" status --porcelain)"
