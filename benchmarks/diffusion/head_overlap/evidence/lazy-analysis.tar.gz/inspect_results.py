"""Print compact policy and latency evidence from the verified summary."""
import json
import statistics
from pathlib import Path

root = Path('outputs/issue-10448-lazy-20261121')
data = json.loads((root/'summary.json').read_text(encoding='utf-8'))
for row in data['rows']:
    if row['variant'] != 'adaptive' or '-smoke-' in row['run']:
        continue
    policies = row['policies']['0']
    descriptions = []
    for name, policy in policies.items():
        for report in policy['reports']:
            descriptions.append(dict(component=name, chosen=report['selected'],
                choices=report['choices'], n=[len(v) for v in report['samples_max_rank_us']],
                median_us=[round(statistics.median(v),1) if v else None for v in report['samples_max_rank_us']]))
    audit = row['first_rank_audits']['0']
    steady = row['steady_rank_audits']['0']
    print(json.dumps(dict(run=row['run'], case=row['case'], ms=round(row['median_ms'],2),
        gain=round(row['reduction_pct'],2), wins=row['wins'], ci=row['paired_bootstrap95_ms'],
        policies=descriptions, first_counters=audit['execution_counters'], steady_counters=steady['execution_counters'],
        calls=audit.get('native_python_calls',audit.get('direct_python_calls')), forwards=audit.get('eager_forwards'),
        graph_stats=audit.get('graph_stats')),ensure_ascii=False))
