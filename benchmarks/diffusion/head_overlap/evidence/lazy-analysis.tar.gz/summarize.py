"""Verify exited lazy-learning experiments, including cold requests and counters."""

import hashlib
import json
import random
import statistics
import subprocess
from pathlib import Path

root=Path('outputs/issue-10448-lazy-20261121')
repo=Path('worktrees/issue-10448-hcms')
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
summary={'scope':'Explicit offline graphs, batch/concurrency1, no profiler. Cold is first request of a variant at a new canvas, model loading excluded.',
         'runs':{},'rows':[],'first_order_note':'AB and BA retain both first-request timings. Common initialization and compilation can affect order; do not call one AB delta pure exploration overhead.'}
blobs={}


def interval(values):
    if not values:
        return None
    rng=random.Random(10448)
    rows=sorted(statistics.median(rng.choices(values,k=len(values))) for _ in range(10000))
    return [rows[249],rows[9749]]


def policies(row,h3):
    if h3:
        return {'blocks':row['lazy_policy']} if row.get('lazy_policy') else {}
    return row.get('lazy_policies',{})


for name,item in manifest.items():
    folder=root/name
    for entry in item['files']:
        file=root/entry['file']
        assert file.stat().st_size==entry['bytes']
        assert hashlib.sha256(file.read_bytes()).hexdigest()==entry['sha256'],file
    assert (folder/'exit-code').read_text(encoding='utf-8').strip()==item['exit_code']
    run=summary['runs'][name]={'exit_code':item['exit_code'],'remote':item['remote']}
    restoration=folder/'restoration-status.txt'
    run['restoration_status']=restoration.read_text(encoding='utf-8') if restoration.exists() else 'not recorded'
    if item['exit_code']!='0':
        print('FAILED, retained:',name)
        continue
    assert run['restoration_status']=='',name
    sha=(folder/'source/code-sha.txt').read_text(encoding='utf-8').strip()
    run['source_sha']=sha
    for line in (folder/'source/source.sha256').read_text(encoding='utf-8').splitlines():
        expected,path=line.split(maxsplit=1)
        path='benchmarks/diffusion/head_overlap/'+path.rsplit('/',1)[-1]
        key=sha,path
        if key not in blobs:
            blobs[key]=subprocess.check_output(['git','-C',str(repo),'show',f'{sha}:{path}'])
        assert hashlib.sha256(blobs[key]).hexdigest()==expected,(name,path)
    config=json.loads((folder/'source/config.json').read_text(encoding='utf-8'))
    data=json.loads((folder/'results/results.json').read_text(encoding='utf-8'))
    assert data['config']==config
    assert not config['engine']['enable_diffusion_pipeline_profiler']
    h3=name.startswith('h3-')
    startup='-startup-' in name
    parallel=config['engine'].get('parallel_config',config['engine'])
    world=parallel['ulysses_degree']
    audit_folder=folder/('audit' if h3 else 'results/audit')
    audits={rank:[json.loads(line) for line in (audit_folder/(f'audit-rank{rank}.jsonl' if h3 else f'rank{rank}.jsonl')).read_text(encoding='utf-8').splitlines()]
            for rank in range(world)}
    run['requests']=len(data['records'])
    run['rank0_model_audit']=next(row for row in audits[0] if row['kind']=='model')
    run['vae_patch_ignored']='VAE patch parallelism is NOT enabled' in (folder/'run.log').read_text(encoding='utf-8')
    for case in config['cases']:
        arms=case.get('variants',config['variants'])
        records=[r for r in data['records'] if r['case']==case['id']]
        rounds=config['measurement']['rounds']
        assert len(records)==len(arms)*(rounds+config['measurement']['warmups']+2)
        sampling=case['sampling']
        expected_shape=([1,sampling['num_frames'],sampling['height'],sampling['width'],3]
                        if sampling.get('num_frames',1)>1 else [sampling['height'],sampling['width'],3])
        assert all(row['shapes']==[expected_shape] for row in records),(name,case['id'],'actual output geometry differs')
        for seed in (42,43,44):
            rows=[r for r in records if r['seed']==seed]
            assert {r['variant'] for r in rows}==set(arms)
            assert len({json.dumps((r['hashes'],r['shapes'],r['dtypes'])) for r in rows})==1
        assert all(not r['profile'] and r['variant_config']==arms[r['variant']] for r in records)
        firsts,steady={},{ }
        for rank,audit in audits.items():
            firsts[rank]={}
            steady[rank]={}
            for arm in arms:
                first=next(r for r in audit if r.get('label')==f'{case["id"]}-warm-{arm}-i0')
                post=next(r for r in audit if r.get('label')==f'{case["id"]}-correctness-{arm}-i0')
                firsts[rank][arm],steady[rank][arm]=first,post
                assert first['mode']==post['mode']=='graph'
                assert post['native_python_calls' if h3 else 'direct_python_calls']==0
                counts=post.get('execution_counters',{})
                assert all(counts.get(key,0)==0 for key in ('timed_event_records','captured_timer_records','sampling_host_syncs','event_queries','all_gather_object'))
                assert all(value==0 for value in post.get('eager_forwards',{}).values())
                if not h3:
                    assert first['graph_stats'].keys()==post['graph_stats'].keys()
                    assert {k:v['captures'] for k,v in first['graph_stats'].items()}=={k:v['captures'] for k,v in post['graph_stats'].items()}
                    assert all(value['captures']==value['graphs']==1 for value in first['graph_stats'].values())
                else:
                    assert post['graph_exists']
                if arm=='adaptive':
                    if not startup:
                        baseline=firsts[rank].get('serial1') or next(r for r in audit if r.get('label')==f'{case["id"]}-warm-serial1-i0')
                        calls='native_python_calls' if h3 else 'direct_python_calls'
                        assert first[calls]==baseline[calls],(name,case['id'],first[calls],baseline[calls])
                        assert first.get('eager_forwards')==baseline.get('eager_forwards')
                    assert first['execution_counters'].get('sampling_host_syncs',0)==0
                    assert first['execution_counters'].get('captured_timer_records',0)==0
                    for component,policy in policies(first,h3).items():
                        last=policies(post,h3)[component]
                        assert policy==last,(name,case['id'],component,'steady policy changed')
                        if rank:
                            assert policy['reports']==policies(firsts[0]['adaptive'],h3)[component]['reports']
                        for report in policy['reports']:
                            if report.get('pairing'):
                                assert len({len(values) for values in report['samples_max_rank_us']})==1
            if h3:
                for capture in audit:
                    if capture['kind']=='graph_created':
                        assert capture['blocks']==capture['native_capture_calls']==50 and capture['eager_graph_bitwise_equal']
        base={r['index']:r['e2e_ms'] for r in records if r['phase']=='paired' and r['variant']=='serial1'}
        if startup and not base:
            base={r['index']:r['e2e_ms'] for r in records if r['phase']=='paired'}
        for arm in arms:
            values={r['index']:r['e2e_ms'] for r in records if r['phase']=='paired' and r['variant']==arm}
            assert set(values)==set(base)==set(range(rounds))
            differences=[base[i]-values[i] for i in base]
            first=next(r for r in records if r['phase']=='warm' and r['index']==0 and r['variant']==arm)
            row={'run':name,'case':case['id'],'variant':arm,'rounds':rounds,'median_ms':statistics.median(values.values()),
                 'startup_only':startup,
                 'cold_ms':first['e2e_ms'],'cold_peak_memory_mb':first['peak_memory_mb'],'output_shapes':first['shapes'],'sampling':case['sampling'],
                 'reduction_pct':100*(statistics.median(base.values())-statistics.median(values.values()))/statistics.median(base.values()),
                 'paired_saved_ms':differences,'paired_median_saved_ms':statistics.median(differences),'paired_bootstrap95_ms':interval(differences),
                 'wins':sum(value>0 for value in differences),'samples_ms':list(values.values()),
                 'first_rank_audits':{rank:rows[arm] for rank,rows in firsts.items()},
                 'steady_rank_audits':{rank:rows[arm] for rank,rows in steady.items()}}
            if arm=='adaptive':
                row['policies']={rank:policies(arms_['adaptive'],h3) for rank,arms_ in firsts.items()}
            summary['rows'].append(row)
            print(f'{name} {case["id"]} {arm}: cold {row["cold_ms"]:.2f}, median {row["median_ms"]:.2f}ms, {row["reduction_pct"]:+.2f}%, {row["wins"]}/{rounds}')
for family in ('qwen','flux','wan14b','h3'):
    base=next((r for r in summary['rows'] if r['run']==f'{family}-startup-base-20261121-r1'),None)
    auto=next((r for r in summary['rows'] if r['run']==f'{family}-startup-auto-20261121-r1'),None)
    if base and auto:
        assert base['sampling']==auto['sampling'] and base['output_shapes']==auto['output_shapes']
        for seed in (42,43,44):
            records=[]
            for row in (base,auto):
                raw=json.loads((root/row['run']/'results/results.json').read_text(encoding='utf-8'))
                records.extend((r['hashes'],r['shapes'],r['dtypes']) for r in raw['records'] if r['seed']==seed)
            assert len({json.dumps(record) for record in records})==1,(family,seed,'independent-process outputs differ')
        for rank,first in auto['first_rank_audits'].items():
            reference=base['first_rank_audits'][rank]
            calls='native_python_calls' if family=='h3' else 'direct_python_calls'
            assert first[calls]==reference[calls] and first.get('eager_forwards')==reference.get('eager_forwards')
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
