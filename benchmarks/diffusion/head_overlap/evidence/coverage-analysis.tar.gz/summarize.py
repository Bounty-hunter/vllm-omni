"""Verify exited runs and compare both marginal and paired request samples."""

import hashlib
import json
import math
import random
import statistics
import subprocess
from pathlib import Path

root = Path("outputs/issue-10448-coverage-20261121")
repo = Path("worktrees/issue-10448-hcms")
manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
summary = dict(new_profiler_traces=False, metric="Full Omni.generate wall time; hashing/persistence excluded", runs={}, rows=[], controls=[])
source_blobs = {}
budgets = json.loads((repo / "benchmarks/diffusion/head_overlap/evidence/core-budget-summary.json").read_text(encoding="utf-8"))["core_cases"]


def interval(values):
    if len(set(values)) == 1:
        return [values[0], values[0]]
    rng = random.Random(10448)
    samples = sorted(statistics.median(rng.choices(values, k=len(values))) for _ in range(10000))
    return [samples[249], samples[9749]]


for name, item in manifest.items():
    folder = root / name
    for entry in item["files"]:
        assert hashlib.sha256((root / entry["file"]).read_bytes()).hexdigest() == entry["sha256"], entry["file"]
    source_sha = (folder / "source/code-sha.txt").read_text(encoding="utf-8").strip() if (folder / "source/code-sha.txt").exists() else None
    summary["runs"][name] = dict(exit_code=item["exit_code"], source_sha=source_sha, remote=item["remote"])
    if item["exit_code"] != "0":
        restoration = folder / "restoration-status.txt"
        summary["runs"][name]["restoration_status"] = restoration.read_text(encoding="utf-8") if restoration.exists() else "payload not completed; inspect checkout before reuse"
        print(f"FAILED {name}: exit {item['exit_code']}; not accepted as a completed performance case")
        continue
    assert not (folder / "restoration-status.txt").read_text(encoding="utf-8").strip(), name
    for line in (folder / "source/source.sha256").read_text(encoding="utf-8").splitlines():
        expected, remote = line.split(maxsplit=1)
        relative = "benchmarks/diffusion/head_overlap/" + remote.rsplit("/", 1)[-1]
        key = source_sha, relative
        if key not in source_blobs:
            source_blobs[key] = subprocess.check_output(["git", "-C", str(repo), "show", f"{source_sha}:{relative}"])
        blob = source_blobs[key]
        assert hashlib.sha256(blob).hexdigest() == expected, (name, relative)
    if name.startswith("core-"):
        config = json.loads((folder / "source/config.json").read_text(encoding="utf-8"))
        data = json.loads((folder / "results/rank0.json").read_text(encoding="utf-8"))
        assert [r["case"] for r in data["records"]] == config
        assert data["rounds"] == 30 and data["inner"] == 16
        for rank in range(data["world"]):
            peer_data = json.loads((folder / f"results/rank{rank}.json").read_text(encoding="utf-8"))
            assert peer_data["rank"] == rank and peer_data["world"] == data["world"]
            assert peer_data["code_sha"] == source_sha
            assert peer_data["script_sha256"] == hashlib.sha256(source_blobs[source_sha, "benchmarks/diffusion/head_overlap/core_budget.py"]).hexdigest()
            assert [r["case"] for r in peer_data["records"]] == config
            for peer_record in peer_data["records"]:
                assert peer_record["exact"]
                for values in peer_record["samples_max_rank_us"].values():
                    assert len(values) == 30 and all(math.isfinite(v) and v > 0 for v in values)
            assert [r["samples_max_rank_us"] for r in peer_data["records"]] == [r["samples_max_rank_us"] for r in data["records"]]
        for record in data["records"]:
            assert record["exact"]
            medians = record["median_max_rank_us"]
            case = record["case"]
            samples = record["samples_max_rank_us"]
            tax_samples = [b-a for a,b in zip(samples["attention_whole"],samples["attention_split_serial"])]
            core_samples = [a-b for a,b in zip(samples["core_whole_borrowed"],samples["core_overlap_borrowed"])]
            control = dict(run=name,source_sha=source_sha,case=case["id"],model_run=case["model_run"],request_case=case["request_case"],
                           calls_per_request=case["calls_per_request"],head_sizes=record["head_sizes"],
                           attention_whole_us=medians["attention_whole"],attention_split_us=medians["attention_split_serial"],
                           attention_first_us=medians["attention_first"],attention_last_us=medians["attention_last"],
                           splitting_tax_us=record["split_attention_tax_us"],
                           peer_forward_us=medians["peer_forward"],peer_reverse_us=medians["peer_reverse"],
                           isolated_peer_core_fraction_pct=100*record["peer_fraction_of_attention_plus_peer"],
                           core_owned_saving_us=record["measured_core_owned_saving_us"],
                           core_borrowed_saving_us=record["measured_core_borrowed_saving_us"],
                           ideal_hideable_peer_us=record["ideal_hideable_peer_us"],
                           ideal_hideable_minus_split_tax_us=record["ideal_hideable_minus_split_tax_us"],
                           core_borrowed_whole_us=medians["core_whole_borrowed"],
                           core_borrowed_overlap_us=medians["core_overlap_borrowed"],
                           core_borrowed_saved_vs_split_serial_us=record["measured_saving_vs_split_serial_us"],
                           paired_splitting_tax_median_us=statistics.median(tax_samples),
                           paired_splitting_tax_bootstrap95_us=interval(tax_samples),
                           paired_core_borrowed_saving_median_us=statistics.median(core_samples),
                           paired_core_borrowed_saving_bootstrap95_us=interval(core_samples),
                           attention_layout="packed varlen FA3" if case["padding"] else "front-joint dense FA3" if case["joint"] else "dense FA3",
                           caveat="Independent controlled QKV layout; no profiler. Request share requires an estimate using calls and E2E.")
            summary["controls"].append(control)
        summary["runs"][name].update(controls=len(data["records"]),world=data["world"])
        continue
    file = folder / "results/results.json"
    data = json.loads(file.read_text(encoding="utf-8"))
    config = json.loads((folder / "source/config.json").read_text(encoding="utf-8"))
    assert data["config"] == config
    assert not config["engine"]["enable_diffusion_pipeline_profiler"]
    parallel = config["engine"].get("parallel_config", config["engine"])
    world = parallel["ulysses_degree"]
    h3 = name.startswith("h3")
    audit_folder = folder / ("audit" if h3 else "results/audit")
    audits = {
        rank: [json.loads(line) for line in (audit_folder / (f"audit-rank{rank}.jsonl" if h3 else f"rank{rank}.jsonl")).read_text(encoding="utf-8").splitlines()]
        for rank in range(world)
    }
    for audit in audits.values():
        model = next(row for row in audit if row["kind"] == "model")
        if h3:
            assert model["fp8_modules"] == 260 and model["vae_world"] == 4
        elif config["engine"].get("quantization_config"):
            for component in config["engine"]["quantization_config"]:
                assert model["fp8_modules"].get(component, 0) > 0, (name, component)
        else:
            assert not any(model["fp8_modules"].values()), name
    summary["runs"][name]["rank0_model_audit"] = next(row for row in audits[0] if row["kind"] == "model")
    requested_vae = world if h3 else parallel["vae_patch_parallel_size"]
    vae_lines = [line for line in (folder/"run.log").read_text(encoding="utf-8").splitlines()
                 if "VAE patch parallelism is NOT enabled" in line or "in tile mode requires vae_use_tiling" in line]
    ignored_vae = any("NOT enabled" in line for line in vae_lines)
    if not h3:
        assert ignored_vae or any("automatically enabling it" in line for line in vae_lines)
    summary["runs"][name]["vae_parallel"] = dict(
        requested=requested_vae,
        patch_parallel_enabled=not ignored_vae,
        configured_parallel_size=1 if ignored_vae else requested_vae,
        evidence=vae_lines if not h3 else "All-rank model audit reports vae_world=4",
        caveat="Configured distributed VAE does not establish tile utilization on every frame/shape.",
    )
    summary["runs"][name].update(requests=len(data["records"]),results_sha256=hashlib.sha256(file.read_bytes()).hexdigest())
    for case in config["cases"]:
        variants = case.get("variants", config["variants"])
        geometries = None
        for rank, audit in audits.items():
            for variant, options in variants.items():
                audit_phase = "paired" if config["measurement"].get("paired_audit", True) else "correctness"
                request = next(row for row in audit if row.get("label") == f"{case['id']}-{audit_phase}-{variant}-i0")
                assert request["mode"] == "graph"
                if h3:
                    assert request["graph_exists"] and request["native_python_calls"] == 0
                    key = [[case["sampling"]["height"],case["sampling"]["width"]],options["chunks"],options["schedule"],options.get("head_partition")]
                    capture = next(row for row in audit if row.get("graph_key") == key)
                    assert capture["native_capture_calls"] == 50 and capture["eager_graph_bitwise_equal"]
                else:
                    assert request["direct_python_calls"] == request["fallbacks"] == 0
                    assert request["requested_head_partition"] == options.get("head_partition")
                    assert request["graph_stats"] and all(stat["replays"] > 0 for stat in request["graph_stats"].values())
                    warm = next(row for row in audit if row.get("label") == f"{case['id']}-warm-{variant}-i0")
                    assert {k:s["captures"] for k,s in request["graph_stats"].items()} == {k:s["captures"] for k,s in warm["graph_stats"].items()}
            if rank == 0:
                warm = next(row for row in audit if row.get("label") == f"{case['id']}-warm-serial1-i0")
                shapes = [(q, 0) for q in warm["qkv"]] if h3 else [(entry[0],entry[3]) for entry in warm["qkv_shapes"]]
                geometries = [dict(sequence_tokens=q[1]*world,joint_tokens=joint,heads_per_rank=q[2]//world,dim=q[3],world=world,packed=h3) for q,joint in shapes]
        records = [r for r in data["records"] if r["case"] == case["id"]]
        assert all(not r["profile"] and r["variant_config"] == variants[r["variant"]] for r in records)
        rounds = config["measurement"]["rounds"]
        assert len(records) == len(variants) * (rounds + config["measurement"]["warmups"] + 2)
        for seed in (42, 43, 44):
            seeded = [r for r in records if r["seed"] == seed]
            assert {r["variant"] for r in seeded} == set(variants)
            assert len({json.dumps([r["hashes"],r["shapes"],r["dtypes"]]) for r in seeded}) == 1
        measurements = {
            variant: {r["index"]: r["e2e_ms"] for r in records if r["phase"] == "paired" and r["variant"] == variant}
            for variant in variants
        }
        assert all(set(values) == set(range(rounds)) for values in measurements.values())
        baseline = measurements["serial1"]
        equal = measurements.get("equal")
        borrowed = measurements.get("serial_borrowed")
        serial_median = statistics.median(baseline.values())
        equal_median = statistics.median(equal.values()) if equal else None
        for variant, values in measurements.items():
            delta = [baseline[i] - values[i] for i in baseline]
            delta_equal = [equal[i] - values[i] for i in baseline] if equal else None
            delta_borrowed = [borrowed[i] - values[i] for i in baseline] if borrowed else None
            row = dict(
                run=name, case=case["id"], variant=variant, variant_config=variants[variant], rounds=rounds,
                actual_output_shapes=records[0]["shapes"], sampling=case["sampling"],
                median_ms=statistics.median(values.values()), min_ms=min(values.values()),max_ms=max(values.values()),
                reduction_vs_serial_pct=100*(serial_median-statistics.median(values.values()))/serial_median,
                reduction_vs_equal_pct=100*(equal_median-statistics.median(values.values()))/equal_median if equal else None,
                wins_vs_serial=sum(x > 0 for x in delta), wins_vs_equal=sum(x > 0 for x in delta_equal) if equal else None,
                paired_saved_vs_serial_median_ms=statistics.median(delta), paired_saved_vs_equal_median_ms=statistics.median(delta_equal) if equal else None,
                paired_saved_vs_serial_bootstrap95_ms=interval(delta), paired_saved_vs_equal_bootstrap95_ms=interval(delta_equal) if equal else None,
                paired_reduction_vs_serial_median_pct=statistics.median(100*(baseline[i]-values[i])/baseline[i] for i in values),
                samples_ms=list(values.values()), paired_saved_vs_serial_ms=delta, paired_saved_vs_equal_ms=delta_equal,
                seed_hashes={str(seed): next(r["hashes"] for r in records if r["seed"] == seed) for seed in (42,43,44)},
                communication_share=None,
                actual_attention_geometries=geometries,
                paired_saved_vs_borrowed_median_ms=statistics.median(delta_borrowed) if borrowed else None,
                paired_saved_vs_borrowed_bootstrap95_ms=interval(delta_borrowed) if borrowed else None,
                wins_vs_borrowed=sum(x > 0 for x in delta_borrowed) if borrowed else None,
                paired_saved_vs_borrowed_ms=delta_borrowed,
                reduction_vs_borrowed_pct=100*(statistics.median(borrowed.values())-statistics.median(values.values()))/statistics.median(borrowed.values()) if borrowed else None,
                selected_settings_same_as_serial=variants[variant] == variants["serial1"],
            )
            matched = [budget for budget in budgets if any(
                budget["world"] == geometry["world"] and budget["tokens"] == geometry["sequence_tokens"]
                and budget["joint"] == geometry["joint_tokens"] and budget["attention_heads"] == geometry["heads_per_rank"]
                for geometry in geometries
            )]
            if len(matched) == 1 and (h3 or name.startswith(("qwen", "flux"))):
                budget = matched[0]
                row["communication_share"] = dict(
                    source="Earlier isolated shape control, not a new request profile",case=budget["case"],
                    isolated_peer_core_fraction_pct=budget["core_peer_fraction_pct"],
                    estimated_peer_request_fraction_pct=budget["C_peer_us"]*budget["calls_per_request"]/10/serial_median,
                )
            summary["rows"].append(row)
            print(f"{name:14} {case['id']:25} {variant:10} {row['median_ms']:9.3f} ms; vs whole {row['reduction_vs_serial_pct']:+6.2f}%; paired {row['paired_saved_vs_serial_median_ms']:+8.2f} ms; wins {row['wins_vs_serial']}/{rounds}")
for row in summary["rows"]:
    base_run = row["run"].removesuffix("-confirm")
    if row["run"] == "h3-policy":
        base_run = "h3-policy"
    control = next((c for c in summary["controls"] if c["model_run"] == base_run and c["request_case"] == row["case"]), None)
    if control:
        baseline = next(r for r in summary["rows"] if r["run"] == row["run"] and r["case"] == row["case"] and r["variant"] == "serial1")
        peer = control["peer_forward_us"] + control["peer_reverse_us"]
        row["communication_share"] = dict(source="New isolated layout control; request fraction is an ESTIMATE, not in-request measurement",
                                         control=control["case"],isolated_peer_core_fraction_pct=control["isolated_peer_core_fraction_pct"],
                                         estimated_peer_request_fraction_pct=peer*control["calls_per_request"]/10/baseline["median_ms"])
summary["interval_note"] = "Descriptive 95% paired-round median bootstrap, 10000 resamples, seed 10448. Does not establish stationarity."
(root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
