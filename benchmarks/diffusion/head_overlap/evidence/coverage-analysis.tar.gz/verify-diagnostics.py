"""Verify diagnostic evidence and create a compact archive without image arrays."""

import hashlib
import json
import tarfile
from pathlib import Path

root = Path("outputs/issue-10448-coverage-20261121")
folder = root / "diagnostics"
manifest = json.loads((root / "diagnostics-manifest.json").read_text(encoding="utf-8"))
assert hashlib.sha256((root / "diagnostics.tar.gz").read_bytes()).hexdigest() == manifest["archive_sha256"]
for item in manifest["files"]:
    file = folder / item["file"]
    assert file.stat().st_size == item["bytes"]
    assert hashlib.sha256(file.read_bytes()).hexdigest() == item["sha256"], file
    if item["file"].startswith("scripts/"):
        local = Path("work/issue-10448-coverage-20261121") / file.name
        assert file.read_bytes() == local.read_bytes(), local
for name, run in manifest["runs"].items():
    assert (folder / name / "exit-code").read_text(encoding="utf-8").strip() == run["exit_code"]
    restoration = folder / name / "restoration-status.txt"
    assert not restoration.exists() or not restoration.read_text(encoding="utf-8").strip()
numeric = json.loads((folder / "small-numeric/numeric.json").read_text(encoding="utf-8"))["records"]
failures = [r for r in numeric if not r["eager_exact"] or not r["graph_exact"]]
assert len(numeric) == 27 and len(failures) == 6
assert all(r["tokens"] == 1056 and len(r["heads"]) == 2 for r in failures)
splitkv = json.loads((folder / "splitkv-numeric/splitkv.json").read_text(encoding="utf-8"))["records"]
assert len(splitkv) == 6
assert all(r["whole_auto_vs_fixed1_exact"] and not r["split_auto_exact"] and r["split_fixed1_exact"] for r in splitkv)
images = json.loads((folder / "full-model-r2/results/images.json").read_text(encoding="utf-8"))["records"]
large = [r for r in images if r["size"] == 1024]
assert all(r["exact"] for r in large if r["variant"] in ("serial1", "serial_borrowed"))
assert all(not r["exact"] for r in large if r["variant"] in ("equal", "even410"))
for variant in ("serial1", "serial_borrowed", "equal", "even410"):
    for seed in (42, 43, 44):
        rows = [r for r in large if r["variant"] == variant and r["seed"] == seed]
        assert rows and len({tuple(r["hashes"]) for r in rows}) == 1
summary = {
    "performance_acceptance": False,
    "numeric_cases": len(numeric), "numeric_nonexact_cases": failures,
    "splitkv_control": splitkv,
    "full_model_1024": [r for r in large if r["phase"] != "warm"],
    "full_model_fixed1_verified": False,
    "backend_default_changed": False,
    "small_h3_policy": "Original whole attention; no relaxed RGB tolerance.",
    "manifest": manifest,
}
(root / "diagnostics-summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
with tarfile.open(root / "diagnostics-compact.tar.gz", "w:gz") as archive:
    for item in manifest["files"]:
        if not item["file"].endswith(".npz"):
            archive.add(folder / item["file"], arcname=item["file"])
    archive.add(root / "diagnostics-manifest.json", arcname="diagnostics-manifest.json")
print(json.dumps({"verified_files": len(manifest["files"]), "numeric_exact": len(numeric)-len(failures),
                  "splitkv_fixed1_exact": len(splitkv), "compact_bytes": (root/"diagnostics-compact.tar.gz").stat().st_size}))
