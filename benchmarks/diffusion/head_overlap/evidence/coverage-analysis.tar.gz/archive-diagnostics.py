"""Archive completed diagnostics, including failures and the exact script copies."""

import hashlib
import json
import tarfile
from pathlib import Path

upload = Path("/tmp/codex-hcms-coverage-20261121")
runs = {
    "small-numeric": "hcms-10448-h3-small-numeric-20261121",
    "initial-driver-failure": "hcms-10448-h3-small-diagnostic-20261121",
    "full-model-r2": "hcms-10448-h3-small-diagnostic-r2-20261121",
    "splitkv-numeric": "hcms-10448-h3-splitkv-numeric-20261121",
}
manifest = {"runs": {}, "files": [], "script_hash_timing": "Recorded after completion; scripts were not changed during these jobs."}
archive_path = upload / "diagnostics.tar.gz"
with tarfile.open(archive_path, "w:gz") as archive:
    entries = []
    for name, directory in runs.items():
        root = Path("/data/dyy/logs") / directory
        assert (root / "exit-code").is_file(), root
        manifest["runs"][name] = {
            "remote": str(root),
            "exit_code": (root / "exit-code").read_text().strip(),
        }
        for file in sorted(root.rglob("*")):
            if file.is_file():
                entries.append((file, Path(name) / file.relative_to(root)))
    scripts = (
        "small-numeric.py", "numeric-launch.sh", "splitkv-numeric.py", "splitkv-launch.sh",
        "h3-small-diagnostic.py", "h3-small-diagnostic-r2.py",
        "h3-diagnostic-launch.sh", "h3-diagnostic-payload.sh",
        "h3-diagnostic-r2-launch.sh", "h3-diagnostic-r2-payload.sh", "remote-job.sh",
    )
    entries.extend((upload / name, Path("scripts") / name) for name in scripts)
    for file, relative in entries:
        assert file.stat().st_size < 30_000_000, file
        archive.add(file, arcname=relative.as_posix())
        manifest["files"].append({
            "file": relative.as_posix(), "bytes": file.stat().st_size,
            "sha256": hashlib.sha256(file.read_bytes()).hexdigest(),
        })
manifest["archive_sha256"] = hashlib.sha256(archive_path.read_bytes()).hexdigest()
archive_path.with_name("diagnostics-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"runs": manifest["runs"], "files": len(manifest["files"]),
                  "bytes": archive_path.stat().st_size, "sha256": manifest["archive_sha256"]}))
