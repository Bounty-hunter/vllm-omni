"""Publish completed broad comparisons and keep failed/diagnostic evidence explicit."""

import csv
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

root = Path("outputs/issue-10448-coverage-20261121")
bench = Path("worktrees/issue-10448-hcms/benchmarks/diffusion/head_overlap")
summary = json.loads((root/"summary.json").read_text(encoding="utf-8"))
required = {"flux","qwen","wan14b","wan14b-confirm","qwen-confirm","flux-confirm","h3-policy","core-sp2","core-sp4"}
assert required <= summary["runs"].keys()
assert all(summary["runs"][name]["exit_code"] == "0" for name in required)
expected_requests = {"flux":312,"qwen":260,"wan14b":156,"flux-confirm":444,
                     "qwen-confirm":370,"wan14b-confirm":407,"h3-policy":629}
for name, count in expected_requests.items():
    assert summary["runs"][name]["requests"] == count
for name in ("flux-confirm","qwen-confirm","wan14b-confirm","h3-policy","core-sp2","core-sp4"):
    assert summary["runs"][name]["source_sha"] == "cb8ab60059f7381cd02353de7c9538bb58bda148"
assert len(summary["controls"]) == 12
assert summary["runs"]["h3-small"]["exit_code"] == "1"
summary["accepted_requests"] = sum(expected_requests.values())
summary["accepted_cases"] = len({r["case"] for r in summary["rows"]})
summary["scope"] = "Explicit offline fixed-canvas CUDA graphs, batch/concurrency1; no production default or HTTP claim."
summary["policy"] = "Selected defaults to original whole settings. Only frozen cases override it. Small fallback does not claim uniform splitting is nonregressing."
summary["ownership"] = "Serial1 owns attention output. Serial_borrowed and split candidates share graph-scoped output slots. Compare to both whole controls."
summary["h3_small_limit"] = "The initial SP4/1024 split screen failed exact RGB. Whole-owned/borrowed agree; pure packed FA3 split arithmetic differs under auto SplitKV at1056. Fixed num_splits1 restores pure-attention equality. No backend default changed; small H3 selected stays whole."
evidence = bench/"evidence"
evidence.mkdir(exist_ok=True)
diagnostics = json.loads((root/"diagnostics-summary.json").read_text(encoding="utf-8"))
assert not diagnostics["full_model_fixed1_verified"] and not diagnostics["backend_default_changed"]
summary["diagnostic_evidence"] = {"summary":"coverage-diagnostics.json", "compact_archive":"coverage-diagnostics.tar.gz",
                                  "full_local_archive_sha256":diagnostics["manifest"]["archive_sha256"]}
(evidence/"coverage-summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
shutil.copyfile(root/"evidence.tar.gz",evidence/"coverage-raw.tar.gz")
(evidence/"coverage-manifest.json").write_bytes((root/"manifest.json").read_bytes().rstrip(b"\n")+b"\n")
shutil.copyfile(root/"diagnostics-summary.json",evidence/"coverage-diagnostics.json")
shutil.copyfile(root/"diagnostics-compact.tar.gz",evidence/"coverage-diagnostics.tar.gz")
with tarfile.open(evidence/"coverage-analysis.tar.gz","w:gz") as archive:
    for name in ("summarize.py","verify-diagnostics.py","publish.py","observe.py","archive-diagnostics.py","final-audit.sh"):
        archive.add(Path("work/issue-10448-coverage-20261121")/name,arcname=name)
archive_sha = hashlib.sha256((evidence/"coverage-raw.tar.gz").read_bytes()).hexdigest()
lines = [
    "Issue #10448: broad shape coverage and conservative selection, 2026-11-21",
    "",
    "Scope and method",
    summary["scope"],summary["policy"],summary["ownership"],
    "NVIDIA L20X, NV18 peers; torch2.14.0+cu130, vLLM0.34.0. No new profiler trace.",
    "FLUX.2-klein-4B is BF16 because the current FP8 path is unsupported.",
    "Qwen-Image-Edit-2511, Wan2.2-T2V-A14B and H3-Image use FP8 DiT linears with BF16 attention/CE.",
    "SP degrees: FLUX2, Qwen2, Wan-A14B4, H3-Image4 (encoder TP4).",
    "FLUX/Qwen REQUEST VAE2 but registry logs explicitly ignore it: these pipelines lack DistributedVaeMixin in this revision.",
    "Wan-A14B configures distributed tiled VAE4; H3-Image audits VAE world4. Tile utilization is not measured for every shape.",
    "Steps: FLUX4, Qwen8, Wan8, H3 six PDD steps. True CFG is1 for these cases.",
    "H3 reduced canvases explicitly set min_generation_area=None; this does not qualify small-canvas image quality.",
    "Screen:3 warmups,8 rotating/reversed rounds. Confirm:5 warmups,30 rounds. Both add seeds43/44.",
    "Variant order reverses only after a full rotation cycle, including even-sized variant sets.",
    "Confirmation audit I/O is excluded from paired requests; warm/post-correctness audits verify unchanged capture counts.",
    "All accepted request outputs match the whole reference bitwise at all three seeds.",
    f"Accepted complete requests: {summary['accepted_requests']}; unique accepted workload cases: {summary['accepted_cases']}.",
    "These totals exclude the failed H3-small screen and all numerical diagnostic requests.",
    "",
    "Selected confirmation results",
    "case | heads/rank | actual output | whole ms | selected ms | vs whole | vs borrowed whole | wins vs whole/borrowed | estimated peer/request",
]
selected = [r for r in summary["rows"] if r["variant"] == "selected"]
assert len(selected) == 17
small = [r for r in selected if r["selected_settings_same_as_serial"]]
assert len(small) == 8
assert all(r["paired_saved_vs_serial_bootstrap95_ms"][0] <= 0 <= r["paired_saved_vs_serial_bootstrap95_ms"][1] for r in small)
for row in selected:
    base = next(r for r in summary["rows"] if r["run"] == row["run"] and r["case"] == row["case"] and r["variant"] == "serial1")
    head_count = row["actual_attention_geometries"][0]["heads_per_rank"]
    options = row["variant_config"]
    weights = options.get("head_partition",[1]*options["chunks"])
    assert head_count%sum(weights)==0
    widths = [head_count*w//sum(weights) for w in weights]
    borrowed = "n/a" if row["reduction_vs_borrowed_pct"] is None else f"{row['reduction_vs_borrowed_pct']:+.2f}%"
    gain = "same whole settings (A/A)" if row["selected_settings_same_as_serial"] else f"{row['reduction_vs_serial_pct']:+.2f}%"
    peer = row["communication_share"]
    share = "not controlled" if peer is None else f"{peer['estimated_peer_request_fraction_pct']:.2f}%"
    borrowed_wins = "n/a" if row["wins_vs_borrowed"] is None else f"{row['wins_vs_borrowed']}/30"
    lines.append(f"{row['case']} | {widths} | {row['actual_output_shapes']} | {base['median_ms']:.3f} | {row['median_ms']:.3f} | {gain} | {borrowed} | {row['wins_vs_serial']}/30, {borrowed_wins} | {share}")
lines += ["", "Paired evidence (ms saved; descriptive95% paired bootstrap interval)"]
for row in selected:
    lines.append(f"{row['case']}: whole {row['paired_saved_vs_serial_median_ms']:.3f} {row['paired_saved_vs_serial_bootstrap95_ms']}; borrowed {row['paired_saved_vs_borrowed_median_ms']} {row['paired_saved_vs_borrowed_bootstrap95_ms']}; range {row['min_ms']:.3f}-{row['max_ms']:.3f}")
lines += [
    "",
    "Communication and splitting controls",
    "These are isolated CUDA-event controls,30 rounds x16 graph replays, maximum over participating ranks.",
    "C_peer includes peer forward/reverse and required fences; C_peer/(A_whole+C_peer) is an isolated core ratio.",
    "Request communication budget is only ESTIMATED as C_peer*calls/E2E. It is not all communication or an in-request profile.",
    "Declared QKV pitches are control layouts; actual model kernels may have additional cache/layout interactions.",
    "H3 controls use packed varlen FA3; the raw global dense entrypoint metadata does not describe H3's packed path.",
    "Whole-borrowed versus split-borrowed and whole-owned versus split-owned keep output ownership consistent.",
    "Small selected=whole controls still time an equal split for diagnosis; their split cost is not charged by the selected recipe.",
    "case | heads | A_whole us | C_peer us | core peer fraction | split tax us | estimated hideable us | same-borrowed core saving us",
]
for c in summary["controls"]:
    lines.append(f"{c['case']} | {c['head_sizes']} | {c['attention_whole_us']:.2f} | {c['peer_forward_us']+c['peer_reverse_us']:.2f} | {c['isolated_peer_core_fraction_pct']:.2f}% | {c['splitting_tax_us']:+.2f} | {c['ideal_hideable_peer_us']:.2f} | {c['core_borrowed_saving_us']:+.2f}")
lines += [
    "", "Interpretation and limits",
    "The two-group pipeline leaves the first forward exchange and final reverse exchange exposed. Total peer bytes are unchanged.",
    "For first-head fraction x, a simple hideable-time estimate is min(A0,(1-x)*F)+min(A1,x*R).",
    "F is the whole input exchange and R the whole output exchange. Fixed fence/copy costs and interference are omitted from that estimate.",
    "A smaller first group can cover a larger remaining input exchange if A0 is sufficiently long. QKV input and output traffic are asymmetric.",
    "Attention splitting also changes kernel tiling, scheduling waves and possibly SplitKV. Even widths are useful candidates, not a universal rule.",
    "Communication grows linearly with tokens while attention grows roughly quadratically. Larger is not monotonically better in percentage E2E gain.",
    "Small shapes retain the original whole settings. The A/A timing differences measure noise and must not be called optimization gains.",
    "All eight small/mid-size A/A paired bootstrap intervals span zero; their median-ratio differences range from -0.19% to +0.54%.",
    "This report freezes explicit cases; it does not implement or qualify a general production shape selector.",
    "Quantization affects DiT linear weights; attention and direct CE buffers remain BF16 in these experiments.",
    "The request budget excludes other communication such as encoder TP and VAE parallel exchanges.",
    "", "Small-shape precision limit", summary["h3_small_limit"],
          "The failed H3-small run is preserved with exit1 and clean restoration; it is excluded from accepted performance rows.",
          "The diagnostic's exit0 means successful diagnosis, not that every compared output was equal.",
          "No RGB tolerance was relaxed and no failed sample was removed from a performance average.",
          "The fixed num_splits experiment was only a pure-attention diagnostic; a full-model fixed1 repair is not claimed.",
          "The initial full-model diagnostic driver failed because its main guard was missing; the corrected r2 run completed.",
          "Diagnostic scripts, logs, hashes and numerical outputs are in coverage-diagnostics.tar.gz and coverage-diagnostics.json.",
          "Full diagnostic NPZ arrays remain in the remote diagnostic directories; their hashes are in the compact archive manifest.",
          "A full 20MB archive including NPZ arrays is retained locally at outputs/issue-10448-coverage-20261121/diagnostics.tar.gz.",
          "", "Evidence and source identities"]
for name,run in summary["runs"].items():
    lines.append(f"{name}: exit{run['exit_code']}, source {run['source_sha']}, {run['remote']}")
    if "vae_parallel" in run:
        lines.append(f"  VAE runtime/config audit: {json.dumps(run['vae_parallel'])}")
lines += [f"Raw archive SHA256: {archive_sha}",
          "Raw samples/configs/patches/exit codes are in evidence/coverage-raw.tar.gz; entry hashes in coverage-manifest.json.",
          "Complete screen and confirmation arrays, hashes, actual attention geometry, paired intervals and controls are in coverage-summary.json.",
          "Analysis and verification script copies are in coverage-analysis.tar.gz; rerun from the same workspace directory layout.",
          "No PR was submitted. AI assistance: Codex prepared code, measurements and analysis."]
(bench/"COVERAGE-RESULTS.txt").write_text("\n".join(lines)+"\n",encoding="utf-8",newline="\n")
with (root/"selected.csv").open("w",encoding="utf-8-sig",newline="") as stream:
    columns=["run","case","variant_config","median_ms","reduction_vs_serial_pct","reduction_vs_borrowed_pct","wins_vs_serial","wins_vs_borrowed","selected_settings_same_as_serial"]
    writer=csv.DictWriter(stream,fieldnames=columns,extrasaction="ignore")
    writer.writeheader()
    writer.writerows(selected)
