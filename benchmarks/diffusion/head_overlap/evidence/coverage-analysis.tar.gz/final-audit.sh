#!/usr/bin/env bash
[[ $(id -un) == dyy ]] || exit 1
shopt -s expand_aliases
source ~/.bashrc || exit $?
type DYY >/dev/null 2>&1 || exit 1
DYY || exit $?
set -euo pipefail
for repo in /data/dyy/code/vllm-omni-codex-hcms-wan5b-matrix-r6-20261120 /data/dyy/code/vllm-omni-codex-hcms-h3-sp4-confirm-20261120; do
  test -z "$(git -C "$repo" status --porcelain)"
  test "$(git -C "$repo" rev-parse HEAD)" = cb8ab60059f7381cd02353de7c9538bb58bda148
  printf 'CLEAN %s %s\n' "$repo" "$(git -C "$repo" rev-parse HEAD)"
done
test -z "$(python /tmp/codex-hcms-coverage-20261121/observe.py --active)"
