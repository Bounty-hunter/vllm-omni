"""Read progress and package only exited jobs; never accept live partials."""

import argparse
import hashlib
import json
import tarfile
from pathlib import Path

RUNS = {
    "flux": "hcms-10448-flux-coverage-20261121",
    "qwen": "hcms-10448-qwen-coverage-20261121",
    "wan14b": "hcms-10448-wan14b-coverage-20261121",
    "h3-small": "hcms-10448-h3-small-coverage-20261121",
    "flux-confirm": "hcms-10448-flux-coverage-confirm-20261121",
    "qwen-confirm": "hcms-10448-qwen-coverage-confirm-20261121",
    "wan14b-confirm": "hcms-10448-wan14b-coverage-confirm-20261121",
    "h3-policy": "hcms-10448-h3-policy-confirm-20261121",
    "core-sp2": "hcms-10448-core-coverage-sp2-20261121",
    "core-sp4": "hcms-10448-core-coverage-sp4-20261121",
}
parser = argparse.ArgumentParser()
parser.add_argument("--collect", action="store_true")
parser.add_argument("--active", action="store_true")
args = parser.parse_args()
manifest = {}
for name, directory in RUNS.items():
    root = Path("/data/dyy/logs") / directory
    if not root.exists():
        continue
    status = dict(run=name, state="running")
    result_file = root / "results/results.json"
    if result_file.exists():
        data = json.loads(result_file.read_text())
        records = data["records"]
        if records:
            status.update(requests=len(records), last={key: records[-1][key] for key in ("case", "variant", "phase", "index")})
    if (root / "exit-code").exists():
        status.update(state="completed", exit_code=(root / "exit-code").read_text().strip())
        manifest[name] = dict(remote=str(root), exit_code=status["exit_code"], files=[])
    if not args.active or status["state"] == "running":
        print(json.dumps(status), flush=True)
if args.collect:
    destination = Path("/tmp/codex-hcms-coverage-20261121/evidence.tar.gz")
    with tarfile.open(destination, "w:gz") as archive:
        for name, item in manifest.items():
            root = Path(item["remote"])
            for file in sorted(root.rglob("*")):
                if not file.is_file() or file.suffix == ".npz":
                    continue
                assert file.stat().st_size < 30_000_000, file
                relative = Path(name) / file.relative_to(root)
                archive.add(file, arcname=str(relative))
                item["files"].append(dict(file=str(relative), sha256=hashlib.sha256(file.read_bytes()).hexdigest()))
    destination.with_name("manifest.json").write_text(json.dumps(manifest, indent=2))
    print(json.dumps(dict(bytes=destination.stat().st_size,sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),runs=list(manifest))))
