#!/usr/bin/env bash
set -euo pipefail
run=$1
export PROBE_DIR="$PWD/benchmarks/diffusion/head_overlap"
export PYTHONPATH="$PROBE_DIR${PYTHONPATH:+:$PYTHONPATH}"
export LD_LIBRARY_PATH=/home/dyy/.local/lib/python3.12/site-packages/nvidia/cudnn/lib:${LD_LIBRARY_PATH:-}
mkdir -p "$run/source"
git rev-parse HEAD > "$run/source/code-sha.txt"
test -z "$(git status --porcelain)"
cp /tmp/codex-hcms-ci-20261121/core-rear.json "$run/source/config.json"
cp "$PROBE_DIR/core_budget.py" "$run/source/core_budget.py"
cp "$0" "$run/source/payload.sh"
nvidia-smi topo -m > "$run/topology.txt"
torchrun --standalone --nproc_per_node=2 "$PROBE_DIR/core_budget.py" \
  --cases "$run/source/config.json" --out "$run/results" --rounds 30 --inner 16
