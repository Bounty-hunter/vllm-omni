#!/usr/bin/env bash
set -euo pipefail
run=$1
export PROBE_DIR="$PWD/benchmarks/diffusion/head_overlap"
export PYTHONPATH="$PROBE_DIR${PYTHONPATH:+:$PYTHONPATH}"
export LD_LIBRARY_PATH=/home/dyy/.local/lib/python3.12/site-packages/nvidia/cudnn/lib:${LD_LIBRARY_PATH:-}
test -z "$(git status --porcelain)"
mkdir -p "$run/source"
git rev-parse HEAD > "$run/source/code-sha.txt"
cp "$0" "$run/source/payload.sh"
sha256sum "$PROBE_DIR/"*.py "$PROBE_DIR/"*.json > "$run/source/source.sha256"
nvidia-smi topo -m > "$run/topology.txt"
if [[ $2 == stress ]]; then
  file=vllm_omni/diffusion/attention/parallel/head_overlap.py
  cp "$file" "$run/source/head_overlap.py.before"
  restore_stress() { cp "$run/source/head_overlap.py.before" "$file"; git status --short > "$run/restoration-status.txt"; }
  trap restore_stress EXIT
  git apply --check "$PROBE_DIR/native-probe.patch"
  git apply "$PROBE_DIR/native-probe.patch"
  git diff --binary > "$run/source/integration.patch"
  for schedule in overlap-return overlap-staging; do
    torchrun --standalone --nproc_per_node=2 "$PROBE_DIR/graph_slot_stress.py" --schedule "$schedule"
  done
else
  cp "$PROBE_DIR/ci-core-staging.json" "$run/source/config.json"
  cp "$PROBE_DIR/core_budget.py" "$run/source/core_budget.py"
  torchrun --standalone --nproc_per_node=4 "$PROBE_DIR/core_budget.py" \
    --cases "$run/source/config.json" --out "$run/results" --rounds 15 --inner 8
fi
