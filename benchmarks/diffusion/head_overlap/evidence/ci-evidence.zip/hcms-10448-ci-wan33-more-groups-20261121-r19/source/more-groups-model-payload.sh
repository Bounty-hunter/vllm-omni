#!/usr/bin/env bash
set -euo pipefail
run=$1
model=$2
export PROBE_DIR="$PWD/benchmarks/diffusion/head_overlap"
mkdir -p "$run/source"
export HCMS_COPY_SUBMITTER="$run/source/copy_submitter.so"
started=$(date +%s%N)
c++ -O2 -std=c++17 -shared -fPIC "$PROBE_DIR/copy_submitter.cpp" -o "$HCMS_COPY_SUBMITTER"
finished=$(date +%s%N)
printf '%s\n' "$(( (finished - started) / 1000000 ))" > "$run/source/submitter-build-ms.txt"
cp "$PROBE_DIR/copy_submitter.cpp" "$run/source/copy_submitter.cpp"
cp "$0" "$run/source/more-groups-model-payload.sh"
sha256sum "$PROBE_DIR/copy_submitter.cpp" "$HCMS_COPY_SUBMITTER" > "$run/source/submitter.sha256"
bash /tmp/codex-hcms-ci-20261121/qwen21-r4-model-payload.sh "$run" "$model" \
  ci-wan33-more-groups.json whole 12
