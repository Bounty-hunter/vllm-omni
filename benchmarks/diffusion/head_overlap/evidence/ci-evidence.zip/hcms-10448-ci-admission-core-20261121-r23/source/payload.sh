#!/usr/bin/env bash
set -euo pipefail
run=$1
mode=$2
export PROBE_DIR="$PWD/benchmarks/diffusion/head_overlap"
export PYTHONPATH="$PROBE_DIR${PYTHONPATH:+:$PYTHONPATH}"
export LD_LIBRARY_PATH=/home/dyy/.local/lib/python3.12/site-packages/nvidia/cudnn/lib:${LD_LIBRARY_PATH:-}
mkdir -p "$run/source"
test -z "$(git status --porcelain)"
git rev-parse HEAD > "$run/source/code-sha.txt"
cp "$0" "$run/source/payload.sh"
cp "$PROBE_DIR/copy_submitter.cpp" "$run/source/copy_submitter.cpp"
export HCMS_COPY_SUBMITTER="$run/source/copy_submitter.so"
started=$(date +%s%N)
c++ -O2 -std=c++17 -shared -fPIC "$PROBE_DIR/copy_submitter.cpp" -o "$HCMS_COPY_SUBMITTER"
finished=$(date +%s%N)
printf '%s\n' "$(( (finished - started) / 1000000 ))" > "$run/source/submitter-build-ms.txt"
sha256sum "$PROBE_DIR/copy_submitter.cpp" "$HCMS_COPY_SUBMITTER" > "$run/source/submitter.sha256"
sha256sum "$PROBE_DIR/"*.py > "$run/source/source.sha256"
if [[ $mode == stress ]]; then
  files=(vllm_omni/diffusion/attention/parallel/head_overlap.py vllm_omni/diffusion/distributed/a2a_permute.py)
  for file in "${files[@]}"; do cp "$file" "$run/source/$(basename "$file").before"; done
  restore_admission() {
    for file in "${files[@]}"; do cp "$run/source/$(basename "$file").before" "$file"; done
    git status --short > "$run/restoration-status.txt"
  }
  trap restore_admission EXIT
  git apply --check "$PROBE_DIR/native-probe.patch"
  git apply "$PROBE_DIR/native-probe.patch"
  git diff --binary > "$run/source/integration.patch"
  torchrun --standalone --nproc_per_node=2 "$PROBE_DIR/graph_slot_stress.py" --schedule stage-gated
elif [[ $mode == core ]]; then
  cp "$PROBE_DIR/ci-core-admission-gate.json" "$run/source/config.json"
  torchrun --standalone --nproc_per_node=4 "$PROBE_DIR/core_budget.py" \
    --cases "$run/source/config.json" --out "$run/results" --rounds 30 --inner 8
else
  exit 2
fi
