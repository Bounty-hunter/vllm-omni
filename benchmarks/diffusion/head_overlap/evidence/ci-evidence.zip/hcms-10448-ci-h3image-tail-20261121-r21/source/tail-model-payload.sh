#!/usr/bin/env bash
set -euo pipefail
run=$1
kind=$2
config=$3
rounds=$4
model=${5:-}
export PROBE_DIR="$PWD/benchmarks/diffusion/head_overlap"
mkdir -p "$run/source"
export HCMS_COPY_SUBMITTER="$run/source/copy_submitter.so"
started=$(date +%s%N)
c++ -O2 -std=c++17 -shared -fPIC "$PROBE_DIR/copy_submitter.cpp" -o "$HCMS_COPY_SUBMITTER"
finished=$(date +%s%N)
printf '%s\n' "$(( (finished - started) / 1000000 ))" > "$run/source/submitter-build-ms.txt"
cp "$PROBE_DIR/copy_submitter.cpp" "$run/source/copy_submitter.cpp"
cp "$0" "$run/source/tail-model-payload.sh"
sha256sum "$PROBE_DIR/copy_submitter.cpp" "$HCMS_COPY_SUBMITTER" > "$run/source/submitter.sha256"
unset HCMS_CORE_EVENTS HCMS_FORCE_DIAGNOSTIC_SPLIT
case "$kind" in
  generic) bash /tmp/codex-hcms-ci-20261121/qwen21-r4-model-payload.sh "$run" "$model" "$config" whole "$rounds" ;;
  image) bash /tmp/codex-hcms-ci-20261121/h3image-tail-payload.sh "$run" "$config" "$rounds" ;;
  video) export HCMS_AUDIO_DETERMINISTIC=1
         bash /tmp/codex-hcms-ci-20261121/h3-payload.sh "$run" "$config" "$rounds" ;;
  *) exit 2 ;;
esac
