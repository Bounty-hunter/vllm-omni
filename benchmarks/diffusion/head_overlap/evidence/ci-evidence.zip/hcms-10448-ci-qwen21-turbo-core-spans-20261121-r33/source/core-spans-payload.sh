#!/usr/bin/env bash
set -euo pipefail
run=$1
export HCMS_CORE_EVENTS=1
export HCMS_FORCE_DIAGNOSTIC_SPLIT=1
export HCMS_CORE_EVENT_SCOPE=all-cores
mkdir -p "$run/source"
printf '%s\n' 'HCMS_CORE_EVENTS=1' 'HCMS_FORCE_DIAGNOSTIC_SPLIT=1' 'HCMS_CORE_EVENT_SCOPE=all-cores' > "$run/source/diagnostic-env.txt"
cp "$0" "$run/source/core-spans-payload.sh"
bash /tmp/codex-hcms-ci-20261121/qwen-turbo-payload.sh "$run" ci-qwen21-turbo-core-spans.json 4
