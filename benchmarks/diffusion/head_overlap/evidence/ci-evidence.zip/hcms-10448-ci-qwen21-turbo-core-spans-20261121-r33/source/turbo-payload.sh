#!/usr/bin/env bash
set -euo pipefail
run=$1
config=$2
rounds=$3
model=/data/dyy/logs/hcms-10448-qwen21-turbo-download-20261122/checkpoint
test "$(cat "$model/codex-ready")" = fc13ba1986fcb905854dc8de2f52eee395f49b5b
export PROBE_DIR="$PWD/benchmarks/diffusion/head_overlap"
export PYTHONPATH="$PROBE_DIR${PYTHONPATH:+:$PYTHONPATH}"
mkdir -p "$run/source"
cp "$model/codex-checkpoint-manifest.json" "$run/source/checkpoint-manifest.json"
cp "$model/model_index.json" "$run/source/model_index.json"
cp "$0" "$run/source/turbo-payload.sh"
export HCMS_COPY_SUBMITTER="$run/source/copy_submitter.so"
started=$(date +%s%N)
c++ -O2 -std=c++17 -shared -fPIC "$PROBE_DIR/copy_submitter.cpp" -o "$HCMS_COPY_SUBMITTER"
finished=$(date +%s%N)
printf '%s\n' "$(( (finished - started) / 1000000 ))" > "$run/source/submitter-build-ms.txt"
cp "$PROBE_DIR/copy_submitter.cpp" "$run/source/copy_submitter.cpp"
sha256sum "$PROBE_DIR/copy_submitter.cpp" "$HCMS_COPY_SUBMITTER" > "$run/source/submitter.sha256"
bash /tmp/codex-hcms-ci-20261121/qwen21-r4-model-payload.sh "$run" "$model" "$config" qwen21-blocks "$rounds"
python /tmp/codex-hcms-ci-20261121/check_qwen_turbo.py "$run"
