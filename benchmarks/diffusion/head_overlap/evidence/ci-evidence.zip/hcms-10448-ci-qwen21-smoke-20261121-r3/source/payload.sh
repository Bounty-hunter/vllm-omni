#!/usr/bin/env bash
set -euo pipefail
run=$1
model=$2
config=$3
adapter=$4
rounds=$5
export TMPDIR="/tmp/codex-hcms-coverage-${config%.json}-20261121"
export TRITON_CACHE_DIR="$TMPDIR/triton"
export TORCHINDUCTOR_CACHE_DIR="$TMPDIR/inductor"
mkdir -p "$TMPDIR" "$run/source"
export LD_LIBRARY_PATH=/home/dyy/.local/lib/python3.12/site-packages/nvidia/cudnn/lib:${LD_LIBRARY_PATH:-}
export PROBE_DIR="$PWD/benchmarks/diffusion/head_overlap"
export PYTHONPATH="$PROBE_DIR${PYTHONPATH:+:$PYTHONPATH}"
files=(vllm_omni/diffusion/attention/parallel/head_overlap.py
       vllm_omni/diffusion/distributed/a2a_permute.py
       vllm_omni/diffusion/worker/diffusion_model_runner.py)
if [[ $adapter == qwen21-blocks ]]; then files+=(vllm_omni/diffusion/models/qwen_image_21/qwen_image_21_transformer.py); fi
if [[ $adapter == hy15-blocks ]]; then files+=(vllm_omni/diffusion/models/hunyuan_video/hunyuan_video_15_transformer.py); fi
if [[ $adapter == qwen-blocks ]]; then files+=(vllm_omni/diffusion/models/qwen_image/qwen_image_transformer.py); fi
test -z "$(git status --porcelain)"
for file in "${files[@]}"; do cp "$file" "$run/source/$(basename "$file").before"; done
restore_probe() {
  for file in "${files[@]}"; do cp "$run/source/$(basename "$file").before" "$file"; done
  git status --short > "$run/restoration-status.txt"
}
trap restore_probe EXIT
git apply --check "$PROBE_DIR/native-probe.patch"
git apply "$PROBE_DIR/native-probe.patch"
git apply --check "$PROBE_DIR/model-probe.patch"
git apply "$PROBE_DIR/model-probe.patch"
if [[ $adapter == qwen-blocks ]]; then
  git apply --check "$PROBE_DIR/qwen-block-graph.patch"
  git apply "$PROBE_DIR/qwen-block-graph.patch"
fi
if [[ $adapter == hy15-blocks ]]; then
  git apply --check "$PROBE_DIR/hy15-block-graph.patch"
  git apply "$PROBE_DIR/hy15-block-graph.patch"
fi
if [[ $adapter == qwen21-blocks ]]; then
  git apply --check "$PROBE_DIR/qwen21-block-graph.patch"
  git apply "$PROBE_DIR/qwen21-block-graph.patch"
fi
git rev-parse HEAD > "$run/source/code-sha.txt"
git diff --binary > "$run/source/integration.patch"
sha256sum "$PROBE_DIR/"*.py "$PROBE_DIR/"*.json > "$run/source/source.sha256"
cp "$PROBE_DIR/$config" "$run/source/config.json"
cp "$0" "$run/source/payload.sh"
nvidia-smi topo -m > "$run/topology.txt"
cat /proc/loadavg > "$run/loadavg-start.txt"
export HCMS_LAZY_COUNTERS=1
export HCMS_MATRIX_AUDIT="$run/results/audit"
python "$PROBE_DIR/model_matrix.py" --model "$model" --config "$PROBE_DIR/$config" \
  --out "$run/results" --rounds "$rounds" --warmups 1
cat /proc/loadavg > "$run/loadavg-end.txt"
