#!/usr/bin/env bash
set -euo pipefail
run=$1
mode=$2
upload=/tmp/codex-hcms-ci-20261121
export PROBE_DIR="$PWD/benchmarks/diffusion/head_overlap"
export PYTHONPATH="$PROBE_DIR${PYTHONPATH:+:$PYTHONPATH}"
export LD_LIBRARY_PATH=/home/dyy/.local/lib/python3.12/site-packages/nvidia/cudnn/lib:${LD_LIBRARY_PATH:-}
test -z "$(git status --porcelain)"
mkdir -p "$run/source"
git rev-parse HEAD > "$run/source/code-sha.txt"
cp "$PROBE_DIR/copy_submitter.cpp" "$run/source/copy_submitter.cpp"
cp "$0" "$run/source/submitter-payload.sh"
export HCMS_COPY_SUBMITTER="$run/source/copy_submitter.so"
started=$(date +%s%N)
c++ -O2 -std=c++17 -shared -fPIC "$PROBE_DIR/copy_submitter.cpp" -o "$HCMS_COPY_SUBMITTER"
finished=$(date +%s%N)
printf '%s\n' "$(( (finished - started) / 1000000 ))" > "$run/source/submitter-build-ms.txt"
sha256sum "$PROBE_DIR/copy_submitter.cpp" "$HCMS_COPY_SUBMITTER" > "$run/source/submitter.sha256"
if [[ $mode == stress ]]; then
  files=(vllm_omni/diffusion/attention/parallel/head_overlap.py vllm_omni/diffusion/distributed/a2a_permute.py)
  for file in "${files[@]}"; do cp "$file" "$run/source/$(basename "$file").before"; done
  restore_submitter() {
    for file in "${files[@]}"; do cp "$run/source/$(basename "$file").before" "$file"; done
    git status --short > "$run/restoration-status.txt"
  }
  trap restore_submitter EXIT
  git apply --check "$PROBE_DIR/native-probe.patch"
  git apply "$PROBE_DIR/native-probe.patch"
  git diff --binary > "$run/source/integration.patch"
  sha256sum "$PROBE_DIR/"*.py > "$run/source/source.sha256"
  for schedule in overlap-return overlap-staging; do
    torchrun --standalone --nproc_per_node=2 "$PROBE_DIR/graph_slot_stress.py" --schedule "$schedule"
  done
elif [[ $mode == qwen ]]; then
  bash "$upload/qwen21-r4-model-payload.sh" "$run" /data/models/hub/Qwen-Image-2.1 \
    ci-qwen21-ref-confirm.json qwen21-blocks 30
elif [[ $mode == core ]]; then
  sha256sum "$PROBE_DIR/"*.py > "$run/source/source.sha256"
  cp "$PROBE_DIR/ci-core-staging.json" "$run/source/config.json"
  cp "$PROBE_DIR/core_budget.py" "$run/source/core_budget.py"
  torchrun --standalone --nproc_per_node=4 "$PROBE_DIR/core_budget.py" \
    --cases "$run/source/config.json" --out "$run/results" --rounds 15 --inner 8
else
  exit 2
fi
