"""Export matched logical CUDA-event spans; never call these kernel traces."""

import argparse
import csv
import json
import statistics
from collections import defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import Patch

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('run', type=Path)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
run, out = args.run, args.output
assert (run / 'exit-code').read_text().strip() == '0'
data = json.loads((run / 'results/results.json').read_text())
assert data['config']['core_event_diagnostic']
assert all(r['exact_matches_reference'] for r in data['records'])
records = {f"{r['case']}-{r['phase']}-{r['variant']}-i{r['index']}": r for r in data['records']}
rows = []
for path in sorted((run / 'results/audit').glob('rank*.jsonl')):
    for line in path.read_text().splitlines():
        audit = json.loads(line)
        if audit['kind'] != 'core_events':
            continue
        record = records[audit['label']]
        if record['phase'] != 'paired':
            continue
        for component, events in audit['components'].items():
            for event in events:
                t = event['offsets_us']
                assert t['begin'] == 0 and t['end'] > 0
                assert all(0 <= v <= t['end'] for v in t.values())
                n = len(event['heads'])
                for g in range(n):
                    assert t[f'F{g}0'] <= t[f'F{g}c'] <= t.get(f'F{g}b', t[f'F{g}1']) <= t[f'F{g}1']
                    assert all(t[f'{k}{g}0'] <= t[f'{k}{g}1'] for k in 'AR')
                attention = sum(t[f'A{g}1']-t[f'A{g}0'] for g in range(n))
                gap = sum(t[f'A{g}0']-t[f'A{g-1}1'] for g in range(1, n))
                front, tail = t['A00'], t['end']-t[f'A{n-1}1']
                assert abs(front+attention+gap+tail-t['end']) < 0.01
                rows.append(dict(component=component, variant=record['variant'], rank=audit['rank'],
                                 index=record['index'], layer=event['layer'], heads=event['heads'],
                                 total_us=t['end'], attention_us=attention, front_us=front, gap_us=gap, tail_us=tail,
                                 attention_segments_us=[t[f'A{g}1']-t[f'A{g}0'] for g in range(n)],
                                 copy_spans_us=[t[f'F{g}c']-t[f'F{g}0'] for g in range(n)],
                                 fence_spans_us=[t[f'F{g}1']-t.get(f'F{g}b', t[f'F{g}c']) for g in range(n)],
                                 offsets_us=t))
groups = defaultdict(list)
for row in rows:
    groups[row['component'], row['rank'], row['variant']].append(row)
summary = []
for (component, rank, variant), group in groups.items():
    assert len(group) == data['config']['measurement']['rounds']
    summary.append(dict(component=component, rank=rank, variant=variant, pairs=len(group),
                        **{field: statistics.mean(r[field] for r in group)
                           for field in ('total_us', 'attention_us', 'front_us', 'gap_us', 'tail_us')}))
limits = ('CUDA event spans for one layer and last component replay, with diagnostic forced partitions. '
          'External timing records perturb execution; these requests qualify no performance gain. '
          'Each core origin is independently zeroed; not a cross-rank absolute clock or kernel profiler trace.')
out.parent.mkdir(parents=True, exist_ok=True)
out.with_suffix('.json').write_text(json.dumps(dict(run=run.name, limits=limits, records=rows, summary=summary), indent=2)+'\n')
with out.with_suffix('.csv').open('w', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)

component = rows[0]['component']
variants = list(data['config']['variants'])
selected = [next(r for r in rows if r['component'] == component and r['rank'] == 0 and r['index'] == 1
                 and r['variant'] == variant) for variant in variants]
fig, axes = plt.subplots(len(selected), 1, figsize=(13, 2*len(selected)+1.7), layout='constrained')
colors = dict(attention='#315fa6', copies='#188f76', fence='#c34f56', wait='#a7abb4', reverse='#d28a22')
trace = []
for i, (axis, row) in enumerate(zip(axes, selected, strict=True)):
    t = row['offsets_us']
    def span(begin, end, lane, name, color):
        assert end >= begin
        axis.broken_barh([(begin, end-begin)], (lane-0.28, 0.56), facecolors=color)
        if end-begin > 28:
            axis.text((begin+end)/2, lane, name, color='white', ha='center', va='center', fontsize=8)
        trace.append(dict(name=f"{row['variant']} {name}", cat='logical CUDA event span', ph='X',
                          ts=begin, dur=end-begin, pid=i, tid=lane,
                          args=dict(layer=row['layer'], rank=0, pair_index=1, independently_zeroed=True)))
    for g in range(len(row['heads'])):
        span(t[f'A{g}0'], t[f'A{g}1'], 1, f'A{g}', colors['attention'])
        span(t[f'F{g}0'], t[f'F{g}c'], 0, f'F{g} copy', colors['copies'])
        b = t.get(f'F{g}b', t[f'F{g}c'])
        if b > t[f'F{g}c']:
            span(t[f'F{g}c'], b, 0, 'dependency', colors['wait'])
        span(b, t[f'F{g}1'], 0, f'F{g} fence', colors['fence'])
        span(t[f'R{g}0'], t[f'R{g}1'], 0, f'R{g}', colors['reverse'])
    axis.axvline(t['end'], color='#252a32', linewidth=1)
    axis.text(t['end']+10, 0.5, f"{t['end']:.1f} us", va='center', fontsize=9)
    axis.set_title(f"{row['variant']} | heads {row['heads']} | attention {row['attention_us']:.1f} us", loc='left')
    axis.set_yticks([1, 0], ['compute', 'peer stream'])
    axis.set_xlim(0, max(r['total_us'] for r in selected)+100)
    axis.set_ylim(-0.5, 1.5)
    axis.grid(axis='x', alpha=0.18)
    axis.spines[['top', 'right']].set_visible(False)
    axis.set_xlabel('Independent event offset per core (us)')
fig.suptitle('Qwen Image 2.1: 1536 x 1536 + reference | rank 0, layer 16, pair 1\nLogical CUDA-event spans, not a kernel trace', fontsize=13)
fig.legend(handles=[Patch(color=color, label=name) for name, color in colors.items()],
           loc='outside lower center', ncol=5, frameon=False)
for ext in ('svg', 'png'):
    fig.savefig(out.with_suffix('.'+ext), dpi=180)
out.with_suffix('.event-spans.trace.json').write_text(json.dumps(dict(traceEvents=trace, displayTimeUnit='us', limits=limits)))
for row in summary:
    print(json.dumps(row))
