"""Verify actual prefix attempts and publish the bounded symmetric-family trial."""
import csv
import json
import random
import statistics
from pathlib import Path


ROOT = Path('outputs/issue-10448-ci-20261121')
SUMMARY = json.loads((ROOT / 'summary.json').read_text())
RUNS = (
    'hcms-10448-ci-qwen21-symmetric-family-20261121-r37',
    'hcms-10448-ci-qwen21-symmetric-shapes-matrix-20261121-r38',
)


def paired_interval(values):
    rng = random.Random(10448)
    medians = sorted(statistics.median(rng.choices(values, k=len(values))) for _ in range(5000))
    return [medians[125], medians[4874]]


rows, audits, controls = [], [], []
for name in RUNS:
    run = ROOT / name
    assert (run / 'exit-code').read_text().strip() == '0', name
    result = json.loads((run / 'results/results.json').read_text())
    records = result['records']
    rank_rows = [[json.loads(line) for line in (run / f'results/audit/rank{rank}.jsonl').read_text().splitlines()]
                 for rank in range(4)]
    for case in result['config']['cases']:
        prefix = case['id']
        selections = {}
        for variant in ('serial1', 'previous', 'adaptive'):
            first = [next(r for r in items if r.get('label') == f'{prefix}-warm-{variant}-i0') for items in rank_rows]
            steady = [next(r for r in items if r.get('label') == f'{prefix}-correctness-{variant}-i0') for items in rank_rows]
            policies = [r['lazy_policies']['transformer/cond'] for r in first]
            reports = [p['reports'][0] for p in policies]
            reference = reports[0]
            assert all(r == reference for r in reports), (name, prefix, variant, 'rank decisions')
            assert not reference['diagnostic_forced']
            assert all(r['direct_python_calls'] == 96 and r['original_prefill_blocks'] == 32 for r in first)
            assert all(r['direct_python_calls'] == 0 and r['original_prefill_blocks'] == 32 for r in steady)
            assert all(r['real_eager_steps'] == {'transformer/blocks/cond': 2} for r in first)
            for r in steady:
                for key in ('timed_event_records', 'event_queries', 'sampling_host_syncs', 'captured_timer_records',
                            'all_gather_object', 'accelerator_sync', 'cuda_sync'):
                    assert r['execution_counters'][key] == 0, (name, variant, key)
                assert r['graph_stats']['transformer/cond']['replays'] == 5 + 31 * 7
            if variant == 'adaptive':
                assert reference['choices'] == [[8], [1, 6, 1], [2, 4, 2]]
                assert [len(s) for s in reference['raw_samples_max_rank_us']] == [8, 8, 8]
                assert reference['timed_prefix_calls'] == reference['allocated_sample_pairs'] == 24
                assert all(p['stats']['candidate_family'] == 'symmetric-ends' for p in policies)
                assert all(r['execution_counters']['event_queries'] == 24 and
                           r['execution_counters']['timed_event_records'] == 96 for r in first)
            selected = reference['selected']
            assert all(all(plan['heads'] == selected for plan in p['stats']['capture_plans'].values()) for p in policies)
            selections[variant] = selected
            paired_gains = [statistics.median(a - b for a, b in zip(reference['samples_max_rank_us'][0], values))
                            if values else None for values in reference['samples_max_rank_us'][1:]]
            warm = next(r['e2e_ms'] for r in records if r['case'] == prefix and r['variant'] == variant and r['phase'] == 'warm')
            audits.append(dict(run=name, case=prefix, variant=variant, choices=reference['choices'], selected=selected,
                               raw_counts=[len(s) for s in reference['raw_samples_max_rank_us']],
                               qualified_cycles=len(reference['samples_max_rank_us'][0]),
                               qualified_paired_gain_us=paired_gains,
                               host_submission_median_us=[statistics.median(s) if s else None
                                                          for s in reference['host_submission_max_rank_us']],
                               raw_core_median_us=[statistics.median(s) if s else None
                                                   for s in reference['raw_samples_max_rank_us']],
                               first_request_ms=warm,
                               prepare_rank_range_ms=[min(p['stats']['prepare_ms'] for p in policies),
                                                      max(p['stats']['prepare_ms'] for p in policies)],
                               finish_rank_range_ms=[min(p['stats']['finish_ms'] for p in policies),
                                                     max(p['stats']['finish_ms'] for p in policies)]))
        times = {variant: {r['index']: r['e2e_ms'] for r in records
                           if r['case'] == prefix and r['variant'] == variant and r['phase'] == 'paired'}
                 for variant in selections}
        assert all(set(values) == set(times['serial1']) for values in times.values())
        assert len(times['serial1']) == 30
        for variant in ('previous', 'adaptive'):
            row = next(r for r in SUMMARY['comparisons'] if r['run'] == name and r['case'] == prefix and r['variant'] == variant)
            additional = [times['previous'][i] - times[variant][i] for i in sorted(times[variant])]
            rows.append(dict(run=name, source_sha=row['source_sha'], case=prefix, variant=variant, selected=selections[variant], rounds=30,
                             whole_ms=row['baseline_ms'], variant_ms=row['adaptive_ms'],
                             reduction_pct=row['latency_reduction_pct'], whole_fallback=row['whole_fallback'],
                             paired_saving_ms=row['paired_saved_ms'], paired_95_ms=row['paired_saved_bootstrap95_ms'],
                             saving_vs_previous_median_ms=statistics.median(additional),
                             saving_vs_previous_95_ms=paired_interval(additional),
                             pure_p2p_window_estimated_request_ms=row['p2p_copy_window_estimate']['estimated_request_ms'],
                             pure_p2p_window_estimated_share_pct=row['p2p_copy_window_estimate']['estimated_request_pct'],
                             saving_fraction_of_p2p_estimate=row['p2p_copy_window_estimate']['saved_fraction']))

for c in SUMMARY['core_controls']:
    if 'symmetric-' not in c['run']:
        continue
    m = c['median_max_rank_us']
    controls.append(dict(run=c['run'], source_sha=c['source_sha'], case=c['case']['id'], heads=c['head_sizes'],
                         attention_whole_us=m['attention_whole'], attention_split_us=m['attention_split_serial'],
                         split_tax_us=c['split_attention_tax_us'], whole_core_us=m['core_whole_borrowed'],
                         overlap_core_us=m['core_overlap_borrowed'],
                         isolated_core_saving_us=m['core_whole_borrowed'] - m['core_overlap_borrowed']))
assert len(rows) == 6 and len(controls) == 9
large = next(r for r in rows if '2048x2048' in r['case'] and r['variant'] == 'adaptive')
large_control = next(c for c in controls if '2048-ref1' in c['case'] and c['heads'] == large['selected'])
large_budget = large['pure_p2p_window_estimated_request_ms']
large_saving = large['whole_ms'] - large['variant_ms']
large_prediction = large_control['isolated_core_saving_us'] * 224 / 1000
budget = dict(shape=2048, p2p_window_estimate_ms=large_budget, half_budget_ms=large_budget / 2,
              e2e_saving_ms=large_saving, isolated_core_saving_times_224_ms=large_prediction,
              cross_experiment_residual_ms=large_prediction - large_saving,
              caveat='Not an in-request decomposition: independent core controls and normal E2E requests differ. '
                     'The residual does not establish a slower outside-core kernel or a hardware cause.')
payload = dict(e2e=rows, prefix_audits=audits, core_controls=controls, large_budget=budget,
               qualification='A full rotated cycle requires all candidate starts pending after submission on every rank. '
                             'Zero qualified cycles are insufficient evidence, not proof of no graph benefit.',
               scope='Opt-in bounded family whole -> 1:x:1 -> 2:x:2. Default old two-group generator unchanged. '
                     'Three shapes, official Turbo 8 sigma/CFG1, FP8/SP4/VAE4 configured/ref1. '
                     'No new profiler, forward, candidate graph or per-layer wait. First request costs remain included.')
(ROOT / 'symmetric-ends-analysis.json').write_text(json.dumps(payload, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
with (ROOT / 'symmetric-ends-e2e.csv').open('w', newline='', encoding='utf-8-sig') as file:
    writer = csv.DictWriter(file, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
lines = [
    'Qwen-Image-2.1-Turbo：真实前缀中的对称三块候选尝试', '',
    '本轮候选：[8]、[1,6,1]、[2,4,2]。对同签名真实core旋转/反序执行；不是强制固定比例。',
    '每请求原生8步/CFG1/ref1，FP8、SP4，配置VAE4。1024/1536/2048各30对×3臂，共297完整请求；9项独立core控制。',
    '新家族opt-in；旧双块生成器仍是默认。候选数固定有界，只尝试边宽1/2，不宣称任意head数的最优搜索。',
    '不增加forward或候选图；选定后冻结capture。三seed输出逐位一致、多rank一致及稳态零探测已由完整verifier和本脚本复核。', '',
    '完整请求结果：正数为中位数时延降低；whole回退为A/A，不计overlap收益。',
    'case | arm | selected | whole ms | arm ms | 降低% | 配对节省95%区间ms | 纯P2P窗口估计占比% | 节省/该预算%',
]
for r in rows:
    fraction = r['saving_fraction_of_p2p_estimate']
    lines.append(f"{r['case']} | {r['variant']} | {r['selected']} | {r['whole_ms']:.3f} | {r['variant_ms']:.3f} | "
                 f"{r['reduction_pct']:+.3f} | {r['paired_95_ms']} | {r['pure_p2p_window_estimated_share_pct']:.3f} | "
                 + ('A/A' if fraction is None else f'{fraction * 100:.1f}'))
lines += ['', '与同run旧策略比较：配对节省正值为新家族更快；不同capture分组不能归因于纯调度。']
for r in rows:
    if r['variant'] == 'adaptive':
        lines.append(f"{r['case']} | median {r['saving_vs_previous_median_ms']:+.3f} ms | 95% {r['saving_vs_previous_95_ms']}")
lines += ['', '独立控制（µs）：attention拆分税与完整core节省；不能当成完整请求性能。',
          'case | heads | attention whole -> split | tax | whole core -> overlap core | core saving']
for c in controls:
    lines.append(f"{c['case']} | {c['heads']} | {c['attention_whole_us']:.2f} -> {c['attention_split_us']:.2f} | "
                 f"{c['split_tax_us']:+.2f} | {c['whole_core_us']:.2f} -> {c['overlap_core_us']:.2f} | "
                 f"{c['isolated_core_saving_us']:+.2f}")
lines += ['', '实际尝试/首次成本：raw每候选8次，合格轮要求所有候选及所有rank均已完整入队。',
          'case | arm | choices | raw counts | qualified | selected | 首请求ms | prepare rank range ms | finish rank range ms']
for a in audits:
    lines.append(f"{a['case']} | {a['variant']} | {a['choices']} | {a['raw_counts']} | {a['qualified_cycles']} | "
                 f"{a['selected']} | {a['first_request_ms']:.3f} | {a['prepare_rank_range_ms']} | {a['finish_rank_range_ms']}")
lines += ['',
    '1536三块的合格轮为0：有真实试错，但丢弃首个冷启动轮后，每轮至少一个候选/rank在主机提交完成前已开始执行，无法用这些eager观测可靠预测图。',
    '该轮三块候选主机提交中位数约1ms，与GPU core时长相近；不能移除资格检查、强制分组或把回退解释成三块无收益。',
    '形状差异与query-tile/SM轮次代理一致：按128 query tile和132 SM估算，1024/1536/2048为32/72/128 query tiles。',
    'whole的预测轮数为2/5/8；1+6+1为4/6/8；2+4+2为3/7/8。这里只是候选成本模型，未采集实际launch grid。',
    '2048的三块attention税明显较低；小尾块减少首发/末收暴露，但小attention能否盖住大块传输仍取决于实际时长。',
    '2048的7个合格轮中，1+6+1相对whole的配对节省中位数243.264us，2+4+2为285.504us，因此选择后者；不能用独立core的最佳值替换真实选择。',
    f"2048固定纯P2P窗口预算{large_budget:.3f}ms/request，50%目标{large_budget/2:.3f}ms；当前E2E省{large_saving:.3f}ms，仍差{large_budget/2-large_saving:.3f}ms。",
    f"同分组独立core省{large_control['isolated_core_saving_us']:.3f}us，乘224约{large_prediction:.3f}ms；与E2E差{large_prediction-large_saving:.3f}ms。",
    '这是跨实验外推差，不是模型内精确分解；不能把差额全归给投影/FFN、HBM/L2争用或CPU空泡。新家族尚未证明相对旧双块有额外E2E收益，未替换默认。',
    '首次prepare包含候选资源准备/分布式对齐，不是纯CPU开销；不同臂有编译/缓存/顺序偏差，不能把首请求差直接当探索税。',
    'P2P分母冻结为r31/r35对应布局的独立CE event窗口，排除barrier、stream wait及local staging，仍含marker/拷贝间间隙。',
    '未采新native profiler。总字节不减少；节省的是暴露的关键路径。保留全部负数、回退、旧对照及历史失败。',
]
(ROOT / 'SYMMETRIC-ENDS-RESULTS.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8', newline='\n')
print('PASS bounded family attempts, rank decisions/capture, call budget, steady zero probes; published 3 shapes / 297 requests / 9 controls')
for row in rows:
    print(row['case'], row['variant'], row['selected'], round(row['reduction_pct'], 3), row['paired_95_ms'])
