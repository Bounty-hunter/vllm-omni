"""Extract completed task artifacts only underneath the named output root."""
import argparse
import tarfile
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('archive', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
root = args.output.resolve()
with tarfile.open(args.archive, 'r:gz') as archive:
    for member in archive.getmembers():
        target = (root / member.name).resolve()
        if not target.is_relative_to(root):
            raise ValueError(f'Archive member escapes output directory: {member.name}')
    archive.extractall(root, filter='data')
print('EXTRACTED', args.archive, 'TO', root)
