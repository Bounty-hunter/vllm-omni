"""Verify completed CI-shape comparisons, including failed/interrupted runs."""
import argparse
import csv
import hashlib
import json
import random
import statistics
import subprocess
import sys
import zipfile
from collections import defaultdict
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, default=Path('outputs/issue-10448-ci-20261121'))
parser.add_argument('--repo', type=Path, default=Path('worktrees/issue-10448-hcms'))
args = parser.parse_args()
root, repo = args.root, args.repo
rows, requests, audit_rows, failed, cores = [], [], [], [], []
diagnostics, correctness_only, source_checks, execution_budgets = [], [], [], []
model_audits = []
source_cache = {}

# One git process keeps verification bounded as source revisions accumulate.
keys = set()
for run in root.glob('hcms-10448-ci-*-20261121-r*'):
    sha_file, manifest = run / 'source/code-sha.txt', run / 'source/source.sha256'
    if not sha_file.exists() or not manifest.exists():
        continue
    sha = sha_file.read_text().strip()
    for line in manifest.read_text().splitlines():
        _, path = line.split(maxsplit=1)
        if path.endswith('.py'):
            keys.add((sha, 'benchmarks/diffusion/head_overlap/' + Path(path).name))
    if (run / 'source/submitter.sha256').exists():
        keys.add((sha, 'benchmarks/diffusion/head_overlap/copy_submitter.cpp'))
ordered_keys = sorted(keys)
batch = subprocess.run(['git', '-C', str(repo), 'cat-file', '--batch'], check=True, capture_output=True,
                       input=''.join(f'{sha}:{path}\n' for sha, path in ordered_keys).encode()).stdout
offset = 0
for key in ordered_keys:
    end = batch.index(b'\n', offset)
    header = batch[offset:end].split()
    assert len(header) == 3 and header[1] == b'blob', (key, header)
    size = int(header[2])
    source_cache[key] = hashlib.sha256(batch[end+1:end+1+size]).hexdigest()
    offset = end + size + 2
assert offset == len(batch)


def verify_source(run, sha):
    manifest = run / 'source/source.sha256'
    if not manifest.exists():
        return
    checked = []
    for line in manifest.read_text().splitlines():
        digest, path = line.split(maxsplit=1)
        relative = 'benchmarks/diffusion/head_overlap/' + Path(path).name
        if not relative.endswith('.py'):
            continue
        key = (sha, relative)
        assert source_cache[key] == digest, (run, relative, sha)
        checked.append(relative)
    submitter = run / 'source/submitter.sha256'
    build = None
    if submitter.exists():
        artifacts = {}
        for line in submitter.read_text().splitlines():
            digest, path = line.split(maxsplit=1)
            name = Path(path).name
            assert name in ('copy_submitter.cpp', 'copy_submitter.so'), name
            artifact = run / 'source' / name
            assert artifact.exists() and hashlib.sha256(artifact.read_bytes()).hexdigest() == digest, artifact
            artifacts[name] = digest
        assert source_cache[sha, 'benchmarks/diffusion/head_overlap/copy_submitter.cpp'] == artifacts['copy_submitter.cpp']
        build_file = run / 'source/submitter-build-ms.txt'
        build = dict(sha256=artifacts, build_ms=int(build_file.read_text()) if build_file.exists() else None)
    source_checks.append(dict(run=run.name, source_sha=sha, verified_python_files=checked, copy_submitter=build))


def bootstrap(values):
    rng = random.Random(10448)
    medians = sorted(statistics.median(rng.choices(values, k=len(values))) for _ in range(5000))
    return [medians[125], medians[4874]]


def policies(audit):
    if audit.get('lazy_policy'):
        return {'blocks': audit['lazy_policy']}
    return audit.get('lazy_policies', {})


def invariant_policy(value):
    return value['stats'].get('schedule', 'stage-local'), [
        (r['signature'], r['choices'], r['selected'], r['samples_max_rank_us']) for r in value['reports']]


def tuples(value):
    return tuple(map(tuples, value)) if isinstance(value, list) else value


def request_cores(first, steady, rounds):
    result = []
    for component, policy in policies(first).items():
        if first.get('native_python_calls') is not None:
            replays = steady['denoising_graph_replays']
        else:
            delta = steady['graph_stats'][component]['replays'] - first['graph_stats'][component]['replays']
            assert delta % (rounds + 1) == 0
            replays = delta // (rounds + 1)
        for report in policy['reports']:
            key = hashlib.sha256(repr(tuples(report['signature'])).encode()).hexdigest()[:16]
            plan = policy['stats']['capture_plans'][key]
            result.append(dict(component=component, signature=report['signature'], heads=report['selected'],
                               calls_per_request=replays * plan['calls']))
    return result


for run in sorted(root.glob('hcms-10448-ci-*-20261121-r*')):
    interrupted = (run / 'interrupted.json').exists()
    status = 'interrupted' if interrupted else (run / 'exit-code').read_text().strip()
    result = run / 'results/results.json'
    sha_file = run / 'source/code-sha.txt'
    if sha_file.exists():
        verify_source(run, sha_file.read_text().strip())
    if status != '0' or not result.exists():
        if (run / 'results/rank0.json').exists() and status == '0':
            data = json.loads((run / 'results/rank0.json').read_text())
            for record in data['records']:
                assert record['exact']
                assert all(len(v) == data['rounds'] for v in record['samples_max_rank_us'].values())
                assert all(statistics.median(record['samples_max_rank_us'][n]) == m
                           for n, m in record['median_max_rank_us'].items())
                rank_copy_samples = []
                for rank in range(data['world']):
                    other = json.loads((run / f'results/rank{rank}.json').read_text())
                    peer = next(r for r in other['records'] if r['case'] == record['case'])
                    assert peer['exact'] and peer['samples_max_rank_us'] == record['samples_max_rank_us']
                    if record.get('copy_event_windows'):
                        windows = peer['copy_event_windows']
                        assert windows['samples_max_rank_us'] == record['copy_event_windows']['samples_max_rank_us']
                        assert all(statistics.median(values) == windows['median_max_rank_us'][key]
                                   for key, values in windows['samples_max_rank_us'].items())
                        for key, values in windows['samples_local_us'].items():
                            assert len(values) == data['rounds'] and all(value > 0 for value in values)
                        rank_copy_samples.append(windows['samples_local_us'])
                if rank_copy_samples:
                    total = [max(samples['peer_forward'][i] + samples['peer_reverse'][i]
                                 for samples in rank_copy_samples) for i in range(data['rounds'])]
                    record['copy_event_windows']['combined_whole_max_rank_us'] = statistics.median(total)
                    record['copy_event_windows']['combined_whole_samples_max_rank_us'] = total
                cores.append(dict(run=run.name, source_sha=data['code_sha'], **record))
        elif status == '0' and any(tag in run.name for tag in ('staging-stress-', 'submitter-stress-', 'admission-stress-', 'defer-stress-', 'input-stress-')):
            log = (run / 'run.log').read_text(errors='replace')
            evidence = [line for line in log.splitlines() if line.startswith('SLOT_STRESS ')]
            assert len(evidence) == (4 if any(tag in run.name for tag in ('admission-stress-', 'defer-stress-', 'input-stress-')) else 8)
            assert all('bitwise exact' in line for line in evidence)
            correctness_only.append(dict(run=run.name, evidence=evidence))
        elif status == '0' and any(tag in run.name for tag in ('eventapi-', 'memops-', 'graph-priority-capability-')):
            log = (run / 'run.log').read_text(errors='replace')
            evidence = [line for line in log.splitlines()
                        if line.startswith(('MEMOPS_CAPABILITY ', '{"external":', 'GRAPH_PRIORITY_CAPABILITY '))]
            assert evidence, run
            probe_sha = None
            if 'graph-priority-capability-' in run.name:
                values = [json.loads(line.removeprefix('GRAPH_PRIORITY_CAPABILITY ')) for line in evidence]
                assert {v['requested_compute_priority'] for v in values} == {0, -1}
                assert all(v['exact'] and v['uses_node_priority'] == bool(v['instantiate_flags'] & 8) for v in values)
                digest, path = (run / 'source/probe.sha256').read_text().strip().split(maxsplit=1)
                assert hashlib.sha256((run / 'source' / Path(path).name).read_bytes()).hexdigest() == digest
                probe_sha = digest
            correctness_only.append(dict(run=run.name, evidence=evidence, probe_sha256=probe_sha, accepted_performance=False))
        else:
            log_path = next((run / name for name in ('run.log', 'sequence.log', 'bootstrap.log')
                             if (run / name).exists()), None)
            log = log_path.read_text(errors='replace') if log_path else ''
            errors = [line for line in log.splitlines() if line.startswith(('TypeError:', 'ValueError:', 'AssertionError:', 'RuntimeError:'))]
            failed.append(dict(run=run.name, status=status, harness_sequence='sequence-' in run.name,
                               final_error=errors[-1:] or [f'See {log_path.name if log_path else "remote logs"}']))
        continue
    data = json.loads(result.read_text())
    records = data['records']
    assert records and not any(r['profile'] for r in records)
    source_sha = (run / 'source/code-sha.txt').read_text().strip()
    config = data['config']
    if config.get('correctness_diagnostic') or config.get('core_event_diagnostic'):
        assert all('exact_matches_reference' in r for r in records)
        diagnostics.append(dict(run=run.name, purpose=config['measurement']['purpose'], records=records,
                                exact_failures=sum(not r['exact_matches_reference'] for r in records),
                                accepted_performance=False))
        continue
    grouped = defaultdict(list)
    for r in records:
        grouped[r['case'], r['variant'], r['phase']].append(r)
        requests.append(dict(run=run.name, source_sha=source_sha, **r))
    audits = defaultdict(dict)
    models = {}
    paths = list((run / 'results/audit').glob('rank*.jsonl')) + list((run / 'audit').glob('audit-rank*.jsonl'))
    assert paths, run
    for path in paths:
        for line in path.read_text().splitlines():
            a = json.loads(line)
            if a['kind'] == 'model':
                models[str(a['rank'])] = a
                model_audits.append(dict(run=run.name, **a))
                if isinstance(a['fp8_modules'], dict):
                    configured = config['engine']['quantization_config']
                    assert all(a['fp8_modules'][name] > 0 for name in configured)
                else:
                    assert a['fp8_modules'] == 260 and a['vae_world'] == 4
                    assert a['min_generation_area'] is None
                    if a.get('video_pipeline'):
                        assert a['audio_decoder_deterministic']
            if a['kind'] == 'attention_capability':
                assert a['active_strategy'] == 'UlyssesParallelAttention' and not a['use_sync']
                assert a['backend'] == 'FLASH_ATTN' and a['dtype'] == 'torch.bfloat16'
            if a['kind'] == 'request':
                assert a.get('fallbacks', 0) == 0
                audits[a['label']][str(a['rank'])] = a
                audit_rows.append(dict(run=run.name, **a))
    assert models
    assert all(a['fp8_modules'] == models['0']['fp8_modules'] for a in models.values())
    if config.get('checkpoint', {}).get('repo') == 'Qwen/Qwen-Image-2.1-Turbo':
        checkpoint = json.loads((run / 'source/checkpoint-manifest.json').read_text())
        index = json.loads((run / 'source/model_index.json').read_text())
        assert checkpoint['revision'] == config['checkpoint']['revision']
        assert len(index['sample_sigmas']) == 8
        assert all(model['sample_sigmas'] == index['sample_sigmas'] for model in models.values())
    cross = {}
    for r in records:
        key = r['case'], r['seed']
        signature = r['hashes'], r['shapes'], r['dtypes']
        assert key not in cross or cross[key] == signature, (run, key)
        cross[key] = signature
    for case in config['cases']:
        case_id = case['id']
        base = sorted(grouped[case_id, 'serial1', 'paired'], key=lambda r: r['index'])
        assert base
        assert {r['seed'] for r in records if r['case'] == case_id} == {42, 43, 44}
        first, steady = {}, {}
        learned_variants = [v for v, spec in config['variants'].items()
                            if spec.get('real_prefix') and grouped[case_id, v, 'paired']]
        assert 'serial1' in learned_variants and 'adaptive' in learned_variants, (run, learned_variants)
        for variant in learned_variants:
            warm = grouped[case_id, variant, 'warm']
            correctness = sorted(grouped[case_id, variant, 'correctness'], key=lambda r: r['index'])
            assert len(warm) == 1 and len(correctness) == 2
            first[variant] = audits[f'{case_id}-warm-{variant}-i0']
            steady[variant] = audits[f'{case_id}-correctness-{variant}-i0']
            assert set(first[variant]) == set(steady[variant])
            assert set(models) == set(first[variant])
            reference = policies(first[variant]['0'])
            assert reference
            for rank, a in first[variant].items():
                current = policies(a)
                assert list(current) == list(reference)
                for name, p in current.items():
                    assert invariant_policy(p) == invariant_policy(reference[name]), (case_id, rank, name)
                    assert p['stats']['control_collectives'] == policies(steady[variant][rank])[name]['stats']['control_collectives']
                    plans = p['stats']['capture_plans']
                    assert sorted(tuple(r['selected']) for r in p['reports']) == sorted(tuple(v['heads']) for v in plans.values())
                    assert all(v['overlap_branch'] == (v['chunks'] > 1) for v in plans.values())
                    if variant == 'serial1':
                        assert all(v['chunks'] == 1 for v in plans.values())
                    layers = sum(v['calls'] for v in plans.values())
                    bodies = 3 if a.get('native_python_calls') is not None or 'qwen21' in case_id else 4
                    assert p['stats']['core_calls'] == bodies * layers, (run, case_id, name, rank)
                    eager_steps = a.get('real_eager_steps', {})
                    actual_prefix_steps = sum(eager_steps.values()) if isinstance(eager_steps, dict) else eager_steps
                    reused = actual_prefix_steps == 0
                    if not reused:
                        assert actual_prefix_steps == 2 * len(current)
                    for report in p['reports']:
                        key = hashlib.sha256(repr(tuples(report['signature'])).encode()).hexdigest()[:16]
                        assert report['discovery_calls'] == report['sampling_pass_calls'] == plans[key]['calls']
                        assert report['timed_prefix_calls'] <= 24
                    execution_budgets.append(dict(run=run.name, case=case_id, variant=variant, rank=rank,
                                                  component=name, layers=layers,
                                                  first_python_bodies=0 if reused else bodies,
                                                  reused_graph=reused,
                                                  graph_origin_python_bodies=bodies,
                                                  real_prefix_calls=0 if reused else 2,
                                                  capture_records=0 if reused else 1,
                                                  validation_replays=0 if reused else a.get('validation_replays', int(bodies == 4)),
                                                  sync_debug_bodies=0 if reused else int(bodies == 4),
                                                  timed_event_records=p['stats']['event_records'],
                                                  prepare_ms=p['stats']['prepare_ms'], finish_ms=p['stats']['finish_ms']))
                counters = steady[variant][rank]['execution_counters']
                assert counters['timed_event_records'] == counters['captured_timer_records'] == 0
                assert counters['event_queries'] == counters['sampling_host_syncs'] == 0
                # H3 video agrees on conditioning errors once per request in
                # its original pipeline, independently of attention learning.
                existing_metadata_gathers = int(case_id.startswith('h3video-'))
                assert counters['all_gather_object'] == existing_metadata_gathers, (run.name, case_id, variant, rank, counters)
                assert steady[variant][rank].get('direct_python_calls', steady[variant][rank].get('native_python_calls')) == 0
                assert all(v == 0 for v in steady[variant][rank].get('eager_forwards', {}).values())
                assert first[variant][rank]['execution_counters']['sampling_host_syncs'] == 0
        for variant in learned_variants:
            if variant == 'serial1':
                continue
            auto = sorted(grouped[case_id, variant, 'paired'], key=lambda r: r['index'])
            assert len(base) == len(auto) and all(a['index'] == b['index'] and a['seed'] == b['seed']
                                                for a, b in zip(base, auto, strict=True))
            for rank, audit in steady[variant].items():
                for counter in ('accelerator_sync', 'cuda_sync', 'tensor_item', 'all_gather_object', 'all_reduce',
                                'event_records', 'timed_event_records', 'sampling_host_syncs',
                                'captured_timer_records', 'event_queries'):
                    # Whole-reference smoke arms can leave the original
                    # Ulysses prefill workspace cold for the following baseline.
                    # Require no added API calls; retain both raw counts below.
                    assert audit['execution_counters'][counter] <= steady['serial1'][rank]['execution_counters'][counter], (
                        run.name, case_id, variant, rank, counter)
            selected = {name: [r['selected'] for r in p['reports']] for name, p in policies(first[variant]['0']).items()}
            whole = all(len(heads) == 1 for values in selected.values() for heads in values)
            # The same signature/whole plan shares its output slot across both arms.
            if whole:
                for rank in first[variant]:
                    for name, p in policies(first[variant][rank]).items():
                        assert p['stats']['capture_plans'] == policies(first['serial1'][rank])[name]['stats']['capture_plans']
            before = statistics.median(r['e2e_ms'] for r in base)
            after = statistics.median(r['e2e_ms'] for r in auto)
            differences = [a['e2e_ms'] - b['e2e_ms'] for a, b in zip(base, auto, strict=True)]
            interval = bootstrap(differences)
            rows.append(dict(run=run.name, case=case_id, variant=variant,
                         schedule=config['variants'][variant]['schedule'], source_sha=source_sha, model=data['engine']['model'],
                         ci_source=config.get('ci_source'), requested=case['sampling'], actual_output_shapes=base[0]['shapes'],
                         rounds=len(base), baseline_ms=before, adaptive_ms=after,
                         latency_reduction_pct=(before - after) / before * 100,
                         paired_saved_ms=statistics.median(differences), paired_saved_bootstrap95_ms=interval,
                         faster_pairs=sum(v > 0 for v in differences), selected=selected, whole_fallback=whole,
                         first_baseline_ms=grouped[case_id, 'serial1', 'warm'][0]['e2e_ms'],
                         first_adaptive_ms=grouped[case_id, variant, 'warm'][0]['e2e_ms'],
                         core_occurrences=request_cores(first[variant]['0'], steady[variant]['0'], len(base)),
                         steady_api_counters={rank: dict(baseline=steady['serial1'][rank]['execution_counters'],
                                                        variant=a['execution_counters'])
                                              for rank, a in steady[variant].items()},
                         interpretation='Whole fallback: A/A, not overlap gain' if whole else
                         'Paired CI crosses zero: gain unconfirmed' if interval[0] <= 0 else
                         'Positive paired CI; independent long confirmation still needed' if len(base) < 30 else
                         'This independent 30-pair run supports a gain'))


def core_geometry(record):
    case = record['case']
    # Strides within batch one, including fused V, must match exactly.
    strides = [[0, *s[1:]] for s in record['qkv_strides']]
    joints = [(shape, [0, *stride[1:]]) for shape, stride in
              zip(record.get('joint_shapes') or [], record.get('joint_strides') or [], strict=True)]
    return record['qkv_shape'], strides, joints, case.get('joint_strategy', 'front'), case.get('padding', 0)


def observed_geometry(signature):
    _, _, qkv, metadata = signature
    md = dict(metadata[1]) if metadata else {}
    joints = [md.get('joint_' + field) for field in ('query', 'key', 'value')]
    joints = [(v[0], v[1]) for v in joints if v is not None]
    padding = md.get('packed_padding')
    pad = qkv[0][0][1] * signature[1] - dict(padding[1])['q_length'] if padding else 0
    return qkv[0][0], [v[1] for v in qkv], joints, md.get('joint_strategy', 'front'), pad


for row in rows:
    if row['case'].startswith('qwen21-turbo-'):
        assert sum(v['calls_per_request'] for v in row['core_occurrences']) == 224
    components = []
    for occurrence in row['core_occurrences']:
        geometry = observed_geometry(occurrence['signature'])
        matched = [c for c in cores if core_geometry(c) == geometry]
        if not matched:
            components.append(dict(**occurrence, matched=False))
            continue
        # Freeze the communication denominator to the observed-signature/r20
        # controls established before later schedule ablations. Do not move the
        # target when another schedule's isolated control is added.
        control = max(matched, key=lambda c: (
            c['case'].get('observed_signature') == occurrence['signature'],
            'core-tail-block-' in c['run'],
            -int(c['run'].rsplit('-r', 1)[-1]), c['case']['id']))
        tax_controls = [c for c in matched if len(c['head_sizes']) > 1 and c['head_sizes'] == occurrence['heads']]
        tax_control = max(tax_controls, key=lambda c: int(c['run'].rsplit('-r', 1)[-1])) if tax_controls else None
        medians = control['median_max_rank_us']
        components.append(dict(component=occurrence['component'], matched=True,
                               calls_per_request=occurrence['calls_per_request'],
                               control_run=control['run'], control_case=control['case']['id'],
                               control_sha=control['source_sha'], control_partition=control['head_sizes'],
                               peer_forward_us=medians['peer_forward'], peer_reverse_us=medians['peer_reverse'],
                               split_attention_tax_us=tax_control['split_attention_tax_us'] if tax_control else None,
                               split_tax_control=None if tax_control is None else dict(
                                   run=tax_control['run'], case=tax_control['case']['id'],
                                   partition=tax_control['head_sizes'], source_sha=tax_control['source_sha'])))
    complete = all(v['matched'] for v in components)
    share = (sum((v['peer_forward_us'] + v['peer_reverse_us']) * v['calls_per_request']
                 for v in components) / row['baseline_ms'] / 10) if complete else None
    row['communication'] = dict(estimated_request_pct=share, components=components,
                                pure_p2p=False,
                                scope='LEGACY peer-exchange envelope INCLUDING peer fences and stream dependencies. '
                                      'Not a pure P2P denominator. Isolated geometry controls times actual graph '
                                      'core occurrences, not an in-request measurement. Qwen2.1 excludes original prefill.')
    row['saving_as_fraction_of_estimated_communication'] = (
        row['latency_reduction_pct'] / share if share and not row['whole_fallback'] else None)
    copy_components = []
    for occurrence in row['core_occurrences']:
        matched = [c for c in cores if c.get('copy_event_windows') and
                   c['case'].get('observed_signature') == occurrence['signature']]
        if len(matched) > 1:
            raise AssertionError('Select and document one fixed CE-only control before adding replications')
        if not matched:
            copy_components.append(dict(component=occurrence['component'], matched=False))
            continue
        control = matched[0]
        copy_components.append(dict(component=occurrence['component'], matched=True,
                                    calls_per_request=occurrence['calls_per_request'], control_run=control['run'],
                                    control_sha=control['source_sha'], control_case=control['case']['id'],
                                    peer_copy_window_us=control['copy_event_windows']['combined_whole_max_rank_us']))
    copy_complete = bool(copy_components) and all(c['matched'] for c in copy_components)
    copy_ms = (sum(c['peer_copy_window_us'] * c['calls_per_request'] / 1000 for c in copy_components)
               if copy_complete else None)
    row['p2p_copy_window_estimate'] = dict(
        estimated_request_ms=copy_ms,
        estimated_request_pct=copy_ms / row['baseline_ms'] * 100 if copy_ms is not None else None,
        saved_fraction=(row['baseline_ms']-row['adaptive_ms']) / copy_ms
                       if copy_ms and not row['whole_fallback'] else None,
        components=copy_components,
        scope='Isolated CE-only event windows, excluding barriers, stream waits and local staging. '
              'Includes marker/inter-copy scheduling overhead; not memcpy kernel-busy union or in-request share. '
              'F and R are measured separately, summed per rank/round, then maximum rank and median rounds. '
              'Qwen2.1 original prefill is excluded.')

ablations = []
for index, before in enumerate(rows):
    for after in rows[index+1:]:
        if ((before['run'], before['case'], before['selected']) !=
                (after['run'], after['case'], after['selected']) or before['schedule'] == after['schedule']):
            continue
        pairs = []
        for variant in (before['variant'], after['variant']):
            pairs.append(sorted((r for r in requests if r['run'] == before['run'] and r['case'] == before['case']
                                 and r['variant'] == variant and r['phase'] == 'paired'), key=lambda r: r['index']))
        differences = [a['e2e_ms']-b['e2e_ms'] for a,b in zip(*pairs, strict=True)]
        ablations.append(dict(run=before['run'], case=before['case'], selected=before['selected'],
                              baseline_variant=before['variant'], variant=after['variant'],
                              baseline_schedule=before['schedule'], schedule=after['schedule'],
                              rounds=len(differences), baseline_ms=before['adaptive_ms'], after_ms=after['adaptive_ms'],
                              latency_reduction_pct=(before['adaptive_ms']-after['adaptive_ms'])/before['adaptive_ms']*100,
                              paired_saved_ms=statistics.median(differences),
                              paired_saved_bootstrap95_ms=bootstrap(differences),
                              whole_fallback=before['whole_fallback']))


def csv_file(name, values):
    if not values:
        return
    keys = list(dict.fromkeys(k for r in values for k in r))
    with (root / name).open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=keys)
        writer.writeheader()
        writer.writerows({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v for k, v in r.items()}
                         for r in values)


csv_file('all-comparisons.csv', rows)
csv_file('all-schedule-ablations.csv', ablations)
csv_file('all-requests.csv', requests)
csv_file('all-audits.csv', audit_rows)
csv_file('model-audits.csv', model_audits)
csv_file('failed-or-interrupted.csv', failed)
csv_file('execution-budgets.csv', execution_budgets)
csv_file('all-core-controls.csv', [dict(run=c['run'], source_sha=c['source_sha'], case=c['case'],
                                       partition=c['head_sizes'], metric=metric, median_max_rank_us=median,
                                       samples_max_rank_us=c['samples_max_rank_us'][metric])
                                  for c in cores for metric, median in c['median_max_rank_us'].items()])
summary = dict(comparisons=rows, failed_or_interrupted=failed, core_controls=cores, requests=len(requests),
               schedule_ablations=ablations,
               correctness_diagnostics=diagnostics, correctness_only=correctness_only,
               source_checks=source_checks, execution_budgets=execution_budgets,
               model_audits=model_audits,
               verified='Outputs/seeds/ranks/actual capture plans/steady zero core timers and Python calls checked.')
(root / 'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
print('PASS', len(rows), 'comparisons;', len(requests), 'requests;', len(failed), 'failed/interrupted;', len(cores), 'core controls')
for r in rows:
    print(r['case'], f"{r['baseline_ms']:.3f}->{r['adaptive_ms']:.3f} ms", f"{r['latency_reduction_pct']:+.3f}%", r['selected'],r['interpretation'])
