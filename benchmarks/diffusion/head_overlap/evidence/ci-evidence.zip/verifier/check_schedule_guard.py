"""Check invalid schedules without importing a CUDA runtime or executing cores."""
import ast
from pathlib import Path
from types import SimpleNamespace

source = Path('worktrees/issue-10448-hcms/benchmarks/diffusion/head_overlap/schedule_probe.py')
tree = ast.parse(source.read_text())
nodes = [node for node in tree.body if
         (isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'VARIANTS' for t in node.targets))
         or (isinstance(node, ast.FunctionDef) and node.name == 'run')]
token = object()
namespace = {'ORIGINAL_CALL': lambda plan: token}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), 'exec'), namespace)
for variant in ('overlap-input', 'overlap-return', 'overlap-staging'):
    try:
        namespace['run'](SimpleNamespace(chunks=2, overlap=False), variant)
    except ValueError as error:
        assert str(error) == 'Staging overlap requires an overlapping plan'
    else:
        raise AssertionError(f'{variant} accepted an unsafe non-overlapping multi-group plan')
assert namespace['run'](SimpleNamespace(chunks=1, overlap=False), 'overlap-input') is token
print('PASS three invalid multi-group staging schedules rejected before device access; whole fallback preserved')
