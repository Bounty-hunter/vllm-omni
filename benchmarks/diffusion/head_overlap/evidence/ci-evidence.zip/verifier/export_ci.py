"""Publish strict comparisons and retain every historical experiment stage."""
import csv,hashlib,json,shutil,zipfile
from pathlib import Path
root=Path('outputs/issue-10448-ci-20261121')
summary=json.loads((root/'summary.json').read_text())
lines=[
 'Attention通算重叠：CI/常见shape与调度优化的完整结果',
 '',
 '硬件：NVIDIA L20X，NV18；batch/concurrency=1；离线完整generate请求，不含HTTP/视频mux。',
 'attention BF16/FA3，DiT FP8；Wan/H3 VAE4。Qwen2.1使用DistributedAutoencoderKLQwenImage21并配置VAE4；未采集逐请求瓦片分配。',
 '此前旧Qwen/FLUX的VAE2配置被registry忽略；不能把该限制套到Qwen2.1，也不能把配置度数当每张小图的活跃瓦片数。',
 '真实DiT调用一发现布局，调用二的前24个同签名core比较whole与一个候选。每层只执行一次并进入后续计算。',
 '两个真实调用替代原有预热机会；capture记录、同步检查及验证replay按adapter分别计数。稳态直接replay，无探测事件/查询/采样等待。',
 'H3与generic保留一次验证replay；Qwen2.1 block adapter不添加辅助sync probe或验证replay，后续真实步骤replay已capture的图。',
 '多段为指定候选实验，默认CPU候选生成器仍只生成两段；不是通用的2/3/4段自动选择器。',
 'H3视频所有对照臂启用确定性音频解码：cudnn benchmark=False,deterministic=True。原始A/A波形不逐位一致的失败仍保留。',
 'H3 original参考是eager block loop+whole direct CE；Qwen/Hy reference_whole参考才是原始Ulysses。',
 '正值=同一run/case内中位数时延降低；whole回退的正负波动是A/A，不能算overlap收益。',
 '通信估计仅含attention-core peer exchange，使用完全匹配QKV/joint布局的孤立控制×实际图core次数/E2E。',
 'Qwen2.1估计不含原始prefill；不含text encoder/VAE通信，不是请求内测量；孤立各段中位数不可当作精确可加的关键路径。',
 '总通信字节未减少；优化减少暴露时间。纯attention拆分税仅在控制分组与实际capture分组一致时列出。',
 '首请求含事件、资源准备、可能慢候选及编译成本。warm是完整请求的脚本标签，不是辅助forward；首请求顺序有缓存偏差，不是纯探索税。',
 '',
 f"本轮验证：{len(summary['comparisons'])}条比较，{summary['requests']}个正常完整请求，{len(summary['core_controls'])}条完整core控制，{len(summary['failed_or_interrupted'])}批失败/中断。",
 '比较条数包含同场景复测和不同方案，不是独立shape数；失败sequence与其失败子任务分别留痕，不重复当作数值错误。',
 '',
 '本轮结论',
 'H3-Image 4K的2+10+2在独立30对中提升3.89%，旧双块同run为3.24%；512/1024保留whole。',
 'Wan33的1+2+6+1，独立30对stage-local提升3.83%；另一12对为4.69%。全部复测均保留，不能只挑较高值。',
 'Wan33把非末块本地回传移到comm后，30对相同分组的额外配对节省区间跨零；预取约束也未证实E2E额外收益。',
 '邻近1+1+7+1未超过同run的1+2+6+1，未替换现有候选。简化轮次模型不证明实际launch grid。',
 'H3视频1024/107f的尾块方案提升3.38%（8对），约为匹配通信估计的49%；512视频旧双块更好。',
 'Qwen2.1 1536/ref1启用host submitter后独立30对提升2.66%；旧独立复核曾回退whole，两个结果均保留。',
 '“节省>=通信占比50%”在部分短轮次结果中达到点估计，尚未稳定达成，更不适用于所有case。',
 '独立API实验读取默认torch图exec flags=1，未开启UseNodePriority(8)；compute priority=-1仍如此。未据此宣称优先级调度收益。',
 '',
 '全部完整请求比较（每项均保留；1对smoke不算稳定性能结论）',
 'run | case | variant/schedule | 对数 | whole ms | 方案 ms | 时延下降% | 估计通信占比% | 节省/通信估计% | 实际分组 | 95%配对节省区间ms | 结论',
]
for r in summary['comparisons']:
 comm=r['communication']['estimated_request_pct']
 fraction=r['saving_as_fraction_of_estimated_communication']
 heads=';'.join(k+':'+','.join('+'.join(map(str,h)) for h in v) for k,v in r['selected'].items())
 interval=','.join(f'{x:.3f}' for x in r['paired_saved_bootstrap95_ms'])
 lines.append(f"{r['run']} | {r['case']} | {r['variant']}/{r['schedule']} | {r['rounds']} | {r['baseline_ms']:.3f} | {r['adaptive_ms']:.3f} | {r['latency_reduction_pct']:+.3f} | "+
              ('未匹配' if comm is None else f'{comm:.2f}')+' | '+('A/A或未匹配' if fraction is None else f'{fraction*100:.1f}')+
              f" | {heads} | [{interval}] | {r['interpretation']}")
lines += ['', '相同capture分组的纯调度对比（不混入切分比例变化）',
          'run | case | baseline schedule -> schedule | ms -> ms | 配对节省中位数ms | 配对95%区间ms']
for r in summary['schedule_ablations']:
 lines.append(f"{r['run']} | {r['case']} | {r['baseline_schedule']} -> {r['schedule']} | "+
              f"{r['baseline_ms']:.3f} -> {r['after_ms']:.3f} | {r['paired_saved_ms']:.3f} | {r['paired_saved_bootstrap95_ms']}")
lines += ['', '首形状完整请求（单次观测，包含建图/编译，受运行顺序影响）',
          'run | case | variant | whole首请求ms | 方案首请求ms']
for r in summary['comparisons']:
 lines.append(f"{r['run']} | {r['case']} | {r['variant']} | {r['first_baseline_ms']:.3f} | {r['first_adaptive_ms']:.3f}")
lines += ['', '完整core控制：纯attention拆分税与调度收益分开',
          'run | case | heads | A whole/split us | whole/overlap core us（共享输出槽） | F+R us | 纯attention拆分税us | attention调用数 | forward/final peer fence数']
for c in summary['core_controls']:
 m=c['median_max_rank_us']
 lines.append(f"{c['run']} | {c['case']['id']} | {'+'.join(map(str,c['head_sizes']))} | {m['attention_whole']:.2f}/{m['attention_split_serial']:.2f} | "+
              f"{m['core_whole_borrowed']:.2f}/{m['core_overlap_borrowed']:.2f} | {m['peer_forward']+m['peer_reverse']:.2f} | {c['split_attention_tax_us']:+.2f} | "+
              f"{c.get('attention_calls','旧记录未分列')} | {c.get('forward_peer_fences','未分列')}/{c.get('final_peer_fences','未分列')}")
lines += ['', '附加调度控制（同一core case内对比；与上表不同指标名全部保留在all-core-controls.csv）',
          'run | case | metric | us']
for c in summary['core_controls']:
 for metric,value in c['median_max_rank_us'].items():
  if metric.startswith(('core_stage-gated_', 'core_overlap-return_', 'core_overlap-staging_')):
   lines.append(f"{c['run']} | {c['case']['id']} | {metric} | {value:.2f}")
lines += ['', '失败/中断（均保留原始日志；不计入性能收益）']
for f in summary['failed_or_interrupted']:
 lines.append(f"{f['run']} | {f['status']} | {'; '.join(f['final_error'])}")
lines += ['', '精度/诊断任务（含已知失败；不计性能收益）']
for d in summary['correctness_diagnostics']:
 lines.append(f"{d['run']} | requests={len(d['records'])}, exact_failures={d['exact_failures']} | {d['purpose']}")
for d in summary['correctness_only']:
 lines.append(f"{d['run']} | correctness/capability-only | {'; '.join(d['evidence'])}")
lines += ['', '本轮代码与证据',
          'all-comparisons.csv：全部方案时延、配对区间、通信估计来源及实际分组。',
          'all-requests.csv：逐请求shape/dtype/hash/时延；all-audits.csv：所有rank的执行计数与策略。',
          'execution-budgets.csv：首次调用体数/事件/prepare/finish毫秒；summary.json含源码及C++构建哈希校验。',
          'ci-evidence.zip保留本轮日志、配置、集成patch及rank审计；诊断大视频字节在远端留存并记录路径/hash。',
          '历史阶段分别保留，不能混作同一实现的独立样本。以下附录包含先前所有结果。', '']
(root/'CI-RESULTS.txt').write_text('\n'.join(lines).rstrip()+'\n',encoding='utf-8',newline='\n')
archive=root/'ci-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  if not p.is_file() or p.suffix in ('.zip','.gz','.npz') or p.name in ('ALL-RESULTS.txt', 'sha256.json'):continue
  z.write(p,p.relative_to(root).as_posix())
 for name in ('summarize.py','export_ci.py'):
  z.write(Path('work/issue-10448-ci-20261121')/name,'verifier/'+name)
allfile=root/'ALL-RESULTS.txt'
allfile.write_text((root/'CI-RESULTS.txt').read_text(encoding='utf-8')+
 '\n\n===== 先前真实前缀26场景/1660请求 =====\n\n'+Path('outputs/issue-10448-prefix-20261121/PREFIX-RESULTS.txt').read_text(encoding='utf-8')+
 '\n\n===== 更早所有实验阶段 =====\n\n'+Path('outputs/issue-10448-all-tests-20261121/ALL-TESTS.txt').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
with zipfile.ZipFile(root/'all-tests-updated.zip','w',zipfile.ZIP_STORED) as z:
 for p in (allfile,archive,Path('outputs/issue-10448-prefix-20261121/prefix-tests.zip'),Path('outputs/issue-10448-all-tests-20261121/all-tests.zip')):
  z.write(p,p.name)
print('Exported',len(summary['comparisons']),'comparisons, bytes=',(root/'all-tests-updated.zip').stat().st_size)
