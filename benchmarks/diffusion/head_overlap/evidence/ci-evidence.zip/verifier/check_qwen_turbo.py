"""Verify the pinned Turbo checkpoint and its effective runtime sampling grid."""
import json
import sys
from pathlib import Path

run = Path(sys.argv[1])
config = json.loads((run / 'source/model_index.json').read_text())
manifest = json.loads((run / 'source/checkpoint-manifest.json').read_text())
assert manifest['repo'] == 'Qwen/Qwen-Image-2.1-Turbo'
assert manifest['revision'] == 'fc13ba1986fcb905854dc8de2f52eee395f49b5b'
assert len(config['sample_sigmas']) == 8
models = []
for path in sorted((run / 'results/audit').glob('rank*.jsonl')):
    for line in path.read_text().splitlines():
        audit = json.loads(line)
        if audit['kind'] == 'model':
            assert audit['sample_sigmas'] == config['sample_sigmas'], audit
            models.append(audit)
assert {r['rank'] for r in models} == {0, 1, 2, 3}
data = json.loads((run / 'results/results.json').read_text())
assert data['records'] and all(r['exact_matches_reference'] for r in data['records'])
assert {r['seed'] for r in data['records']} == {42, 43, 44}
assert all(c['sampling']['num_inference_steps'] == 8 and c['sampling']['true_cfg_scale'] == 1
           for c in data['config']['cases'])
print('PASS pinned Qwen 2.1 Turbo, all-rank native sigma grid, CFG1 and three-seed byte equality;',
      len(data['records']), 'complete requests')
