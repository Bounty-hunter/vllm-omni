"""Account for every core within the last actual decode-graph replay."""
import argparse
import csv
import json
import statistics
from collections import defaultdict
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('run', type=Path)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
assert (args.run / 'exit-code').read_text().strip() == '0'
data = json.loads((args.run / 'results/results.json').read_text())
assert data['config']['core_event_diagnostic'] and all(r['exact_matches_reference'] for r in data['records'])
labels = {f"{r['case']}-{r['phase']}-{r['variant']}-i{r['index']}": r for r in data['records']}
cores, rows = [], []
for path in sorted((args.run / 'results/audit').glob('rank*.jsonl')):
    for line in path.read_text().splitlines():
        audit = json.loads(line)
        if audit['kind'] != 'core_events':
            continue
        request = labels[audit['label']]
        if request['phase'] != 'paired':
            continue
        for component, events in audit['components'].items():
            assert len(events) == 32
            events = sorted(events, key=lambda e: e['component_offset_us'])
            span = events[0]['component_span_us']
            previous_end = 0
            for event in events:
                start, duration = event['component_offset_us'], event['offsets_us']['end']
                assert event['component_span_us'] == span
                assert start >= previous_end - 0.1 and start+duration <= span+0.1
                assert set(event['offsets_us']) == {'begin', 'end'}
                assert event['offsets_us']['begin'] == 0 and duration > 0
                previous_end = start+duration
                cores.append(dict(component=component, rank=audit['rank'], variant=request['variant'],
                                  index=request['index'], layer=event['layer'], heads=event['heads'],
                                  component_offset_us=start, core_us=duration))
            total = sum(e['offsets_us']['end'] for e in events)
            rows.append(dict(component=component, rank=audit['rank'], variant=request['variant'],
                             index=request['index'], component_us=span, cores_us=total,
                             other_component_us=span-total, cores=32,
                             external_records_per_component=66))
groups = defaultdict(list)
for row in rows:
    groups[row['component'], row['rank'], row['variant']].append(row)
critical = defaultdict(list)
for row in rows:
    critical[row['component'], row['variant'], row['index']].append(row)
for (component, variant, index), peers in critical.items():
    assert len(peers) == 4
    selected = max(peers, key=lambda r: r['component_us'])
    groups[component, 'max_component_rank', variant].append(selected)
summary = []
for (component, rank, variant), samples in groups.items():
    assert len(samples) == data['config']['measurement']['rounds']
    summary.append(dict(component=component, rank=rank, variant=variant, pairs=len(samples),
                        **{key:statistics.mean(r[key] for r in samples)
                           for key in ('component_us','cores_us','other_component_us')}))
limits = ('One actual last decode replay per request; all32 cores, equal two external records per core '
          'and one equal pair around the component. Diagnostic forced partitions qualify no normal gain. '
          'Other-component time includes projections, FFN, elementwise work and device scheduling gaps. '
          'The maximum-rank row uses the same rank for all phase values. Scaling last-step results to '
          'all seven decode calls is an estimate, not an exact full-request sum.')
args.out.parent.mkdir(parents=True, exist_ok=True)
result = dict(run=args.run.name, limits=limits, requests=rows, cores=cores, summary=summary)
args.out.with_suffix('.json').write_text(json.dumps(result, indent=2)+'\n')
for suffix, values in (('-requests.csv', rows), ('-cores.csv', cores)):
    with args.out.with_name(args.out.name+suffix).open('w',encoding='utf-8-sig',newline='') as stream:
        writer = csv.DictWriter(stream,fieldnames=list(values[0]))
        writer.writeheader()
        writer.writerows(values)
for row in summary:
    print(json.dumps(row))
