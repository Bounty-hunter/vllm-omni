"""Publish measured budgets with their scopes and unresolved differences."""
import json
from pathlib import Path

import matplotlib.pyplot as plt

root = Path('outputs/issue-10448-ci-20261121')
summary = json.loads((root/'summary.json').read_text())
rows = [r for r in summary['comparisons'] if 'qwen21-turbo-' in r['run']]
control = next(c for c in summary['core_controls'] if c['run'].endswith('-r31'))
copy = control['copy_event_windows']['median_max_rank_us']
whole_copy = copy['peer_forward']+copy['peer_reverse']
split_copy = sum(copy[name] for name in ('peer_forward_first','peer_forward_last','peer_reverse_first','peer_reverse_last'))
linear_exposed = 3/8*copy['peer_forward']+5/8*copy['peer_reverse']
chunk_exposed = copy['peer_forward_first']+copy['peer_reverse_last']
spans = json.loads((root/'qwen-turbo-all-core-spans.json').read_text())
phases = {r['variant']:r for r in spans['summary'] if r['rank']=='max_component_rank'}
base, serial, overlap = (phases[name] for name in ('serial1','serial_split','adaptive'))
core_saving = base['cores_us']-overlap['cores_us']
other_growth = overlap['other_component_us']-base['other_component_us']
component_saving = base['component_us']-overlap['component_us']
anchor = next(r for r in rows if 'turbo-matrix-' in r['run'] and '1536x1536' in r['case'])
normal_saving = anchor['baseline_ms']-anchor['adaptive_ms']
predicted = component_saving*7/1000
lines = [
 'Qwen Image 2.1 / Turbo：1536²＋参考图分析与完整测试',
 '',
 '当前使用官方 Qwen/Qwen-Image-2.1-Turbo，固定 revision fc13ba1986fcb905854dc8de2f52eee395f49b5b。',
 '官方8步sigma表原样加载、CFG1、原始prefix KV cache/prefill保留；不是把teacher权重直接改成8步。',
 '部署：NVIDIA L20X / FA3 BF16 attention / FP8 DiT / batch1 / SP4 / VAE4 configured。未审计逐请求活跃VAE瓦片。',
 '锚点decode布局：每rank输入QKV [1,2304,32,128]；重排后Q [1,9216,8,128]，KV [1,13271,8,128]。',
 'KV prefix长度4055，joint query长度0；参考图为仓库qwen_image_edit_2511_test1.png。',
 '每请求保留1次原始prefill和7×32=224次decode core。计时为完整离线generate，不含模型加载、下载、HTTP。',
 '',
 '无计时完整请求：每项30对，三个seed逐字节一致，所有rank策略一致。单块回退的波动不计作overlap收益。',
 'run | case | variant | heads | whole ms | variant ms | latency reduction % | P2P window estimate % | saved / P2P estimate % | paired95 ms',
 ]
for r in rows:
    heads = ';'.join(','.join('+'.join(map(str,h)) for h in values) for values in r['selected'].values())
    p = r['p2p_copy_window_estimate']
    ratio = 'A/A' if p['saved_fraction'] is None else f"{p['saved_fraction']*100:.2f}"
    share = 'unmeasured' if p['estimated_request_pct'] is None else f"{p['estimated_request_pct']:.3f}"
    lines.append(f"{r['run']} | {r['case']} | {r['variant']} | {heads} | {r['baseline_ms']:.3f} | {r['adaptive_ms']:.3f} | "
                 f"{r['latency_reduction_pct']:+.3f} | {share} | {ratio} | {r['paired_saved_bootstrap95_ms']}")
lines += [
 '', '通信口径修正',
 '旧9.49%包含peer barrier和stream依赖，已更名为历史“含同步交换窗口”，不再用于纯P2P的50%目标。',
 '新P2P指标只包住通信流上的outgoing CE拷贝，排除barrier、enter/ready等待和local staging。',
 '它仍包含event marker和拷贝间调度间隙，是独立窗口估计，不是请求内memcpy kernel busy union。',
 '主表：每轮先在同rank把F/R窗口相加，再取最大rank，最后取30轮中位数，锚点为311.920us/core。',
 '估计×实际decode core次数/E2E；不含原始prefill、text encoder/VAE通信。其他旧模型未补纯窗口时留空。',
 '', '理想两块模型与实测传输边界',
 f"下面为各phase最大rank中位数的组合，近似展示，不与主表311.920的聚合方式混淆：F={copy['peer_forward']:.3f}, R={copy['peer_reverse']:.3f}us。",
 f"整块F+R={whole_copy:.3f}us；3+5串行两块F/R合计={split_copy:.3f}us，多{split_copy-whole_copy:.3f}us，字节数不变。",
 f"在线性时延假设下，隐藏量=(5/8)F+(3/8)R={whole_copy-linear_exposed:.3f}us，暴露首F+末R={linear_exposed:.3f}us。",
 f"实测chunk首F+末R={chunk_exposed:.3f}us，比线性估计多暴露{chunk_exposed-linear_exposed:.3f}us。",
 f"若其余chunk拷贝全部隐藏，纯拷贝净节省约{whole_copy-chunk_exposed:.3f}us，尚未扣其他新增开销。",
 '条件是A0足够覆盖后块F、A1足够覆盖前块R；孤立A0/A1约294/447us，窗口约149/43us，满足时长条件。',
 '固定提交成本和传输效率各占多少尚未分清；不能把每一项微控制的中位数当作模型内精确可加的关键路径。',
 '', '所有32层完整core：同样计时点的模型内核算',
 'r33为独立诊断，4对请求，三条路径每core均2个external事件、component再2个，共66点。',
 '各项均取该请求component最长rank上的同一组phase值，再平均。只观察每请求最后一次decode图replay。',
 'variant | complete component ms | sum of 32 cores ms | other component intervals ms',
 ]
for name in ('serial1','serial_split','adaptive'):
    p = phases[name]
    lines.append(f"{name} | {p['component_us']/1000:.3f} | {p['cores_us']/1000:.3f} | {p['other_component_us']/1000:.3f}")
lines += [
 f"同样3+5切分，serial -> overlap的core合计节省={(serial['cores_us']-overlap['cores_us'])/1000:.3f}ms/step。",
 f"whole -> serial split额外core开销={(serial['cores_us']-base['cores_us'])/1000:.3f}ms/step，约{(serial['cores_us']-base['cores_us'])/32:.3f}us/core。",
 f"因此core净省{core_saving/1000:.3f}ms/step；core外区间增加{other_growth/1000:.3f}ms；整段净省{component_saving/1000:.3f}ms。",
 f"最后一步×7的估计是{predicted:.3f}ms；r32无计时完整请求实测省{normal_saving:.3f}ms，差{normal_saving-predicted:+.3f}ms。",
 'core外含投影、FFN、逐元素运算与设备调度间隙。不能仅凭这个区间增长断言FFN kernel变慢或指定HBM/L2/SM为根因。',
 '最后一步外推、不同请求/批次的硬件状态、计时点扰动及DiT外阶段变化仍未分离，不能声称精确闭合。',
 'r28 teacher35步相同布局的单层诊断另见详细图：同切分overlap使attention增加约23us；它只是其中一项开销。',
 '', '受控实现实验',
 'stage-defer-fence复用原produced事件，把后一块ready barrier延至当前attention完成，保留所有拷贝、peer fences和输出所有权。',
 'r29匹配分组诊断的rank0：原core1046.624us，新1061.941us，gap约11.083->28.363us；其他rank也未改善。没有替换默认。',
 'r29正常30对中原策略回退whole、新策略选择3+5，不能把两者之差当纯调度收益。',
 'overlap-input只把下一块本地输入staging移到通信流，与当前attention重叠；输出staging和其余依赖保持原状。',
 ]
for r in summary['schedule_ablations']:
    if 'input-staging-' in r['run']:
        lines.append(f"r36同3+5原调度 -> 输入staging：{r['baseline_ms']:.3f} -> {r['after_ms']:.3f}ms；配对节省{r['paired_saved_ms']:.3f}ms，95% {r['paired_saved_bootstrap95_ms']}。")
lines += [
 '输入staging的配对区间跨零，结论是尚未证实额外收益，不能仅按两组中位数差声称稳定回退。',
 '两种调度的多rank/eager/graph/延迟消费者复用检查及模型三个seed通过；未改善的结果保留，不启用新默认。',
 '', '首次形状与稳态',
 '首个真实decode调用发现，第二个真实调用的前24个同签名core采样；不增加探测forward，不逐层host同步。',
 'capture记录保留；Qwen2.1无辅助sync probe/validation replay。正常稳态没有计时事件、查询、采样同步或Python attention。',
 '首次generate包含资源准备/候选试错/建图；不同策略按顺序首次运行会共享已热缓存，不能把下表差值当纯探索成本。',
 'case | variant | first whole generate ms | first variant generate ms',
 ]
for r in rows:
    lines.append(f"{r['case']} | {r['variant']} | {r['first_baseline_ms']:.3f} | {r['first_adaptive_ms']:.3f}")
lines += [
 'execution-budgets.csv另外保留各rank的prepare/finish耗时、事件及调用数。权重下载约57.3秒、32.45GB，单独记录，不混入generate。',
 '', '证据与限制',
 'normal性能source SHA逐项保留在all-comparisons.csv；r33完整core诊断source f73f3fb7e5da48ed9f823d9ca599d3a239f8df11。',
 'r31纯窗口source 0c1d4ca603c05bae6a2cc9bea561ceb4d6568892；r35其余三形状source 292abca62d157b4611b114574e75353718a3cb76。',
 '收尾仅补了非overlap多块使用input-staging时的拒绝校验；合法路径的GPU操作不变，CPU边界检查通过。',
 '所有trace.json为明确标注的逻辑CUDA event区间，非新采集的Nsight/PyTorch kernel trace。',
 '尚未达到净节省为纯P2P预算50%的目标；原3+5三轮点估计约27%-35.5%，每轮均保留，不能只选较高点。',
 '不能用旧含同步分母或孤立core收益替代E2E；输入staging对照也未证实额外收益。',
 '没有建立core外增长的具体kernel/host因果链，仍需继续定位。没有PR、共享依赖升级或生产默认集成。',
 ]
(root/'QWEN-ANCHOR-ANALYSIS.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')

fig, axes = plt.subplots(1,2,figsize=(13,5),layout='constrained')
names = ['Whole','3+5 serial','3+5 overlap']
values = [phases[k] for k in ('serial1','serial_split','adaptive')]
axes[0].barh(names,[r['cores_us']/1000 for r in values],color='#315fa6',label='Complete cores')
axes[0].barh(names,[r['other_component_us']/1000 for r in values],left=[r['cores_us']/1000 for r in values],color='#bdc4cd',label='Other work + gaps')
for i,r in enumerate(values):
    axes[0].text(r['cores_us']/2000,i,f"{r['cores_us']/1000:.2f}",ha='center',va='center',color='white')
    axes[0].text((r['cores_us']+r['other_component_us']/2)/1000,i,f"{r['other_component_us']/1000:.2f}",ha='center',va='center')
    axes[0].text(r['component_us']/1000+0.5,i,f"{r['component_us']/1000:.2f}",va='center',fontsize=9)
axes[0].invert_yaxis()
axes[0].set_xlim(0,91)
axes[0].set_xlabel('Last decode component span (ms)')
axes[0].set_title('All 32 cores, equal event counts\n4 diagnostic pairs; phase values from component-critical rank')
fig.legend(*axes[0].get_legend_handles_labels(),loc='outside lower center',ncol=2,frameon=False)
axes[1].barh(['Whole CE windows','3+5 serial CE windows','Linear exposed endpoints','Measured chunk endpoints'],
             [whole_copy,split_copy,linear_exposed,chunk_exposed],color=['#188f76','#83b6a8','#d1a45e','#c77650'])
for i,value in enumerate([whole_copy,split_copy,linear_exposed,chunk_exposed]):
    axes[1].text(value+4,i,f'{value:.1f}',va='center')
axes[1].invert_yaxis()
axes[1].set_xlim(0,400)
axes[1].set_xlabel('Isolated CE-only event windows (us)')
axes[1].set_title('Copy time is not linear in head width\nSums of phasewise max-rank medians; barriers excluded')
for axis in axes:
    axis.spines[['top','right']].set_visible(False)
    axis.grid(axis='x',alpha=.15)
fig.suptitle('Qwen Image 2.1 Turbo | 1536 x 1536 + reference | SP4, FP8 DiT, native 8 steps')
for ext in ('svg','png'):
    fig.savefig(root/f'qwen-turbo-performance-budget.{ext}',dpi=180)
print(root/'QWEN-ANCHOR-ANALYSIS.txt')
