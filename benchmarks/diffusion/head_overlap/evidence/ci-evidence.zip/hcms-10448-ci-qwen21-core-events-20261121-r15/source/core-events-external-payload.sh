#!/usr/bin/env bash
set -euo pipefail
run=$1
mkdir -p "$run/source"
cp "$0" "$run/source/core-events-external-payload.sh"
cp /tmp/codex-hcms-ci-20261121/core-events-payload.sh "$run/source/core-events-payload.sh"
printf '%s\n' 'HCMS_CORE_EVENTS=1' 'HCMS_FORCE_DIAGNOSTIC_SPLIT=1' 'HCMS_COPY_SUBMITTER=task-local-built-library' \
  > "$run/source/diagnostic-env.txt"
bash /tmp/codex-hcms-ci-20261121/core-events-payload.sh "$@"
