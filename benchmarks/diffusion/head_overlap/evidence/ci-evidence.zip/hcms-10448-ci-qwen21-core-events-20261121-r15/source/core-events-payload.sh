#!/usr/bin/env bash
set -euo pipefail
run=$1
model=$2
config=$3
adapter=$4
export PROBE_DIR="$PWD/benchmarks/diffusion/head_overlap"
export PYTHONPATH="$PROBE_DIR${PYTHONPATH:+:$PYTHONPATH}"
export HCMS_CORE_EVENTS=1
export HCMS_FORCE_DIAGNOSTIC_SPLIT=1
mkdir -p "$run/source"
export HCMS_COPY_SUBMITTER="$run/source/copy_submitter.so"
c++ -O2 -std=c++17 -shared -fPIC "$PROBE_DIR/copy_submitter.cpp" -o "$HCMS_COPY_SUBMITTER"
cp "$PROBE_DIR/copy_submitter.cpp" "$run/source/copy_submitter.cpp"
sha256sum "$PROBE_DIR/copy_submitter.cpp" "$HCMS_COPY_SUBMITTER" > "$run/source/submitter.sha256"
python -c 'import torch; torch.accelerator.set_device_index(0); event = torch.Event(device="cuda", enable_timing=True); event.record(); torch.accelerator.synchronize(); assert event.query() and event.elapsed_time(event) == 0; print("PASS generic accelerator event API")' > "$run/event-precheck.log" 2>&1
bash /tmp/codex-hcms-ci-20261121/qwen21-r4-model-payload.sh "$run" "$model" "$config" "$adapter" 3
