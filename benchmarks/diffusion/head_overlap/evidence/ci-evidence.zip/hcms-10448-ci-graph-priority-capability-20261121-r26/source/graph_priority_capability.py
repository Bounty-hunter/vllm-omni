"""Read CUDA graph instantiation flags; no profiler or model forward."""
import ctypes,json
import torch
from vllm_omni.diffusion.distributed.a2a_permute import _ce_runtime
runtime=_ce_runtime()
get_flags=runtime.lib.cudaGraphExecGetFlags
get_flags.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulonglong)]
get_flags.restype=ctypes.c_int
for priority in (0,-1):
 compute=torch.cuda.Stream(priority=priority)
 comm=torch.cuda.Stream(priority=0)
 with torch.cuda.stream(compute):
  value=torch.ones(1024,device='cuda')
  torch.accelerator.synchronize()
  graph=torch.cuda.CUDAGraph(keep_graph=True)
  with torch.cuda.graph(graph,stream=compute):
   first=value+1
   comm.wait_stream(compute)
   with torch.cuda.stream(comm):
    second=first+2
   compute.wait_stream(comm)
   result=second+1
  graph.instantiate()
  flags=ctypes.c_ulonglong()
  runtime.CUDART_CHECK(get_flags(graph.raw_cuda_graph_exec(),ctypes.byref(flags)))
  graph.replay()
  torch.accelerator.synchronize()
  assert torch.equal(result,torch.full_like(result,5))
  print('GRAPH_PRIORITY_CAPABILITY '+json.dumps(dict(requested_compute_priority=priority,
   actual_compute_priority=compute.priority,actual_communication_priority=comm.priority,
   instantiate_flags=flags.value,uses_node_priority=bool(flags.value&8),
   exact=True,torch=torch.__version__,gpu=torch.cuda.get_device_name())),flush=True)
  graph.reset()
