#!/usr/bin/env bash
set -euo pipefail
run=$1
world=$2
export TMPDIR="/tmp/hcms-coverage-core-sp${world}-20261121"
export TRITON_CACHE_DIR="$TMPDIR/triton"
mkdir -p "$TMPDIR" "$run/source"
export LD_LIBRARY_PATH=/home/dyy/.local/lib/python3.12/site-packages/nvidia/cudnn/lib:${LD_LIBRARY_PATH:-}
export PROBE_DIR="$PWD/benchmarks/diffusion/head_overlap"
export PYTHONPATH="$PROBE_DIR${PYTHONPATH:+:$PYTHONPATH}"
files=(vllm_omni/diffusion/attention/parallel/head_overlap.py vllm_omni/diffusion/distributed/a2a_permute.py)
test -z "$(git status --porcelain)"
for file in "${files[@]}"; do cp "$file" "$run/source/$(basename "$file").before"; done
restore_probe() {
  for file in "${files[@]}"; do cp "$run/source/$(basename "$file").before" "$file"; done
  git status --short > "$run/restoration-status.txt"
}
trap restore_probe EXIT
git apply --check "$PROBE_DIR/native-probe.patch"
git apply "$PROBE_DIR/native-probe.patch"
git rev-parse HEAD > "$run/source/code-sha.txt"
git diff --binary > "$run/source/integration.patch"
sha256sum "$PROBE_DIR/"*.py "$PROBE_DIR/"*.json > "$run/source/source.sha256"
cp "$PROBE_DIR/coverage-core-sp${world}.json" "$run/source/config.json"
cp "$0" "$run/source/payload.sh"
nvidia-smi topo -m > "$run/topology.txt"
torchrun --standalone --nproc-per-node="$world" "$PROBE_DIR/core_budget.py" \
  --cases "$PROBE_DIR/coverage-core-sp${world}.json" --out "$run/results" --rounds 30 --inner 16
