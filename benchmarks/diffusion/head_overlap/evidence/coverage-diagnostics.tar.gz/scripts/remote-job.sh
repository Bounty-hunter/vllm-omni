#!/usr/bin/env bash
# Usage: remote-job.sh REPO RUN_DIR GPUS TIMEOUT WAIT NOTE -- COMMAND [ARG...]
# RUN_DIR must be a unique task directory under /data/dyy/logs/.

if [[ $(id -un) != dyy ]]; then
    echo 'Run this script through su - dyy; root must not run the job.' >&2
    exit 1
fi
if (( $# < 8 )) || [[ $7 != -- ]]; then
    echo 'Usage: remote-job.sh REPO RUN_DIR GPUS TIMEOUT WAIT NOTE -- COMMAND [ARG...]' >&2
    exit 2
fi

repo_arg=$1
run_dir_arg=$2
gpus=$3
timeout=$4
wait_limit=$5
note=$6
shift 7
if [[ $repo_arg != /* || $run_dir_arg != /* || ! $gpus =~ ^[1-9][0-9]*$ ]]; then
    echo 'Repository and log paths must be absolute; GPUS must be positive.' >&2
    exit 2
fi
repo=$(readlink -f -- "$repo_arg") || exit 2
run_dir=$(readlink -m -- "$run_dir_arg") || exit 2
protected_repo=$(readlink -f -- /data/dyy/code/vllm-omni) || exit 2
if [[ ! -d $repo || $repo == "$protected_repo" || $repo == "$protected_repo/"* ]]; then
    echo 'Use an existing independent verification checkout.' >&2
    exit 2
fi
if [[ $run_dir != /data/dyy/logs/* ]]; then
    echo 'RUN_DIR must be a task directory under /data/dyy/logs/.' >&2
    exit 2
fi
mkdir -p -- "$run_dir" || exit 2
# noclobber prevents a second invocation from replacing this task's log.
set -o noclobber
exec >"$run_dir/run.log" 2>&1 || exit 2
set +o noclobber
trap 'job_rc=$?; trap - EXIT; printf "%s\n" "$job_rc" > "$run_dir/exit-code"; exit "$job_rc"' EXIT

shopt -s expand_aliases
source ~/.bashrc || exit $?
type DYY >/dev/null 2>&1 || { echo 'DYY is unavailable after shell initialization.'; exit 1; }
DYY || exit $?
set -euo pipefail
command -v gpu >/dev/null
cd -- "$repo"
export PYTHONPATH="$repo${PYTHONPATH:+:$PYTHONPATH}"
export OMNI_VERIFY_REPO="$repo"
printf 'user=%s\nrepo=%s\n' "$(id -un)" "$repo"
git rev-parse HEAD
git status --short
printf 'command:'
printf ' %q' "$@"
printf '\n'
gpu status

# Import provenance is checked inside the same GPU reservation as the command.
# exec preserves the command's status; no pipeline can hide a failing test.
gpu run --gpus "$gpus" --timeout "$timeout" --wait "$wait_limit" --note "$note" -- \
    bash -c 'set -euo pipefail
python -c '\''import os, sys, vllm_omni; root = os.path.realpath(os.environ["OMNI_VERIFY_REPO"]); module = os.path.realpath(vllm_omni.__file__); print("vllm_omni=" + module, flush=True); sys.exit(0 if os.path.commonpath([root, module]) == root else "vllm_omni imported outside the verification checkout")'\''
exec "$@"' codex-omni "$@"
