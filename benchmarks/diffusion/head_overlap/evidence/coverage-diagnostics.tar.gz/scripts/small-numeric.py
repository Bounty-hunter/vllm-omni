"""Diagnostic only: compare head-count arithmetic without CE or model state."""

import argparse
import hashlib
import json
from pathlib import Path

import torch

from vllm_omni.diffusion.attention.backends.abstract import AttentionMetadata
from vllm_omni.diffusion.attention.backends.flash_attn import FlashAttentionImpl

parser = argparse.ArgumentParser()
parser.add_argument("--out", type=Path, required=True)
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=True)
torch.accelerator.set_device_index(0)
stream = torch.cuda.Stream()
stream.wait_stream(torch.cuda.current_stream())
torch.cuda.set_stream(stream)
impl = FlashAttentionImpl(14, 128, 128**-0.5)
result = dict(scope="Pure packed FA3 numeric diagnostic; no CE, weights, output slots or profiling", records=[],
              script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
with torch.inference_mode():
    for total in (288, 1056, 4128):
        for seed in (42, 43, 44):
            torch.manual_seed(seed)
            tensors = tuple(torch.randn(1, total, 14, 128, dtype=torch.bfloat16, device="cuda") for _ in range(3))
            bounds = torch.tensor([0, total-16, total], dtype=torch.int32, device="cuda")
            md = AttentionMetadata(extra=dict(cu_seqlens_q=bounds, cu_seqlens_k=bounds,
                                             max_seqlen_q=total-16, max_seqlen_k=total-16))
            reference = impl.forward_cuda(*tensors, md)
            for sizes in ((14,), (7,7), (4,10)):
                groups, offset = [], 0
                for size in sizes:
                    groups.append(tuple(x[:,:,offset:offset+size].contiguous() for x in tensors))
                    offset += size

                def body():
                    return tuple(impl.forward_cuda(*group, md) for group in groups)

                for _ in range(3):
                    eager = body()
                eager = torch.cat(eager, dim=2)
                torch.accelerator.synchronize()
                graph = torch.cuda.CUDAGraph()
                with torch.cuda.graph(graph, stream=stream):
                    outputs = body()
                graph.replay()
                torch.accelerator.synchronize()
                actual = torch.cat(outputs, dim=2)
                delta = (actual.float()-reference.float()).abs()
                row = dict(tokens=total,seed=seed,heads=sizes,
                           eager_exact=bool(torch.equal(eager,reference)),
                           graph_exact=bool(torch.equal(actual,reference)),
                           different_values=int(torch.count_nonzero(delta).item()),max_abs=float(delta.max().item()))
                result["records"].append(row)
                print(json.dumps(row),flush=True)
                del graph, outputs
(args.out/"numeric.json").write_text(json.dumps(result,indent=2)+"\n")
