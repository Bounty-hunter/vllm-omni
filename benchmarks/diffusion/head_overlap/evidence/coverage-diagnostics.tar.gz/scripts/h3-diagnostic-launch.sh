#!/usr/bin/env bash
[[ $(id -un) == dyy ]] || exit 1
shopt -s expand_aliases
source ~/.bashrc || exit $?
type DYY >/dev/null 2>&1 || exit 1
DYY || exit $?
set -euo pipefail
upload=/tmp/codex-hcms-coverage-20261121
repo=/data/dyy/code/vllm-omni-codex-hcms-h3-sp4-confirm-20261120
test -z "$(git -C "$repo" status --porcelain)"
run=/data/dyy/logs/hcms-10448-h3-small-diagnostic-20261121
test ! -e "$run"
mkdir -p "$run"
tmux new-session -d -s codex-hcms-small-diagnostic-20261121 "bash $upload/remote-job.sh $repo $run 4 15m 20m hcms-small-diagnostic -- bash $upload/h3-diagnostic-payload.sh $run > $run/bootstrap.log 2>&1"
