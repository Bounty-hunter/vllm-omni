"""Diagnostic image deltas; mismatches are reported, never accepted as correctness passes."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from model_matrix import arrays

from vllm_omni.entrypoints.omni import Omni
from vllm_omni.inputs.data import OmniDiffusionSamplingParams



def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    args.out.mkdir(parents=True, exist_ok=True)
    variants = config["variants"]
    rows = []
    omni = Omni(model=args.model, **config["engine"])
    try:
        for size in (512, 1024):
            active = dict(variants)
            if size == 1024:
                active["serial_borrowed"] = dict(graph_mode="graph", chunks=1, schedule="stage-local-shared-slots")
            runs = [("warm", name, index, 42) for name in active for index in range(3)]
            if size == 512:
                for index in range(8):
                    names = list(active)
                    offset = index % len(names)
                    names = names[offset:] + names[:offset]
                    if (index // len(names)) % 2:
                        names.reverse()
                    runs.extend(("paired-context", name, index, 42) for name in names)
            runs.extend(("correctness", name, seed - 43, seed) for seed in (43,44) for name in active)
            references = {}
            for phase, name, index, seed in runs:
                extra = dict(active[name],case=f"h3-{size}",variant=name,label=f"h3-{size}-{phase}-{name}-i{index}",
                             audit=index==0,trace=False)
                sampling = dict(config["cases"][0]["sampling"],height=size,width=size,seed=seed,extra_args=extra)
                output = omni.generate(config["prompt"],sampling_params_list=[OmniDiffusionSamplingParams(**sampling)])
                values = arrays(output)
                if name == "serial1" and seed not in references:
                    references[seed] = [np.array(value,copy=True) for value in values]
                    if size == 1024:
                        np.savez_compressed(args.out/f"reference-{size}-seed{seed}.npz",*references[seed])
                ref = references[seed]
                deltas = [np.abs(value.astype(np.int16)-expected.astype(np.int16)) for value,expected in zip(values,ref,strict=True)]
                exact = all(not np.any(delta) for delta in deltas)
                row = dict(size=size,variant=name,phase=phase,index=index,seed=seed,exact=exact,
                           hashes=[hashlib.sha256(value.tobytes()).hexdigest() for value in values],
                           reference_hashes=[hashlib.sha256(value.tobytes()).hexdigest() for value in ref],
                           different_channels=sum(int(np.count_nonzero(delta)) for delta in deltas),
                           different_pixels=sum(int(np.count_nonzero(np.any(delta,axis=-1))) for delta in deltas),
                           max_abs=max(int(delta.max()) for delta in deltas))
                if not exact and (phase=="warm" and index==0 or seed!=42):
                    np.savez_compressed(args.out/f"mismatch-{size}-{name}-seed{seed}.npz",*values)
                rows.append(row)
                print("NUMERIC_IMAGE "+json.dumps(row),flush=True)
                (args.out/"images.json").write_text(json.dumps(dict(scope="Numeric diagnostic only; no performance acceptance",all_exact=all(r["exact"] for r in rows),records=rows),indent=2)+"\n")
    finally:
        omni.close()


if __name__ == "__main__":
    main()
