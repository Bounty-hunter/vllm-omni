"""Check whether automatic SplitKV selection changes packed FA3 arithmetic."""

import argparse
import inspect
import json
from pathlib import Path

import torch

from vllm_omni.diffusion.attention.backends.flash_attn import FlashAttentionImpl
from vllm_omni.diffusion.attention.backends.utils.fa import flash_attn_varlen_func, vllm_varlen_version_kwargs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    torch.accelerator.set_device_index(0)
    result = dict(scope="Numeric diagnostic only; no CE/model/output slots/profiler",
                  backend=flash_attn_varlen_func.__module__, signature=str(inspect.signature(flash_attn_varlen_func)),
                  version=vllm_varlen_version_kwargs(flash_attn_varlen_func), records=[])
    with torch.inference_mode():
        for seed in (42,43,44):
            torch.manual_seed(seed)
            qkv = tuple(torch.randn(1056,14,128,dtype=torch.bfloat16,device="cuda") for _ in range(3))
            bounds = torch.tensor([0,1040,1056],dtype=torch.int32,device="cuda")

            def call(tensors, fixed):
                options = dict(result["version"])
                if fixed:
                    options["num_splits"] = 1
                out = flash_attn_varlen_func(*tensors,cu_seqlens_q=bounds,cu_seqlens_k=bounds,
                                            max_seqlen_q=1040,max_seqlen_k=1040,causal=False,
                                            softmax_scale=128**-0.5,**options)
                return FlashAttentionImpl._unwrap_flash_output(out)

            reference = call(qkv,False)
            fixed_whole = call(qkv,True)
            for sizes in ((7,7),(4,10)):
                groups,offset=[],0
                for size in sizes:
                    groups.append(tuple(t[:,offset:offset+size].contiguous() for t in qkv))
                    offset+=size
                auto = torch.cat([call(group,False) for group in groups],dim=1)
                fixed = torch.cat([call(group,True) for group in groups],dim=1)
                torch.accelerator.synchronize()
                row=dict(seed=seed,heads=sizes,whole_auto_vs_fixed1_exact=bool(torch.equal(reference,fixed_whole)),
                         split_auto_exact=bool(torch.equal(reference,auto)),split_fixed1_exact=bool(torch.equal(reference,fixed)),
                         auto_max_abs=float((reference.float()-auto.float()).abs().max().item()),
                         fixed1_max_abs=float((reference.float()-fixed.float()).abs().max().item()))
                result["records"].append(row)
                print(json.dumps(row),flush=True)
    (args.out/"splitkv.json").write_text(json.dumps(result,indent=2)+"\n")


if __name__ == "__main__":
    main()
