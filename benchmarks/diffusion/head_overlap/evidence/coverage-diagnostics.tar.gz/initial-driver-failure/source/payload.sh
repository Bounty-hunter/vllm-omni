#!/usr/bin/env bash
set -euo pipefail
run=$1
export TMPDIR=/tmp/hcms-h3-small-diagnostic-20261121
export TRITON_CACHE_DIR="$TMPDIR/triton"
export TORCHINDUCTOR_CACHE_DIR="$TMPDIR/inductor"
mkdir -p "$TMPDIR" "$run/source"
export LD_LIBRARY_PATH=/home/dyy/.local/lib/python3.12/site-packages/nvidia/cudnn/lib:${LD_LIBRARY_PATH:-}
export PROBE_DIR="$PWD/benchmarks/diffusion/head_overlap"
export PYTHONPATH="$PROBE_DIR${PYTHONPATH:+:$PYTHONPATH}"
export HCMS_EXPECTED_FP8=260
export HCMS_EXPECTED_VAE_WORLD=4
export HCMS_GRAPH_OUTPUT="$run/audit"
files=(vllm_omni/diffusion/models/minimax_h3/pipeline_minimax_h3_image.py
       vllm_omni/diffusion/models/minimax_h3/minimax_h3_transformer.py
       vllm_omni/diffusion/attention/parallel/head_overlap.py
       vllm_omni/diffusion/distributed/a2a_permute.py)
test -z "$(git status --porcelain)"
for file in "${files[@]}"; do cp "$file" "$run/source/$(basename "$file").before"; done
restore_probe() {
  for file in "${files[@]}"; do cp "$run/source/$(basename "$file").before" "$file"; done
  git status --short > "$run/restoration-status.txt"
}
trap restore_probe EXIT
git apply --check "$PROBE_DIR/native-probe.patch"
git apply "$PROBE_DIR/native-probe.patch"
git apply --check "$PROBE_DIR/h3-graph-probe.patch"
git apply "$PROBE_DIR/h3-graph-probe.patch"
git rev-parse HEAD > "$run/source/code-sha.txt"
git diff --binary > "$run/source/integration.patch"
sha256sum "$PROBE_DIR/"*.py "$PROBE_DIR/"*.json > "$run/source/source.sha256"
cp "$PROBE_DIR/h3-small-coverage-matrix.json" "$run/source/config.json"
cp "$0" "$run/source/payload.sh"
nvidia-smi topo -m > "$run/topology.txt"
python /tmp/codex-hcms-coverage-20261121/h3-small-diagnostic.py --model /data/dyy/logs/hcms-10448-model \
  --config "$PROBE_DIR/h3-small-coverage-matrix.json" --out "$run/results" 
