"""Package exited real-prefix jobs only, retaining failures and array hashes."""
import hashlib
import json
import tarfile
from pathlib import Path

target=Path('/tmp/codex-hcms-prefix-20261121/evidence.tar.gz')
manifest={}
with tarfile.open(target,'w:gz') as archive:
    for folder in sorted(Path('/data/dyy/logs').glob('hcms-10448-prefix-*20261121*')):
        if not (folder/'exit-code').is_file():
            continue
        name=folder.name.removeprefix('hcms-10448-prefix-')
        row=manifest[name]=dict(remote=str(folder),exit_code=(folder/'exit-code').read_text().strip(),files=[],external_arrays=[])
        for file in sorted(folder.rglob('*')):
            if not file.is_file():
                continue
            item=dict(file=f'{name}/{file.relative_to(folder).as_posix()}',
                sha256=hashlib.sha256(file.read_bytes()).hexdigest(),bytes=file.stat().st_size)
            if file.suffix=='.npz':
                row['external_arrays'].append(item)
                continue
            assert item['bytes']<30_000_000,file
            archive.add(file,arcname=item['file'])
            row['files'].append(item)
target.with_name('manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(runs={k:v['exit_code'] for k,v in manifest.items()},bytes=target.stat().st_size,
    sha256=hashlib.sha256(target.read_bytes()).hexdigest())))
