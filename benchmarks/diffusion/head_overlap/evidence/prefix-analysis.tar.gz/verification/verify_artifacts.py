"""Check published artifacts against saved samples and per-file manifests."""
import csv
import hashlib
import json
import statistics
import tarfile
import zipfile
from pathlib import Path

prefix = Path('outputs/issue-10448-prefix-20261121')
all_tests = Path('outputs/issue-10448-all-tests-20261121')
evidence = Path('worktrees/issue-10448-hcms/benchmarks/diffusion/head_overlap/evidence')
summary = json.loads((prefix / 'prefix-summary.json').read_text(encoding='utf-8'))
assert summary['requests'] == 1660 and len(summary['runs']) == 32
assert len(summary['matrix']) == 26 and len(summary['confirmations']) == 14
assert len(summary['independent_startup_pairs']) == 10


def rows(name):
    with (all_tests / name).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


aggregates, samples = rows('all-e2e-variants.csv'), rows('all-steady-samples.csv')
assert len(aggregates) == 454 and len(samples) == 5165
assert len(rows('all-first-shape-observations.csv')) == 249
assert len(rows('communication-splitting-controls.csv')) == 22
assert len(rows('isolated-microbenchmarks.csv')) == 176
grouped = {}
for row in samples:
    key = row['stage'], row['run'], row['case'], row['variant']
    grouped.setdefault(key, []).append(float(row['latency_ms']))
for row in aggregates:
    key = row['stage'], row['run'], row['case'], row['variant']
    assert abs(statistics.median(grouped[key]) - float(row['median_ms'])) < 1e-8, key
    if row['baseline_ms'] and row['latency_reduction_pct']:
        ratio = 100 * (float(row['baseline_ms']) - float(row['median_ms'])) / float(row['baseline_ms'])
        assert abs(ratio - float(row['latency_reduction_pct'])) < 1e-8, key
for folder, archives in ((prefix, ('prefix-tests.zip',)),
                         (all_tests, ('all-tests.zip', 'original-evidence.zip'))):
    hashes = json.loads((folder / 'sha256.json').read_text(encoding='utf-8'))
    for name in archives:
        with zipfile.ZipFile(folder / name) as archive:
            assert archive.testzip() is None, name
            if name != 'original-evidence.zip':
                for member, expected in hashes.items():
                    assert hashlib.sha256(archive.read(member)).hexdigest() == expected, (name, member)
    for name, expected in hashes.items():
        assert hashlib.sha256((folder / name).read_bytes()).hexdigest() == expected, name
with tarfile.open(evidence / 'prefix-raw.tar.gz') as archive:
    manifest = json.load(archive.extractfile('manifest.json'))
    for run in manifest.values():
        assert run['exit_code'] == '0'
        for entry in run['files']:
            contents = archive.extractfile(entry['file']).read()
            assert len(contents) == entry['bytes'] and hashlib.sha256(contents).hexdigest() == entry['sha256']
print('PASS 1660 requests / 32 runs; 454 aggregates / 5165 saved samples; all medians, ratios, ZIP CRC, hashes and branch raw evidence')
