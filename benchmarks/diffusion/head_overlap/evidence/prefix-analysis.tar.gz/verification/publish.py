"""Package source identities, request records and audits for the experiment branch."""
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

root = Path('outputs/issue-10448-prefix-20261121')
work = Path('work/issue-10448-prefix-20261121')
bench = Path('worktrees/issue-10448-hcms/benchmarks/diffusion/head_overlap')
evidence = bench / 'evidence'
manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
summary = json.loads((root / 'prefix-summary.json').read_text(encoding='utf-8'))
assert len(summary['matrix']) == 26 and len(summary['confirmations']) == 14
assert len(summary['independent_startup_pairs']) == 10 and summary['requests'] == 1660
assert all(run['exit_code'] == '0' for run in summary['runs'].values())
compact_manifest = {}
with tarfile.open(evidence / 'prefix-raw.tar.gz', 'w:gz') as archive:
    for name, run in manifest.items():
        selected = []
        for entry in run['files']:
            relative = Path(entry['file']).relative_to(name).as_posix()
            keep = (relative in ('exit-code', 'restoration-status.txt', 'topology.txt', 'results/results.json',
                                 'loadavg-start.txt', 'loadavg-end.txt')
                    or relative.startswith(('audit/', 'results/audit/'))
                    or relative in ('source/code-sha.txt', 'source/config.json', 'source/source.sha256',
                                    'source/integration.patch', 'source/payload.sh'))
            if keep:
                file = root / entry['file']
                assert hashlib.sha256(file.read_bytes()).hexdigest() == entry['sha256'], file
                archive.add(file, arcname=entry['file'])
                selected.append(entry)
        compact_manifest[name] = dict(exit_code=run['exit_code'], files=selected,
                                      external_arrays=run['external_arrays'])
    manifest_path = work / 'branch-manifest.json'
    manifest_path.write_text(json.dumps(compact_manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
    archive.add(manifest_path, arcname='manifest.json')
with tarfile.open(evidence / 'prefix-analysis.tar.gz', 'w:gz') as archive:
    for name in ('summary.json', 'prefix-summary.json', 'verification.log', 'completion-audit.log', 'all-requests.csv',
                 'all-comparisons.csv', 'all-prefix-observations.csv', 'independent-first-requests.csv'):
        archive.add(root / name, arcname=name)
    for name in ('summarize.py', 'export_results.py', 'collect.py', 'make_confirmation.py', 'publish.py',
                 'verify_artifacts.py'):
        archive.add(work / name, arcname='verification/' + name)
    archive.add(Path('work/issue-10448-lazy-20261121/all_tests.py'), arcname='verification/all_tests.py')
shutil.copyfile(root / 'PREFIX-RESULTS.txt', bench / 'PREFIX-RESULTS.txt')
shutil.copyfile(root / 'prefix-summary.json', evidence / 'prefix-summary.json')
print(json.dumps({file.name: dict(bytes=file.stat().st_size, sha256=hashlib.sha256(file.read_bytes()).hexdigest())
                  for file in (evidence / 'prefix-raw.tar.gz', evidence / 'prefix-analysis.tar.gz',
                               evidence / 'prefix-summary.json')}))
