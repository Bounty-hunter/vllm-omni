"""Export every saved performance arm, retaining phases and ownership baselines."""
import csv
import hashlib
import json
import statistics
import zipfile
from collections import Counter
from pathlib import Path

bench=Path('worktrees/issue-10448-hcms/benchmarks/diffusion/head_overlap')
evidence=bench/'evidence'
out=Path('outputs/issue-10448-all-tests-20261121')
out.mkdir(exist_ok=True)
rows=[]
samples=[]
cold=[]


def read(name):
    return json.loads((evidence/name).read_text(encoding='utf-8'))


def append(stage, run, case, variant, median, values, base, *, shape=None, heads=None,
           rounds=None, wins=None, reduction=None, borrowed=None, borrowed_gain=None,
           comm=None, note='', source='', cold_ms=None):
    record=dict(stage=stage,run=run,case=case,variant=variant,actual_output_shape=shape,
        heads_per_rank=heads,baseline_ms=base,median_ms=median,
        latency_reduction_pct=reduction if reduction is not None else (100*(base-median)/base if base else None),
        same_output_ownership_whole_ms=borrowed,same_output_ownership_gain_pct=borrowed_gain,
        faster_pairs=wins,rounds=rounds or len(values),estimated_peer_request_pct=comm,
        note=note,source=source)
    rows.append(record)
    for i,value in enumerate(values):
        samples.append(dict(stage=stage,run=run,case=case,variant=variant,index=i,latency_ms=value,source=source))
    if cold_ms is not None:
        cold.append(dict(stage=stage,run=run,case=case,variant=variant,first_shape_request_ms=cold_ms,
            note='首形状/首配置观测，受顺序、初始化、建图影响；不能视为纯探索成本',source=source))


prefix_root=Path('outputs/issue-10448-prefix-20261121')
prefix=json.loads((prefix_root/'summary.json').read_text(encoding='utf-8'))
prefix_comparisons=list(csv.DictReader((prefix_root/'all-comparisons.csv').open(encoding='utf-8-sig')))
for row in prefix['rows']:
    run,case,arm=row['run'],row['case'],row['variant']
    startup='-startup-' in run
    base=next((v for v in prefix['rows'] if (v['run'],v['case'],v['variant'])==(run,case,'serial1')),None)
    audit=row['first_rank_audits']['0']
    policies={'blocks':audit['lazy_policy']} if audit.get('lazy_policy') else audit.get('lazy_policies',{})
    heads=[report['selected'] for policy in policies.values() for report in policy['reports']]
    fallback=bool(heads) and all(len(v)==1 for v in heads)
    stage=('真实前缀_独立首请求' if startup else '真实前缀_30轮复核' if '-confirm-' in run else
           '真实前缀_smoke' if '-smoke-' in run else '真实前缀_26场景矩阵')
    match=next((r for r in prefix_comparisons if (r['run'],r['case'],r['variant'])==(run,case,arm)),None)
    comm=float(match['estimated_peer_request_pct']) if match and match['estimated_peer_request_pct'] else None
    note=('独立单臂，不计算自身比较收益' if startup else '基线' if arm=='serial1' else
          '旧单块路径仅验证等价，不算overlap收益' if arm=='legacy1' else
          '单块A/A差值，不算overlap收益' if fallback else '实际前缀选择；结合独立复核和配对区间判断')
    append(stage,run,case,arm,row['median_ms'],row['samples_ms'],None if startup else base['median_ms'],
        shape=row['output_shapes'],heads=heads,rounds=row['rounds'],wins=None if startup else row['wins'],
        reduction=None if startup else row['reduction_pct'],note=note+'；两臂同共享输出所有权',
        borrowed=base['median_ms'] if base and not startup else None,
        borrowed_gain=row['reduction_pct'] if not startup else None,comm=comm,
        source=prefix['runs'][run]['source_sha'],cold_ms=row['cold_ms'])

lazy=json.loads(Path('outputs/issue-10448-lazy-20261121/summary.json').read_text(encoding='utf-8'))
coverage=read('coverage-summary.json')
for row in lazy['rows']:
    run,case,arm=row['run'],row['case'],row['variant']
    startup='-startup-' in run
    base=next((v for v in lazy['rows'] if (v['run'],v['case'],v['variant'])==(run,case,'serial1')),None)
    stage=('预热采样_独立首请求' if startup else '预热采样_最终矩阵' if '-cold-' in run else
           '预热采样_30轮复核' if '-confirm-' in run else '预热采样_smoke' if '-smoke-' in run else '预热采样_首轮矩阵')
    heads=[report['selected'] for value in row.get('policies',{}).get('0',{}).values() for report in value['reports']]
    whole=bool(heads) and all(len(v)==1 for v in heads)
    normal_case=case
    for suffix in ('-cold-ab','-cold-ba','-startup','-lazy-confirm'):
        normal_case=normal_case.removesuffix(suffix)
    control=next((c for c in coverage['controls'] if c['request_case']==normal_case),None)
    comm=((control['peer_forward_us']+control['peer_reverse_us'])*control['calls_per_request']/1000/base['median_ms']*100
          if control and base and not startup else None)
    note=('独立单臂，仅2轮热态，不作配对收益' if startup else
          '单块A/A差值，不算优化收益' if arm=='adaptive' and whole else
          '基线' if arm=='serial1' else '固定分组对照' if arm=='oracle' else
          'smoke，非性能验收' if '-smoke-' in run else
          '旧采样/建图实现；不作最终首次成本证据' if stage=='预热采样_首轮矩阵' else
          '早期AB/BA方向相反、区间跨0，波动结果' if 'wan14b' in run and '-cold-' in run and 'f33' in case else
          '保留原始观测，结合配对区间判断')
    append(stage,run,case,arm,row['median_ms'],row['samples_ms'],None if startup else base['median_ms'],
        shape=row['output_shapes'],heads=heads,rounds=row['rounds'],wins=None if startup else row['wins'],
        reduction=None if startup else row['reduction_pct'],note=note+'；单块和候选均共享输出槽',
        borrowed=base['median_ms'] if base and not startup else None,
        borrowed_gain=row['reduction_pct'] if not startup else None,comm=comm,
        source=lazy['runs'][run]['source_sha'],cold_ms=row['cold_ms'])

for row in coverage['rows']:
    run,case=row['run'],row['case']
    base=next(v for v in coverage['rows'] if (v['run'],v['case'],v['variant'])==(run,case,'serial1'))
    borrow=next((v for v in coverage['rows'] if (v['run'],v['case'],v['variant'])==(run,case,'serial_borrowed')),None)
    geometry=row['actual_attention_geometries'][0]
    cfg=row['variant_config']
    weights=cfg.get('head_partition',[1]*cfg['chunks'])
    heads=[geometry['heads_per_rank']*v//sum(weights) for v in weights]
    same=row['selected_settings_same_as_serial'] and row['variant']=='selected'
    append('固定分组_30轮确认' if row['rounds']==30 else '固定分组_筛选',run,case,row['variant'],
        row['median_ms'],row['samples_ms'],base['median_ms'],shape=row['actual_output_shapes'],
        heads=heads,rounds=row['rounds'],wins=row['wins_vs_serial'],reduction=row['reduction_vs_serial_pct'],
        borrowed=borrow['median_ms'] if borrow else None,borrowed_gain=row['reduction_vs_borrowed_pct'],
        comm=(row['communication_share'] or {}).get('estimated_peer_request_fraction_pct'),
        note='单块A/A差值，不算优化收益' if same else '原始基线自有输出；拆分使用共享输出，另列同所有权收益',
        source=coverage['runs'][run]['source_sha'])

part=read('head-partition-summary.json')
for row in part['rows']:
    run,case=row['run'],row['case']
    base=next(v for v in part['rows'] if (v['run'],v['case'],v['variant'])==(run,case,'serial1'))
    append('不等分组_30轮确认' if row['pairs']==30 else '不等分组_筛选',run,case,row['variant'],
        row['median_ms'],row['samples_ms'],base['median_ms'],shape=row['output_shapes'],heads=row['head_sizes'],
        rounds=row['pairs'],wins=row['faster_vs_serial'],reduction=row['reduction_vs_serial_pct'],
        comm=row['estimated_peer_request_fraction_pct'],
        note='Wan5B时延波动很大，不接受14.74%等中位数比值作为稳定收益' if run=='wan-confirm' else
             '原始基线自有输出，拆分共享输出；全部候选均保留',source=part['sources'][run]['source_sha'])

matrix=read('model-matrix-summary.json')
for row in matrix['cases']:
    for arm in ('serial','overlap'):
        append('初期等分_30轮确认' if row['pairs']==30 else '初期等分_筛选',row['run'],row['case'],arm,
            row[f'{arm}_ms'],row[f'{arm}_samples_ms'],row['serial_ms'],shape=row['output_shapes'],
            rounds=row['pairs'],wins=0 if arm=='serial' else row['paired_faster'],
            note='自有单块对共享输出等分；短筛选不等于稳定收益；720p Wan5B实际输出704x1280',source=row['source_sha'])

for row in read('native-summary.json'):
    for name,value in row['runs'].items():
        base_name='native-A1' if name in ('native-A1','native-B1') else 'native-A2'
        append('最初原生_A1B1B2A2',name,f"h3-{row['size']}",name,value['median_ms'],value['samples_ms'],
            row['runs'][base_name]['median_ms'],shape=[[row['size'],row['size'],3]],
            note='历史路径/输出所有权不同；无交替逐轮配对；不可与最新原型混算')


def save(name, records):
    fields=list(dict.fromkeys(k for record in records for k in record))
    with (out/name).open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields)
        writer.writeheader()
        for record in records:
            writer.writerow({key:json.dumps(value,ensure_ascii=False) if isinstance(value,(list,dict)) else value
                             for key,value in record.items()})


controls=[]
for c in coverage['controls']:
    controls.append(dict(stage='覆盖矩阵独立core控制',case=c['case'],heads=c['head_sizes'],
        attention_whole_us=c['attention_whole_us'],attention_split_us=c['attention_split_us'],
        split_tax_us=c['splitting_tax_us'],peer_us=c['peer_forward_us']+c['peer_reverse_us'],
        isolated_peer_core_pct=c['isolated_peer_core_fraction_pct'],core_saving_us=c['core_borrowed_saving_us'],
        note='同共享输出槽完整core；非请求内profiling'))
budget=read('core-budget-summary.json')
for c in budget['core_cases']:
    controls.append(dict(stage='早期独立core控制',case=f"{c['model_run']}/{c['case']}",
        heads=[c['split_heads'],c['split_heads']],attention_whole_us=c['A_us'],attention_split_us=c['A_split_us'],
        split_tax_us=c['split_tax_us'],peer_us=c['C_peer_us'],isolated_peer_core_pct=c['core_peer_fraction_pct'],
        core_saving_us=c['core_saved_us'],estimated_peer_request_pct=c['estimated_peer_budget_request_pct'],
        note=c['whole_vs_split_ownership']))

micro=[]
for row in read('micro-timings.json'):
    micro.append(dict(stage='最初micro',case=row['case'],mode=row['mode'],variant=row['variant'],
        event_median_us=row['median_ms']*1000,event_samples_us=[v*1000 for v in row['rank_max_event_samples_ms']],
        note='孤立算子/传输/完整core的不同变体，不能当E2E收益'))
for row in budget['waves']['records']:
    for variant,median in row['median_us'].items():
        micro.append(dict(stage='纯attention波次控制',case=f"N{row['tokens']}-H{row['heads']}",mode='graph',variant=variant,
            event_median_us=median,event_samples_us=row['samples_us'][variant],
            note='纯attention，无通信；所有分组精度相等'))

save('all-e2e-variants.csv',rows)
save('all-steady-samples.csv',samples)
save('all-first-shape-observations.csv',cold)
save('communication-splitting-controls.csv',controls)
save('isolated-microbenchmarks.csv',micro)

counts=Counter(r['stage'] for r in rows)
lines=['全部已记录性能结果（截至2026-11-21；包含各阶段，不混算实现和输出所有权）','',
    '最新实现是实际请求前缀探测：第一个真实DiT调用发现shape，第二个调用的前24个同签名core学习。',
    '每层仅执行一次，结果进入真实计算；不增加forward。已有capture边界统一汇总，后续图replay零探测。',
    '旧预热采样版仍保留为历史结果，不能混作最新实现的验收证据。','',
    '所有正值、负值、A/A回退及不稳定结果均保留；百分比为(基线中位数-变体中位数)/基线中位数。',
    '不同阶段的实现、输出所有权、预热顺序不同，必须在各自同run/case内比较。',
    '通信占比为孤立控制折算估计；micro算子时间与完整请求时间分文件。',
    'NVIDIA L20X/NV18，离线固定图，batch/concurrency1。Qwen/Wan/H3的主要新矩阵为FP8 DiT，attention为BF16；FLUX为BF16。',
    'Qwen/FLUX的VAE2请求被registry忽略。H3/WanA14B VAE4；早期Wan5B VAE2。','',
    f'共{len(rows)}条E2E变体汇总、{len(samples)}条稳态样本、{len(cold)}条首次形状观测、{len(controls)}个core控制、{len(micro)}条micro变体。',
    '汇总行包含同一场景独立复测和基线，不是独立shape数量。原始JSON及既有TXT报告在original-evidence.zip。','',
    '阶段 | 变体汇总行数']
lines.extend(f'{stage} | {count}' for stage,count in counts.items())
lines += ['', '最新实际前缀探测完整报告（26场景、独立复核、独立进程首次成本）','',
          (prefix_root/'PREFIX-RESULTS.txt').read_text(encoding='utf-8'),
          '', '历史预热采样版全部13场景（两次重学各8对；A/A正负差值不作为优化收益）',
          'case | whole_ms | adaptive_ms | 表观差值pct | AB/BA各次差值pct | heads | 通信估计pct | 结论']
latest=read('lazy-summary.json')
for r in latest['canonical_cases']:
    ratio='/'.join(f"{order['adaptive']['reduction_pct']:+.2f}" for order in r['orders'])
    heads=[';'.join('+'.join(map(str,p['selected'])) for p in order['policy']) for order in r['orders']]
    share=r['communication']['estimated_peer_request_fraction_pct'] if r['communication'] else None
    lines.append(f"{r['case']} | {r['baseline_ms']:.3f} | {r['adaptive_ms']:.3f} | {r['reduction_pct']:+.2f} | {ratio} | {heads} | {share} | {r['interpretation']}")
lines += ['', 'Wan33帧后续30对复核：2162.049 ->2097.739 ms，+2.97%，30/30对更快；不删除此前波动结果。',
          '', '固定分组17场景30轮确认（whole自有输出；另列同共享输出槽收益）',
          'case | whole_ms | selected_ms | vs_whole_pct | vs_borrowed_whole_pct | heads | note']
for r in coverage['rows']:
    if r['variant']!='selected':
        continue
    base=next(v for v in coverage['rows'] if (v['run'],v['case'],v['variant'])==(r['run'],r['case'],'serial1'))
    note='A/A，未切分，不接受差值为优化收益' if r['selected_settings_same_as_serial'] else '固定分组'
    lines.append(f"{r['case']} | {base['median_ms']:.3f} | {r['median_ms']:.3f} | {r['reduction_vs_serial_pct']:+.2f} | {r['reduction_vs_borrowed_pct']} | {r['variant_config']} | {note}")
lines += ['', '全部E2E变体（单位ms；正值更快，A/A正值不算优化收益）',
          'stage | run | case | variant | base_ms | median_ms | reduction_pct | wins/rounds | note']
for r in rows:
    f=lambda v:f'{v:.3f}' if isinstance(v,(int,float)) else '-'
    lines.append(' | '.join((r['stage'],r['run'],r['case'],r['variant'],f(r['baseline_ms']),f(r['median_ms']),
        f(r['latency_reduction_pct']),f"{r['faster_pairs']}/{r['rounds']}",r['note'])))
lines += ['', '失败/不接受为性能收益的结果']
for method,data in [('真实前缀',prefix),('预热采样',lazy),('固定分组',coverage)]:
    for run,value in data['runs'].items():
        if value['exit_code']!='0':
            lines.append(f"{method}/{run}: exit{value['exit_code']}，排除性能收益，保留原始日志。")
lines += ['FLUX FP8初始化不支持；FLUX ref2在image-latent ID准备失败；初期未到CE的捕获被拒绝，均不算性能收益。',
          'H3小图拆分触发过packed FA3 auto-SplitKV精度不一致，当前小图保留单块，未放宽精度容差。',
          'Wan5B早期14.74%中位数比值未稳定复现，不接受该幅度作为收益。',
          'WanA14B33帧最终矩阵早期AB/BA -5.84%/+13.06%均波动大；后续独立30轮确认+2.97%、30/30胜出。']
(out/'ALL-TESTS.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(out/'original-evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(evidence.glob('*summary.json')):
        archive.write(file,'evidence/'+file.name)
    archive.write(evidence/'micro-timings.json','evidence/micro-timings.json')
    archive.write(Path('outputs/issue-10448-lazy-20261121/summary.json'),'evidence/lazy-verified-request-summary.json')
    for name in ('summary.json','prefix-summary.json','manifest.json','PREFIX-RESULTS.txt','verification.log','completion-audit.log','evidence.tar.gz',
                 'all-requests.csv','all-comparisons.csv','all-prefix-observations.csv','independent-first-requests.csv'):
        archive.write(prefix_root/name,'real-prefix/'+name)
    for name in ('coverage-diagnostics.json','lazy-manifest.json'):
        if (evidence/name).exists():
            archive.write(evidence/name,'evidence/'+name)
    for name in ('LAZY-RESULTS.txt','COVERAGE-RESULTS.txt','MATRIX-RESULTS.txt','PARTITION-RESULTS.txt','BUDGET-ANALYSIS.txt','README.md'):
        archive.write(bench/name,name)
assert len({(r['stage'],r['run'],r['case'],r['variant']) for r in rows})==len(rows)
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file() and p.name not in ('sha256.json','all-tests.zip')}
(out/'sha256.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(out/'all-tests.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(out.iterdir()):
        if file.is_file() and file.name!='all-tests.zip':
            archive.write(file,file.name)
print(json.dumps(dict(e2e_rows=len(rows),steady_samples=len(samples),first_shape_observations=len(cold),core_controls=len(controls),micro_rows=len(micro))))
