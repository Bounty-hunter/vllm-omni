"""Verify real-request prefix geometry, precision, counts and paired timings."""
import hashlib
import json
import random
import statistics
import subprocess
from pathlib import Path

root=Path('outputs/issue-10448-prefix-20261121')
repo=Path('worktrees/issue-10448-hcms')
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
summary=dict(scope='Real denoising call one discovers; first24 same-signature cores in call two sample. '
             'Actual eager results feed the pipeline; original capture boundary freezes, then replay.',runs={},rows=[])
blobs={}


def policies(row,h3):
    return ({'blocks':row['lazy_policy']} if row.get('lazy_policy') else {}) if h3 else row.get('lazy_policies',{})


def interval(values):
    rng=random.Random(10448)
    resamples=sorted(statistics.median(rng.choices(values,k=len(values))) for _ in range(10000))
    return [resamples[249],resamples[9749]]


for name,item in manifest.items():
    folder=root/name
    for entry in item['files']:
        file=root/entry['file']
        assert file.stat().st_size==entry['bytes'] and hashlib.sha256(file.read_bytes()).hexdigest()==entry['sha256'],file
    run=summary['runs'][name]=dict(exit_code=item['exit_code'],remote=item['remote'])
    if item['exit_code']!='0':
        print('FAILED, retained:',name)
        continue
    assert (folder/'restoration-status.txt').read_text(encoding='utf-8')==''
    sha=(folder/'source/code-sha.txt').read_text(encoding='utf-8').strip()
    run['source_sha']=sha
    for line in (folder/'source/source.sha256').read_text(encoding='utf-8').splitlines():
        expected,path=line.split(maxsplit=1)
        relative='benchmarks/diffusion/head_overlap/'+path.rsplit('/',1)[-1]
        key=sha,relative
        if key not in blobs:
            blobs[key]=subprocess.check_output(['git','-C',str(repo),'show',f'{sha}:{relative}'])
        assert hashlib.sha256(blobs[key]).hexdigest()==expected,(name,relative)
    config=json.loads((folder/'source/config.json').read_text(encoding='utf-8'))
    data=json.loads((folder/'results/results.json').read_text(encoding='utf-8'))
    assert data['config']==config and not config['engine']['enable_diffusion_pipeline_profiler']
    h3=name.startswith('h3-')
    family=name.split('-')[0]
    parallel=config['engine'].get('parallel_config',config['engine'])
    world=parallel['ulysses_degree']
    audit_path=folder/('audit' if h3 else 'results/audit')
    audits={rank:[json.loads(line) for line in (audit_path/(f'audit-rank{rank}.jsonl' if h3 else f'rank{rank}.jsonl')).read_text(encoding='utf-8').splitlines()]
            for rank in range(world)}
    run['requests']=len(data['records'])
    run['model_audit']=next(row for row in audits[0] if row['kind']=='model')
    for case in config['cases']:
        arms=case.get('variants',config['variants'])
        records=[r for r in data['records'] if r['case']==case['id']]
        rounds=config['measurement']['rounds']
        assert len(records)==len(arms)*(rounds+config['measurement']['warmups']+2)
        sampling=case['sampling']
        shape=([1,sampling['num_frames'],sampling['height'],sampling['width'],3] if sampling.get('num_frames',1)>1 else
               [sampling['height'],sampling['width'],3])
        assert all(row['shapes']==[shape] and not row['profile'] for row in records)
        for seed in (42,43,44):
            rows=[r for r in records if r['seed']==seed]
            assert {r['variant'] for r in rows}==set(arms)
            assert len({json.dumps((r['hashes'],r['shapes'],r['dtypes'])) for r in rows})==1,(name,case['id'],seed)
        firsts,steady={},{}
        for rank,audit in audits.items():
            firsts[rank],steady[rank]={},{}
            for arm,options in arms.items():
                first=next(r for r in audit if r.get('label')==f'{case["id"]}-warm-{arm}-i0')
                post=next(r for r in audit if r.get('label')==f'{case["id"]}-correctness-{arm}-i0')
                firsts[rank][arm],steady[rank][arm]=first,post
                calls='native_python_calls' if h3 else 'direct_python_calls'
                assert post[calls]==0
                assert first['execution_counters']['sampling_host_syncs']==first['execution_counters']['captured_timer_records']==0
                assert all(post['execution_counters'][key]==0 for key in ('timed_event_records','event_queries','all_gather_object','captured_timer_records','sampling_host_syncs'))
                prefix=options.get('real_prefix',False)
                if h3:
                    assert first[calls]==150
                    assert first['real_eager_steps']==(2 if prefix else 0) and post['real_eager_steps']==0
                    assert first['denoising_graph_replays']==(4 if prefix else 6) and post['denoising_graph_replays']==6
                    assert first['validation_replays']==1 and post['validation_replays']==0
                else:
                    layers={'qwen':60,'flux':25,'wan14b':80,'wan5b':30}[family]
                    assert first[calls]==layers*(4 if prefix else 5),(name,case['id'],arm,first[calls])
                    expected_body=4 if prefix else 5
                    assert all(n==expected_body for n in first['eager_forwards'].values())
                    assert first['eager_forwards'] and all(n==0 for n in post['eager_forwards'].values())
                    if prefix:
                        assert first['real_eager_steps'] and all(n==2 for n in first['real_eager_steps'].values())
                    else:
                        assert not first['real_eager_steps']
                    assert not post['real_eager_steps']
                    assert {k:v['captures'] for k,v in first['graph_stats'].items()}=={k:v['captures'] for k,v in post['graph_stats'].items()}
                    assert all(v['captures']==v['graphs']==1 for v in first['graph_stats'].values())
                    total_replays=sum(v['replays'] for v in first['graph_stats'].values())
                    assert total_replays==sampling['num_inference_steps']-(len(first['graph_stats']) if prefix else 0)
                timed=0
                for component,policy in policies(first,h3).items():
                    assert policy==policies(post,h3)[component]
                    if rank:
                        assert policy['reports']==policies(firsts[0][arm],h3)[component]['reports']
                    if prefix:
                        assert policy['stats']['sample_limit_per_signature']==24
                        for report in policy['reports']:
                            assert report['sampling_pass_calls']==report['discovery_calls']
                            assert report['timed_prefix_calls']==report['allocated_sample_pairs']<=24
                            assert len({len(v) for v in report['samples_max_rank_us']})==1
                            assert sum(map(len,report['raw_samples_max_rank_us']))==report['timed_prefix_calls']
                            timed+=report['timed_prefix_calls']
                if prefix:
                    assert first['execution_counters']['event_queries']==timed
                    assert first['execution_counters']['timed_event_records']==timed*4
            if {'serial1','adaptive'} <= arms.keys():
                assert firsts[rank]['serial1'][calls]==firsts[rank]['adaptive'][calls]
        reference='serial1' if 'serial1' in arms else next(iter(arms))
        base={r['index']:r['e2e_ms'] for r in records if r['phase']=='paired' and r['variant']==reference}
        for arm in arms:
            rows=[r for r in records if r['phase']=='paired' and r['variant']==arm]
            values={r['index']:r['e2e_ms'] for r in rows}
            assert set(values)==set(base)==set(range(rounds))
            diff=[base[i]-values[i] for i in base]
            first=next(r for r in records if r['phase']=='warm' and r['index']==0 and r['variant']==arm)
            row=dict(run=name,case=case['id'],variant=arm,median_ms=statistics.median(values.values()),
                cold_ms=first['e2e_ms'],cold_peak_memory_mb=first['peak_memory_mb'],output_shapes=first['shapes'],
                rounds=rounds,reference=reference,reduction_pct=100*(statistics.median(base.values())-statistics.median(values.values()))/statistics.median(base.values()),
                paired_saved_ms=diff,paired_median_saved_ms=statistics.median(diff),paired_bootstrap95_ms=interval(diff),
                wins=sum(v>0 for v in diff),samples_ms=list(values.values()),
                first_rank_audits={rank:rows[arm] for rank,rows in firsts.items()},
                steady_rank_audits={rank:rows[arm] for rank,rows in steady.items()})
            summary['rows'].append(row)
            print(f"{name} {case['id']} {arm}: first{row['cold_ms']:.2f}ms,steady{row['median_ms']:.2f}ms,delta{row['reduction_pct']:+.2f}%,{row['wins']}/{rounds}")
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
print('PASS actual geometry,3-seed exactness,rank agreement,real-prefix budget,forward/replay/capture counts and zero steady exploration')
