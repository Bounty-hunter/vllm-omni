"""Keep confirmations and independent-process cold controls on the same policy."""
import copy
import json
from pathlib import Path

bench = Path('worktrees/issue-10448-hcms/benchmarks/diffusion/head_overlap')
indices = dict(qwen=[0, 2, 3], flux=[0, 2, 3], wan14b=[0, 2, 3],
               h3=[1, 5, 6], wan5b=[1, 2])
startup_index = dict(qwen=2, flux=3, wan14b=2, h3=5, wan5b=2)
for family, selected in indices.items():
    original = json.loads((bench / f'prefix-{family}-matrix.json').read_text())
    confirm = copy.deepcopy(original)
    confirm['cases'] = [confirm['cases'][i] for i in selected]
    confirm['measurement']['rounds'] = 30
    confirm['measurement']['purpose'] = 'Independent process; repeat natural-prefix selection, then 30 paired steady requests.'
    (bench / f'prefix-{family}-confirm.json').write_text(json.dumps(confirm, indent=2) + '\n', newline='\n')
    for arm in ('serial1', 'adaptive'):
        startup = copy.deepcopy(original)
        startup['cases'] = [startup['cases'][startup_index[family]]]
        startup['variants'] = {arm: startup['variants'][arm]}
        startup['measurement']['rounds'] = 1
        startup['measurement']['purpose'] = 'Single arm, independent model process. First warm record is first request after model loading.'
        (bench / f'prefix-{family}-startup-{arm}.json').write_text(json.dumps(startup, indent=2) + '\n', newline='\n')
