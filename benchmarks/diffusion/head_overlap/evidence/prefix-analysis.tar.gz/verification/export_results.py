"""Publish every real-prefix observation without mixing historical methods."""
import csv
import hashlib
import json
import statistics
import zipfile
from pathlib import Path

root = Path('outputs/issue-10448-prefix-20261121')
bench = Path('worktrees/issue-10448-hcms/benchmarks/diffusion/head_overlap')
summary = json.loads((root / 'summary.json').read_text())
coverage = json.loads((bench / 'evidence/coverage-summary.json').read_text())
requests, choices, comparisons, startups = [], [], [], []
cross_run_outputs = {}
raw = {}
for name, run in summary['runs'].items():
    if run['exit_code'] != '0':
        continue
    raw[name] = json.loads((root / name / 'results/results.json').read_text())
    for record in raw[name]['records']:
        key = name.split('-')[0], record['case'], record['seed']
        value = record['hashes'], record['shapes'], record['dtypes']
        assert key not in cross_run_outputs or cross_run_outputs[key] == value, (name, key)
        cross_run_outputs[key] = value
        requests.append(dict(run=name, source_sha=run['source_sha'], **record))


def policies(row):
    audit = row['first_rank_audits']['0']
    return {'blocks': audit['lazy_policy']} if audit.get('lazy_policy') else audit.get('lazy_policies', {})


def partitions(row):
    return '; '.join(f"{component}:" + ','.join('+'.join(map(str, r['selected'])) for r in policy['reports'])
                     for component, policy in policies(row).items())


def whole(row):
    reports = [r for p in policies(row).values() for r in p['reports']]
    return bool(reports) and all(len(r['selected']) == 1 for r in reports)


def geometries(row):
    result = []
    for component, policy in policies(row).items():
        for report in policy['reports']:
            signature = report['signature']
            world, qkv, metadata = signature[1:]
            shape = qkv[0][0]
            joint = 0
            if metadata is not None and metadata[0] == 'AttentionMetadata':
                fields = dict(metadata[1])
                if fields.get('joint_query') is not None:
                    joint = fields['joint_query'][0][1]
            result.append(dict(component=component, world=world, batch=shape[0],
                               sequence_tokens=shape[1] * world, joint_tokens=joint,
                               attention_tokens=shape[1] * world + joint,
                               heads_per_rank=shape[2] // world, head_dim=shape[3]))
    return result


def selection_notes(row):
    result = []
    for component, policy in policies(row).items():
        for report in policy['reports']:
            valid = min(map(len, report['samples_max_rank_us']))
            reason = ('布局/工作量/机会数守卫，未启用切分候选' if len(report['choices']) == 1 else
                      '完全排队的有效cycle不足6，保留单块' if valid < 6 else
                      '收益/胜率/噪声门槛未通过，保留单块' if len(report['selected']) == 1 else
                      '完整core配对观测通过选择门槛')
            result.append(dict(component=component, selected=report['selected'], valid_cycles=valid, reason=reason))
    return result


def communication(case, baseline):
    name = case.removesuffix('-real-prefix')
    control = next((c for c in coverage['controls'] if c['request_case'] == name), None)
    if control is None:
        return None
    peer = control['peer_forward_us'] + control['peer_reverse_us']
    return dict(estimated_request_pct=peer * control['calls_per_request'] / baseline / 10,
                isolated_core_pct=control['isolated_peer_core_fraction_pct'],
                source_sha=control['source_sha'], control=control['case'], peer_us=peer,
                calls_per_request=control['calls_per_request'], partition=control['head_sizes'],
                split_attention_tax_us=control['splitting_tax_us'],
                note='Earlier isolated layout control, not in-request profiling. Split tax applies only to its stated partition.')


for row in summary['rows']:
    for component, policy in policies(row).items():
        for report in policy['reports']:
            choices.append(dict(run=row['run'], case=row['case'], variant=row['variant'], component=component,
                                **report, preparation_stats=policy['stats']))
    if row['variant'] == 'serial1' or '-startup-' in row['run']:
        continue
    base = next(r for r in summary['rows'] if (r['run'], r['case'], r['variant']) ==
                (row['run'], row['case'], 'serial1'))
    share = communication(row['case'], base['median_ms'])
    if row['variant'] != 'legacy1':
        assert geometries(row) == geometries(base), (row['run'], row['case'])
    interpretation = ('旧单块路径对照，仅验证等价，不算overlap收益' if row['variant'] == 'legacy1' else
                      '回退单块：A/A差值，不算overlap收益' if whole(row) else
                      '配对区间跨零，未确认稳定收益' if row['paired_bootstrap95_ms'][0] <= 0 else
                      '短矩阵筛选，需独立长轮次复核' if row['rounds'] < 30 else
                      '本批30对支持收益；另核对独立重学是否重复选中')
    comparisons.append(dict(run=row['run'], case=row['case'], variant=row['variant'],
                            actual_output_shape=row['output_shapes'], rounds=row['rounds'],
                            attention_geometries=geometries(row),
                            selection_notes=selection_notes(row),
                            baseline_ms=base['median_ms'], candidate_ms=row['median_ms'],
                            latency_reduction_pct=row['reduction_pct'], wins=row['wins'],
                            paired_median_saved_ms=row['paired_median_saved_ms'],
                            paired_bootstrap95_ms=row['paired_bootstrap95_ms'],
                            partition=partitions(row) or '旧单块路径', whole_fallback=whole(row),
                            estimated_peer_request_pct=share['estimated_request_pct'] if share else None,
                            communication_control=share,
                            first_baseline_ms=base['cold_ms'], first_candidate_ms=row['cold_ms'],
                            source_sha=summary['runs'][row['run']]['source_sha'],
                            interpretation=interpretation,
                            note='The actual selection is frozen after the real prefix; cold costs are reported separately.'))

startup_rows = [r for r in summary['rows'] if '-startup-' in r['run']]
signatures = {}
for row in startup_rows:
    for record in raw[row['run']]['records']:
        key = row['run'].split('-')[0], row['case'], record['seed']
        value = record['hashes'], record['shapes'], record['dtypes']
        assert key not in signatures or signatures[key] == value, key
        signatures[key] = value
    if row['variant'] != 'adaptive':
        continue
    base_run = row['run'].replace('-startup-adaptive-', '-startup-serial1-')
    base = next((r for r in startup_rows if r['run'] == base_run), None)
    if base is None:
        continue

    def boundary_times(value, field):
        audit_policies = [({'blocks': audit['lazy_policy']} if audit.get('lazy_policy') else audit['lazy_policies'])
                          for audit in value['first_rank_audits'].values()]
        return max(sum(p['stats'][field] for p in rank.values()) for rank in audit_policies)

    startups.append(dict(family=row['run'].split('-')[0], repeat=row['run'].split('-')[-1],
                         case=row['case'], serial1_ms=base['cold_ms'], adaptive_ms=row['cold_ms'],
                         adaptive_minus_serial1_ms=row['cold_ms'] - base['cold_ms'],
                         serial_prepare_ms=boundary_times(base, 'prepare_ms'),
                         adaptive_prepare_ms=boundary_times(row, 'prepare_ms'),
                         serial_finish_ms=boundary_times(base, 'finish_ms'),
                         adaptive_finish_ms=boundary_times(row, 'finish_ms'),
                         serial_peak_memory_mb=base['cold_peak_memory_mb'],
                         adaptive_peak_memory_mb=row['cold_peak_memory_mb'],
                         peak_memory_delta_mb=[b - a for a, b in zip(base['cold_peak_memory_mb'], row['cold_peak_memory_mb'], strict=True)],
                         selected=partitions(row),
                         note='Independent processes, first request after model loading; difference includes graph setup, audit and variability.'))


def write_csv(filename, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with (root / filename).open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value, ensure_ascii=False) if isinstance(value, (list, dict)) else value
                             for key, value in row.items()})


write_csv('all-requests.csv', requests)
write_csv('all-comparisons.csv', comparisons)
write_csv('all-prefix-observations.csv', choices)
write_csv('independent-first-requests.csv', startups)
matrix = [r for r in comparisons if '-matrix-' in r['run'] and r['variant'] == 'adaptive']
confirmed = [r for r in comparisons if '-confirm-' in r['run'] and r['variant'] == 'adaptive']
lines = [
    '真实请求前缀探测：完整性能结果', '',
    '首个真实 DiT 调用发现签名；第二个真实调用的前24个同签名core尝试单块和一个预测分组。',
    '探测窗口内每次attention只跑一个方案，结果进入后续计算；原有capture同步点统一决定策略，之后固定图replay。',
    'CSV的warm仅是性能脚本对首个完整generate请求的标签；不是在辅助预热forward里取样。',
    '原有建图同步检查、capture记录及验证replay保留并分别计数；没有新增探测forward。',
    'Wan A14B两个expert分别在各自的前两次真实调用学习，不一定是全局step1/2。',
    '没有增加forward；首请求仍有事件记录、候选资源准备和可能试到慢方案的成本。', '',
    '早期smoke使用e21版本、最多两个切分候选；当前26场景矩阵及复测只比较whole与一个预测切分。',
    '硬件：NVIDIA L20X，NV18互联；离线batch/concurrency1；attention BF16/FA3。',
    'Torch 2.14.0+cu130，vLLM 0.34.0；dense backend fa3_fwd_interface，varlen fa_version=3。',
    'Qwen/H3/Wan DiT FP8；FLUX BF16（当前FP8初始化不支持）。',
    'H3为H3-Image checkpoint，6 step/SP4/原生VAE4；不是H3视频模型。',
    'Qwen 8 step/SP2、FLUX 4 step/SP2；两者registry忽略VAE2配置，不能宣称VAE并行生效。',
    'Wan A14B 8 step/SP4/VAE4；Wan TI2V-5B 8 step/SP2/VAE2。',
    '正值=延迟下降百分比=(whole中位数-adaptive中位数)/whole中位数；两臂共享输出所有权。',
    '通信占比复用之前相同geometry的孤立peer控制×每请求core次数/E2E，为估计，非请求内测量。',
    '这里只折算Ulysses attention-core peer通信，不包含text encoder/VAE等模块的其他通信。',
    '未覆盖的通信占比留空；旧控制的拆分税只适用于其记录的分组，不能代替新选择分组的纯attention测量。', '',
    f"完成{len(summary['runs'])}批（含失败如有），{len(requests)}请求；矩阵{len(matrix)}场景，长轮次复核{len(confirmed)}场景。", '',
    '全部矩阵（8对；A/A正负差值不算overlap收益）',
    'case | 全局attention tokens | whole ms | adaptive ms | 差值% | 胜出 | rank内实际heads | 通信估计% | 30轮复核',
]
for row in matrix:
    confirm = next((r for r in confirmed if r['case'] == row['case']), None)
    last = (f"{confirm['latency_reduction_pct']:+.2f}% {confirm['wins']}/30; {confirm['partition']}"
            if confirm else '未复核')
    share = row['estimated_peer_request_pct']
    share_text = f'{share:.2f}' if share is not None else '-'
    tokens = sorted({r['attention_tokens'] for r in row['attention_geometries']})
    lines.append(f"{row['case']} | {tokens} | {row['baseline_ms']:.3f} | {row['candidate_ms']:.3f} | "
                 f"{row['latency_reduction_pct']:+.2f} | {row['wins']}/{row['rounds']} | {row['partition']} | "
                 f"{share_text} | {last}")
lines += ['', '独立30轮复核（在新进程重新学习；若回退单块，同样记录）',
          'case | whole ms | adaptive ms | 差值% | 胜出 | 配对节省95% bootstrap区间ms | heads | 判断']
for row in confirmed:
    lines.append(f"{row['case']} | {row['baseline_ms']:.3f} | {row['candidate_ms']:.3f} | "
                 f"{row['latency_reduction_pct']:+.2f} | {row['wins']}/30 | "
                 f"{row['paired_bootstrap95_ms']} | {row['partition']} | {row['interpretation']}")
lines += ['', '如何理解模型间差异',
          '同样是大shape，E2E收益仍受通信占比约束。H3大图通信预算约10-11%，FLUX参考图约2-3%，空间不同。',
          '分组需要同时满足小块效率、计算覆盖后续通信、以及总attention拆分损失；尺寸更大并不保证收益更大。',
          '480x832、65帧时，A14B实际attention序列26520 tokens，TI2V-5B仅6630 tokens；视频输出尺寸并不等于attention负载。',
          '旧Wan5B/SP2的65帧6+6孤立控制中，纯attention由382.36增至456.84us，增加74.48us；peer合计149.05us。',
          '这个等分反例中拆分损失接近一半通信预算；它不证明其他分组无收益。当前在线候选置信度不足则保留单块。',
          'Wan A14B65帧首轮8对曾-2.36%；30轮独立复测的实际值另列，两批都保留，不能用后者覆盖前者。',
          'Qwen1536单参考图首轮8/8更快，30轮配对区间仍跨零，暂不列为稳定收益。',
          '旧固定2+10控制曾在Qwen1024单参考图取得约2.53%同输出所有权收益；本版因有效cycle不足回退，未恢复该收益。',
          '这是当前探测覆盖率的限制；旧固定分组结果单独保留，不能计为本版自动选择收益。',
          '只有明确选中切分且独立长轮次支持的场景才作为收益证据；A/A和区间跨零的结果保留原值。']
lines += ['', '独立进程首请求（模型加载后；每个模型两对，顺序AB/BA；样本量不足以估计稳定首请求均值）',
          'family/repeat | whole ms | adaptive ms | adaptive额外ms | 准备whole/auto ms | 汇总whole/auto ms | 峰值whole/auto MB | heads']
for row in startups:
    lines.append(f"{row['family']}/{row['repeat']} | {row['serial1_ms']:.3f} | {row['adaptive_ms']:.3f} | "
                 f"{row['adaptive_minus_serial1_ms']:+.3f} | {row['serial_prepare_ms']:.3f}/{row['adaptive_prepare_ms']:.3f} | "
                 f"{row['serial_finish_ms']:.3f}/{row['adaptive_finish_ms']:.3f} | "
                 f"{row['serial_peak_memory_mb']}/{row['adaptive_peak_memory_mb']} | {row['selected']}")
lines += ['', '验证口径和限制',
          'summarize.py逐批校验：SHA/源码hash、真实输出shape、seed42/43/44逐字节一致、所有rank策略一致。',
          'export_results.py另核对相同case/seed跨smoke、矩阵、复核及独立首请求进程的最终输出hash。',
          '校验首次和后续请求的真实eager步数、capture/验证/replay次数、每签名<=24计时core及事件数。',
          '稳态Python core/计时事件/query/学习all-gather/逐core主机同步均为0；通信依赖和GPU fence仍执行。',
          'Qwen首次Python core240（旧路径300）；H3仍150，含两个真实eager step、capture记录，另有原有验证replay。',
          'prepared_ms包含资源/控制面工作，不能直接当纯新增成本；内存字段为现有peak高水位统计。',
          'GPU由调度器为任务分配；主机及其他卡仍有共享负载，首请求差值包含初始化、建图与系统波动。',
          '各臂使用各自的磁盘编译缓存目录，并在两次进程复测间复用；这里测的是新模型进程首请求，不是清空全部JIT缓存的启动。',
          '探测受CPU供给速度影响：未完全排队的cycle丢弃；低置信度回退单块，不能补跑forward。',
          '未获得有效样本不等于图模式下无理论收益；all-comparisons.csv逐签名列出回退原因和有效cycle数。',
          '预测模型只产生候选，参数尚未在线校准；不保证所有新shape或独立重学都选中最优切分。',
          '总peer字节量未减少；目标是减少关键路径可见通信，不能把总通信量写成减半。',
          '当前是显式离线实验适配，尚未作为默认服务路径；未验收HTTP/并发/跨请求持久化策略/NPU。',
          '全部原始请求/配对样本/候选观测/首请求分别见相邻CSV，历史阶段完整结果另见issue-10448-all-tests目录。']
(root / 'PREFIX-RESULTS.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8', newline='\n')
compact = dict(scope=summary['scope'], requests=len(requests), runs=summary['runs'],
               matrix=matrix, confirmations=confirmed, independent_startup_pairs=startups,
               qualifications='Offline fixed-case graph prototype; no extra forwards, zero steady learning. '
                              'Communication estimates reuse earlier independent layout controls. '
                              'Intervals crossing zero and whole-attention fallbacks are not accepted gains.')
(root / 'prefix-summary.json').write_text(json.dumps(compact, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
hashes = {file.name: hashlib.sha256(file.read_bytes()).hexdigest()
          for file in root.iterdir() if file.is_file() and file.name not in ('sha256.json', 'prefix-tests.zip')}
(root / 'sha256.json').write_text(json.dumps(hashes, indent=2) + '\n', encoding='utf-8', newline='\n')
with zipfile.ZipFile(root / 'prefix-tests.zip', 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for name in ('PREFIX-RESULTS.txt', 'all-requests.csv', 'all-comparisons.csv', 'all-prefix-observations.csv',
                 'independent-first-requests.csv', 'summary.json', 'manifest.json', 'verification.log',
                 'evidence.tar.gz', 'prefix-summary.json', 'completion-audit.log', 'sha256.json'):
        archive.write(root / name, name)
print(json.dumps(dict(requests=len(requests), matrix_cases=len(matrix), confirmations=len(confirmed),
                      startup_pairs=len(startups), observations=len(choices))))
